(this["webpackJsonphakeem"] = this["webpackJsonphakeem"] || []).push([["main"],{

    /***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/App.css":
    /*!************************************************************************************************************************!*\
      !*** ./node_modules/css-loader/dist/cjs.js??ref--5-oneOf-4-1!./node_modules/postcss-loader/src??postcss!./src/App.css ***!
      \************************************************************************************************************************/
    /*! exports provided: default */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    __webpack_require__.r(__webpack_exports__);
    /* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
    /* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
    // Imports
    
    var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(true);
    // Module
    ___CSS_LOADER_EXPORT___.push([module.i, ".App {\n  text-align: center;\n}\n/*\n.App-logo {\n  height: 40vmin;\n  pointer-events: none;\n}\n\n@media (prefers-reduced-motion: no-preference) {\n  .App-logo {\n    animation: App-logo-spin infinite 20s linear;\n  }\n}\n\n.App-header {\n  background-color: #282c34;\n  min-height: 100vh;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  font-size: calc(10px + 2vmin);\n  color: white;\n}\n\n.App-link {\n  color: #61dafb;\n}\n\n@keyframes App-logo-spin {\n  from {\n    transform: rotate(0deg);\n  }\n  to {\n    transform: rotate(360deg);\n  }\n} */\n\n.addUser{\n  position: absolute;\n  top: 80px;\n  right: 10px;\n}\n\n/* .form-control {\n  width: 25% !important;\n} */\n \nform{\n  display: inline-block;\n} \n\n.twobuttons{\n  display: flex;\n  justify-content: space-evenly;\n  margin-bottom: \"2.25em\";\n  margin-top: \"2.25em\" \n\n}\n", "",{"version":3,"sources":["webpack://src/App.css"],"names":[],"mappings":"AAAA;EACE,kBAAkB;AACpB;AACA;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;GAkCG;;AAEH;EACE,kBAAkB;EAClB,SAAS;EACT,WAAW;AACb;;AAEA;;GAEG;;AAEH;EACE,qBAAqB;AACvB;;AAEA;EACE,aAAa;EACb,6BAA6B;EAC7B,uBAAuB;EACvB;;AAEF","sourcesContent":[".App {\n  text-align: center;\n}\n/*\n.App-logo {\n  height: 40vmin;\n  pointer-events: none;\n}\n\n@media (prefers-reduced-motion: no-preference) {\n  .App-logo {\n    animation: App-logo-spin infinite 20s linear;\n  }\n}\n\n.App-header {\n  background-color: #282c34;\n  min-height: 100vh;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  font-size: calc(10px + 2vmin);\n  color: white;\n}\n\n.App-link {\n  color: #61dafb;\n}\n\n@keyframes App-logo-spin {\n  from {\n    transform: rotate(0deg);\n  }\n  to {\n    transform: rotate(360deg);\n  }\n} */\n\n.addUser{\n  position: absolute;\n  top: 80px;\n  right: 10px;\n}\n\n/* .form-control {\n  width: 25% !important;\n} */\n \nform{\n  display: inline-block;\n} \n\n.twobuttons{\n  display: flex;\n  justify-content: space-evenly;\n  margin-bottom: \"2.25em\";\n  margin-top: \"2.25em\" \n\n}\n"],"sourceRoot":""}]);
    // Exports
    /* harmony default export */ __webpack_exports__["default"] = (___CSS_LOADER_EXPORT___);
    
    
    /***/ }),
    
    /***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/index.css":
    /*!**************************************************************************************************************************!*\
      !*** ./node_modules/css-loader/dist/cjs.js??ref--5-oneOf-4-1!./node_modules/postcss-loader/src??postcss!./src/index.css ***!
      \**************************************************************************************************************************/
    /*! exports provided: default */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    __webpack_require__.r(__webpack_exports__);
    /* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
    /* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
    // Imports
    
    var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(true);
    // Module
    ___CSS_LOADER_EXPORT___.push([module.i, "body {\n  margin: 0;\n  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',\n    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',\n    sans-serif;\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n}\n\ncode {\n  font-family: source-code-pro, Menlo, Monaco, Consolas, 'Courier New',\n    monospace;\n}\n", "",{"version":3,"sources":["webpack://src/index.css"],"names":[],"mappings":"AAAA;EACE,SAAS;EACT;;cAEY;EACZ,mCAAmC;EACnC,kCAAkC;AACpC;;AAEA;EACE;aACW;AACb","sourcesContent":["body {\n  margin: 0;\n  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',\n    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',\n    sans-serif;\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n}\n\ncode {\n  font-family: source-code-pro, Menlo, Monaco, Consolas, 'Courier New',\n    monospace;\n}\n"],"sourceRoot":""}]);
    // Exports
    /* harmony default export */ __webpack_exports__["default"] = (___CSS_LOADER_EXPORT___);
    
    
    /***/ }),
    
    /***/ "./src/App.css":
    /*!*********************!*\
      !*** ./src/App.css ***!
      \*********************/
    /*! no static exports found */
    /***/ (function(module, exports, __webpack_require__) {
    
    var api = __webpack_require__(/*! ../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
                var content = __webpack_require__(/*! !../node_modules/css-loader/dist/cjs.js??ref--5-oneOf-4-1!../node_modules/postcss-loader/src??postcss!./App.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/App.css");
    
                content = content.__esModule ? content.default : content;
    
                if (typeof content === 'string') {
                  content = [[module.i, content, '']];
                }
    
    var options = {};
    
    options.insert = "head";
    options.singleton = false;
    
    var update = api(content, options);
    
    
    if (true) {
      if (!content.locals || module.hot.invalidate) {
        var isEqualLocals = function isEqualLocals(a, b, isNamedExport) {
      if (!a && b || a && !b) {
        return false;
      }
    
      var p;
    
      for (p in a) {
        if (isNamedExport && p === 'default') {
          // eslint-disable-next-line no-continue
          continue;
        }
    
        if (a[p] !== b[p]) {
          return false;
        }
      }
    
      for (p in b) {
        if (isNamedExport && p === 'default') {
          // eslint-disable-next-line no-continue
          continue;
        }
    
        if (!a[p]) {
          return false;
        }
      }
    
      return true;
    };
        var oldLocals = content.locals;
    
        module.hot.accept(
          /*! !../node_modules/css-loader/dist/cjs.js??ref--5-oneOf-4-1!../node_modules/postcss-loader/src??postcss!./App.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/App.css",
          function () {
            content = __webpack_require__(/*! !../node_modules/css-loader/dist/cjs.js??ref--5-oneOf-4-1!../node_modules/postcss-loader/src??postcss!./App.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/App.css");
    
                  content = content.__esModule ? content.default : content;
    
                  if (typeof content === 'string') {
                    content = [[module.i, content, '']];
                  }
    
                  if (!isEqualLocals(oldLocals, content.locals)) {
                    module.hot.invalidate();
    
                    return;
                  }
    
                  oldLocals = content.locals;
    
                  update(content);
          }
        )
      }
    
      module.hot.dispose(function() {
        update();
      });
    }
    
    module.exports = content.locals || {};
    
    /***/ }),
    
    /***/ "./src/App.js":
    /*!********************!*\
      !*** ./src/App.js ***!
      \********************/
    /*! exports provided: default */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    __webpack_require__.r(__webpack_exports__);
    /* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
    /* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components */ "./src/components/index.js");
    /* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
    /* harmony import */ var react_toast_notifications__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-toast-notifications */ "./node_modules/react-toast-notifications/dist/index.js");
    /* harmony import */ var react_toast_notifications__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_toast_notifications__WEBPACK_IMPORTED_MODULE_3__);
    /* harmony import */ var _Routes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Routes */ "./src/Routes.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__);
    __webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
    __webpack_require__.$Refresh$.setup(module.i);
    
    var _jsxFileName = "/home/mounika/Desktop/hakeem-app/src/App.js";
    
    
    
    
    
    
    
    function App() {
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])("div", {
        className: "App",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["BrowserRouter"], {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])("div", {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])(react_toast_notifications__WEBPACK_IMPORTED_MODULE_3__["ToastProvider"], {
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["Route"], {
                exact: true,
                path: "/",
                render: () => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_1__["Splash"], {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 15,
                  columnNumber: 45
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 15,
                columnNumber: 11
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["Route"], {
                exact: true,
                path: "/signin",
                render: () => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_1__["Signup"], {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 16,
                  columnNumber: 51
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 16,
                columnNumber: 11
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["Route"], {
                exact: true,
                path: "/continue",
                render: () => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_1__["Orthis"], {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 17,
                  columnNumber: 53
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 17,
                columnNumber: 11
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["Route"], {
                exact: true,
                path: "/welcome",
                render: () => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_1__["Welcome"], {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 18,
                  columnNumber: 52
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 18,
                columnNumber: 11
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["Route"], {
                path: "/",
                render: props => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])(_Routes__WEBPACK_IMPORTED_MODULE_4__["default"], { ...props
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 19,
                  columnNumber: 44
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 19,
                columnNumber: 11
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 14,
              columnNumber: 9
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 13,
            columnNumber: 9
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 12,
          columnNumber: 8
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 11,
        columnNumber: 5
      }, this);
    }
    
    _c = App;
    /* harmony default export */ __webpack_exports__["default"] = (App);
    
    var _c;
    
    __webpack_require__.$Refresh$.register(_c, "App");
    
    const currentExports = __react_refresh_utils__.getModuleExports(module.i);
    __react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);
    
    if (true) {
      const isHotUpdate = !!module.hot.data;
      const prevExports = isHotUpdate ? module.hot.data.prevExports : null;
    
      if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
        module.hot.dispose(
          /**
           * A callback to performs a full refresh if React has unrecoverable errors,
           * and also caches the to-be-disposed module.
           * @param {*} data A hot module data object from Webpack HMR.
           * @returns {void}
           */
          function hotDisposeCallback(data) {
            // We have to mutate the data object to get data registered and cached
            data.prevExports = currentExports;
          }
        );
        module.hot.accept(
          /**
           * An error handler to allow self-recovering behaviours.
           * @param {Error} error An error occurred during evaluation of a module.
           * @returns {void}
           */
          function hotErrorHandler(error) {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.handleRuntimeError(error);
            }
    
            if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
              if (window.onHotAcceptError) {
                window.onHotAcceptError(error.message);
              }
            }
    
            __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
          }
        );
    
        if (isHotUpdate) {
          if (
            __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
            __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
          ) {
            module.hot.invalidate();
          } else {
            __react_refresh_utils__.enqueueUpdate(
              /**
               * A function to dismiss the error overlay after performing React refresh.
               * @returns {void}
               */
              function updateCallback() {
                if (
                  typeof __react_refresh_error_overlay__ !== 'undefined' &&
                  __react_refresh_error_overlay__
                ) {
                  __react_refresh_error_overlay__.clearRuntimeErrors();
                }
              }
            );
          }
        }
      } else {
        if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
          module.hot.invalidate();
        }
      }
    }
    /* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))
    
    /***/ }),
    
    /***/ "./src/Routes.js":
    /*!***********************!*\
      !*** ./src/Routes.js ***!
      \***********************/
    /*! exports provided: default */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    __webpack_require__.r(__webpack_exports__);
    /* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
    /* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
    /* harmony import */ var react_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-router */ "./node_modules/react-router/esm/react-router.js");
    /* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components */ "./src/components/index.js");
    /* harmony import */ var react_toast_notifications__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-toast-notifications */ "./node_modules/react-toast-notifications/dist/index.js");
    /* harmony import */ var react_toast_notifications__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_toast_notifications__WEBPACK_IMPORTED_MODULE_4__);
    /* harmony import */ var _lang_locales_en__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./lang/locales/en */ "./src/lang/locales/en.js");
    /* harmony import */ var _lang_locales_en__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_lang_locales_en__WEBPACK_IMPORTED_MODULE_5__);
    /* harmony import */ var _lang_locales_ar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./lang/locales/ar */ "./src/lang/locales/ar.js");
    /* harmony import */ var _lang_locales_ar__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_lang_locales_ar__WEBPACK_IMPORTED_MODULE_6__);
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__);
    __webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
    __webpack_require__.$Refresh$.setup(module.i);
    
    var _jsxFileName = "/home/mounika/Desktop/hakeem-app/src/Routes.js";
    
    
    
    
    
    
    
    
    
    
    function Routes() {
      let label = {
        en: (_lang_locales_en__WEBPACK_IMPORTED_MODULE_5___default()),
        ar: (_lang_locales_ar__WEBPACK_IMPORTED_MODULE_6___default())
      };
      localStorage.getItem("language") === "ar" ? label = label.ar : label = label.en;
    
      if (localStorage.getItem('loggedin')) {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(react_router_dom__WEBPACK_IMPORTED_MODULE_1__["BrowserRouter"], {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])("div", {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(react_toast_notifications__WEBPACK_IMPORTED_MODULE_4__["ToastProvider"], {
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Sidebar"], {
                pageWrapId: 'page-wrap',
                outerContainerId: 'outer-container',
                label: label
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 24,
                columnNumber: 29
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["BottomNavbar"], {
                label: label
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 25,
                columnNumber: 29
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(react_router_dom__WEBPACK_IMPORTED_MODULE_1__["Route"], {
                exact: true,
                path: "/search",
                render: () => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Search"], {
                  label: label
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 26,
                  columnNumber: 71
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 26,
                columnNumber: 29
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(react_router_dom__WEBPACK_IMPORTED_MODULE_1__["Route"], {
                exact: true,
                path: "/maps",
                render: () => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["MapContainer"], {
                  label: label
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 27,
                  columnNumber: 69
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 27,
                columnNumber: 29
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(react_router_dom__WEBPACK_IMPORTED_MODULE_1__["Route"], {
                exact: true,
                path: "/profile",
                render: () => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Profile"], {
                  label: label
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 28,
                  columnNumber: 72
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 28,
                columnNumber: 29
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(react_router_dom__WEBPACK_IMPORTED_MODULE_1__["Route"], {
                exact: true,
                path: "/dashboard",
                render: () => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Dashboard"], {
                  label: label
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 29,
                  columnNumber: 74
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 29,
                columnNumber: 29
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(react_router_dom__WEBPACK_IMPORTED_MODULE_1__["Route"], {
                exact: true,
                path: "/chat",
                render: () => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Chat"], {
                  label: label
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 30,
                  columnNumber: 69
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 30,
                columnNumber: 29
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(react_router_dom__WEBPACK_IMPORTED_MODULE_1__["Route"], {
                exact: true,
                path: "/home",
                render: () => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Home"], {
                  label: label
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 31,
                  columnNumber: 69
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 31,
                columnNumber: 29
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(react_router_dom__WEBPACK_IMPORTED_MODULE_1__["Route"], {
                exact: true,
                path: "/appointments",
                render: () => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Bookings"], {
                  label: label
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 32,
                  columnNumber: 77
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 32,
                columnNumber: 29
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(react_router_dom__WEBPACK_IMPORTED_MODULE_1__["Route"], {
                exact: true,
                path: "/appointment",
                render: () => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Appointment"], {
                  label: label
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 33,
                  columnNumber: 76
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 33,
                columnNumber: 29
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(react_router_dom__WEBPACK_IMPORTED_MODULE_1__["Route"], {
                exact: true,
                path: "/profilesettings",
                render: () => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["ProfileSettings"], {
                  label: label
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 34,
                  columnNumber: 80
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 34,
                columnNumber: 29
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 23,
              columnNumber: 25
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 22,
            columnNumber: 21
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 21,
          columnNumber: 17
        }, this);
      } else {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__["jsxDEV"])(react_router__WEBPACK_IMPORTED_MODULE_2__["Redirect"], {
          to: "/"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 43,
          columnNumber: 17
        }, this);
      }
    }
    
    _c = Routes;
    /* harmony default export */ __webpack_exports__["default"] = (Routes);
    
    var _c;
    
    __webpack_require__.$Refresh$.register(_c, "Routes");
    
    const currentExports = __react_refresh_utils__.getModuleExports(module.i);
    __react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);
    
    if (true) {
      const isHotUpdate = !!module.hot.data;
      const prevExports = isHotUpdate ? module.hot.data.prevExports : null;
    
      if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
        module.hot.dispose(
          /**
           * A callback to performs a full refresh if React has unrecoverable errors,
           * and also caches the to-be-disposed module.
           * @param {*} data A hot module data object from Webpack HMR.
           * @returns {void}
           */
          function hotDisposeCallback(data) {
            // We have to mutate the data object to get data registered and cached
            data.prevExports = currentExports;
          }
        );
        module.hot.accept(
          /**
           * An error handler to allow self-recovering behaviours.
           * @param {Error} error An error occurred during evaluation of a module.
           * @returns {void}
           */
          function hotErrorHandler(error) {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.handleRuntimeError(error);
            }
    
            if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
              if (window.onHotAcceptError) {
                window.onHotAcceptError(error.message);
              }
            }
    
            __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
          }
        );
    
        if (isHotUpdate) {
          if (
            __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
            __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
          ) {
            module.hot.invalidate();
          } else {
            __react_refresh_utils__.enqueueUpdate(
              /**
               * A function to dismiss the error overlay after performing React refresh.
               * @returns {void}
               */
              function updateCallback() {
                if (
                  typeof __react_refresh_error_overlay__ !== 'undefined' &&
                  __react_refresh_error_overlay__
                ) {
                  __react_refresh_error_overlay__.clearRuntimeErrors();
                }
              }
            );
          }
        }
      } else {
        if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
          module.hot.invalidate();
        }
      }
    }
    /* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))
    
    /***/ }),
    
    /***/ "./src/components/AppLanguage.jsx":
    /*!****************************************!*\
      !*** ./src/components/AppLanguage.jsx ***!
      \****************************************/
    /*! exports provided: default */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    __webpack_require__.r(__webpack_exports__);
    /* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
    __webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
    __webpack_require__.$Refresh$.setup(module.i);
    
    
    
    function AppLanguage(language) {
      const dir = language === "ar" ? "rtl" : "ltr";
      document.documentElement.dir = dir;
    }
    
    _c = AppLanguage;
    /* harmony default export */ __webpack_exports__["default"] = (AppLanguage);
    
    var _c;
    
    __webpack_require__.$Refresh$.register(_c, "AppLanguage");
    
    const currentExports = __react_refresh_utils__.getModuleExports(module.i);
    __react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);
    
    if (true) {
      const isHotUpdate = !!module.hot.data;
      const prevExports = isHotUpdate ? module.hot.data.prevExports : null;
    
      if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
        module.hot.dispose(
          /**
           * A callback to performs a full refresh if React has unrecoverable errors,
           * and also caches the to-be-disposed module.
           * @param {*} data A hot module data object from Webpack HMR.
           * @returns {void}
           */
          function hotDisposeCallback(data) {
            // We have to mutate the data object to get data registered and cached
            data.prevExports = currentExports;
          }
        );
        module.hot.accept(
          /**
           * An error handler to allow self-recovering behaviours.
           * @param {Error} error An error occurred during evaluation of a module.
           * @returns {void}
           */
          function hotErrorHandler(error) {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.handleRuntimeError(error);
            }
    
            if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
              if (window.onHotAcceptError) {
                window.onHotAcceptError(error.message);
              }
            }
    
            __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
          }
        );
    
        if (isHotUpdate) {
          if (
            __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
            __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
          ) {
            module.hot.invalidate();
          } else {
            __react_refresh_utils__.enqueueUpdate(
              /**
               * A function to dismiss the error overlay after performing React refresh.
               * @returns {void}
               */
              function updateCallback() {
                if (
                  typeof __react_refresh_error_overlay__ !== 'undefined' &&
                  __react_refresh_error_overlay__
                ) {
                  __react_refresh_error_overlay__.clearRuntimeErrors();
                }
              }
            );
          }
        }
      } else {
        if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
          module.hot.invalidate();
        }
      }
    }
    /* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))
    
    /***/ }),
    
    /***/ "./src/components/Appointment.jsx":
    /*!****************************************!*\
      !*** ./src/components/Appointment.jsx ***!
      \****************************************/
    /*! exports provided: default */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    __webpack_require__.r(__webpack_exports__);
    /* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
    /* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
    /* harmony import */ var react_select__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-select */ "./node_modules/react-select/dist/react-select.esm.js");
    /* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! date-fns */ "./node_modules/date-fns/esm/index.js");
    /* harmony import */ var _date_io_date_fns__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @date-io/date-fns */ "./node_modules/@date-io/date-fns/build/index.esm.js");
    /* harmony import */ var _material_ui_pickers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/pickers */ "./node_modules/@material-ui/pickers/esm/index.js");
    /* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
    /* harmony import */ var react_toast_notifications__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-toast-notifications */ "./node_modules/react-toast-notifications/dist/index.js");
    /* harmony import */ var react_toast_notifications__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_toast_notifications__WEBPACK_IMPORTED_MODULE_7__);
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__);
    __webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
    __webpack_require__.$Refresh$.setup(module.i);
    
    var _jsxFileName = "/home/mounika/Desktop/hakeem-app/src/components/Appointment.jsx",
        _s = __webpack_require__.$Refresh$.signature();
    
    
    
    
    
    
    
    
    
    
    const slots = [{
      id: "1",
      value: "10:00"
    }, {
      id: "2",
      value: "10:30"
    }, {
      id: "3",
      value: "11:00"
    }, {
      id: "4",
      value: "11:30"
    }, {
      id: "5",
      value: "12:00"
    }, {
      id: "6",
      value: "12:30"
    }, {
      id: "7",
      value: "1:00"
    }, {
      id: "8",
      value: "3:00"
    },, {
      id: "9",
      value: "3:30"
    }, {
      id: "10",
      value: "4:00"
    }, {
      id: "11",
      value: "4:30"
    }, {
      id: "12",
      value: "5:00"
    },, {
      id: "13",
      value: "5:30"
    }, {
      id: "14",
      value: "6:00"
    }, {
      id: "15",
      value: "6:30"
    }, {
      id: "17",
      value: "7:00"
    }, {
      id: "18",
      value: "7:30"
    }, {
      id: "19",
      value: "8:00"
    }, {
      id: "20",
      value: "8:30"
    }, {
      id: "21",
      value: "9:00"
    }];
    
    function Appointment(props) {
      _s();
    
      const [selectedDate, setSelectedDate] = react__WEBPACK_IMPORTED_MODULE_0___default.a.useState(new Date());
      const [color, setColor] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])('');
      const {
        addToast
      } = Object(react_toast_notifications__WEBPACK_IMPORTED_MODULE_7__["useToasts"])();
      const [sloterror, setsloterror] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
      const [role, setROle] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(localStorage.getItem("role"));
    
      const handleDateChange = date => {
        setSelectedDate(date);
      };
    
      const handleNavigation = () => {
        props.history.push('/profile');
      };
    
      const changeColor = id => {
        setColor(id);
      };
    
      const validation = () => {
        if (color == '') {
          setsloterror(true);
          return false;
        } else {
          setsloterror(false);
          return true;
        }
      };
    
      const confirmAppointment = () => {
        let valid = validation();
    
        if (valid) {
          addToast('Your appointment request sent Successfully ', {
            appearance: 'success',
            autoDismiss: true,
            autoDismissTimeout: 1000,
            onDismiss: () => {
              props.history.push("/home");
            }
          });
        }
      };
    
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
        className: "userappointment-container",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
          className: "top-container",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("img", {
            src: "/static/img/arrow.svg",
            className: "arrow-image",
            onClick: handleNavigation
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 146,
            columnNumber: 17
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("img", {
            src: "/static/img/share.svg",
            className: "share-image"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 147,
            columnNumber: 17
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 145,
          columnNumber: 13
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
          className: "top-header",
          children: props.label.appointment_appointment
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 149,
          columnNumber: 13
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
          className: "appointmentdate-container",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
            className: "date-label",
            children: props.label.appointment_selectdate
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 152,
            columnNumber: 17
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(_material_ui_pickers__WEBPACK_IMPORTED_MODULE_5__["MuiPickersUtilsProvider"], {
            utils: _date_io_date_fns__WEBPACK_IMPORTED_MODULE_4__["default"],
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(_material_ui_pickers__WEBPACK_IMPORTED_MODULE_5__["KeyboardDatePicker"], {
              disableToolbar: true,
              variant: "inline",
              format: "MM/dd/yyyy",
              margin: "normal",
              id: "date-picker-inline",
              label: "Choose Date",
              value: selectedDate,
              onChange: handleDateChange,
              KeyboardButtonProps: {
                'aria-label': 'change date'
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 154,
              columnNumber: 21
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 153,
            columnNumber: 17
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 150,
          columnNumber: 13
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
          className: "slots-container",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
            className: "slots-label",
            children: props.label.appointment_slot
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 170,
            columnNumber: 17
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
            className: "time-slot-set",
            children: slots.map(({
              value,
              id
            }) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
              style: {
                backgroundColor: color === id ? "#3acce1" : ""
              },
              onClick: () => changeColor(id),
              name: value,
              children: value
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 173,
              columnNumber: 25
            }, this))
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 171,
            columnNumber: 17
          }, this), sloterror === true ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
            className: "slot-error",
            children: [" ", props.label.appointment_slot_required]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 186,
            columnNumber: 39
          }, this) : "", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
            className: "submit-container",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_6__["Button"], {
              className: "submit-button",
              onClick: confirmAppointment,
              children: props.label.appointment_submit
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 189,
              columnNumber: 17
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 188,
            columnNumber: 17
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 169,
          columnNumber: 13
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 144,
        columnNumber: 9
      }, this);
    }
    
    _s(Appointment, "XIfrNTrIpqjvNLWVwa8y2Yfs72o=", false, function () {
      return [react_toast_notifications__WEBPACK_IMPORTED_MODULE_7__["useToasts"]];
    });
    
    _c = Appointment;
    /* harmony default export */ __webpack_exports__["default"] = (_c2 = Object(react_router_dom__WEBPACK_IMPORTED_MODULE_1__["withRouter"])(Appointment));
    
    var _c, _c2;
    
    __webpack_require__.$Refresh$.register(_c, "Appointment");
    __webpack_require__.$Refresh$.register(_c2, "%default%");
    
    const currentExports = __react_refresh_utils__.getModuleExports(module.i);
    __react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);
    
    if (true) {
      const isHotUpdate = !!module.hot.data;
      const prevExports = isHotUpdate ? module.hot.data.prevExports : null;
    
      if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
        module.hot.dispose(
          /**
           * A callback to performs a full refresh if React has unrecoverable errors,
           * and also caches the to-be-disposed module.
           * @param {*} data A hot module data object from Webpack HMR.
           * @returns {void}
           */
          function hotDisposeCallback(data) {
            // We have to mutate the data object to get data registered and cached
            data.prevExports = currentExports;
          }
        );
        module.hot.accept(
          /**
           * An error handler to allow self-recovering behaviours.
           * @param {Error} error An error occurred during evaluation of a module.
           * @returns {void}
           */
          function hotErrorHandler(error) {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.handleRuntimeError(error);
            }
    
            if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
              if (window.onHotAcceptError) {
                window.onHotAcceptError(error.message);
              }
            }
    
            __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
          }
        );
    
        if (isHotUpdate) {
          if (
            __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
            __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
          ) {
            module.hot.invalidate();
          } else {
            __react_refresh_utils__.enqueueUpdate(
              /**
               * A function to dismiss the error overlay after performing React refresh.
               * @returns {void}
               */
              function updateCallback() {
                if (
                  typeof __react_refresh_error_overlay__ !== 'undefined' &&
                  __react_refresh_error_overlay__
                ) {
                  __react_refresh_error_overlay__.clearRuntimeErrors();
                }
              }
            );
          }
        }
      } else {
        if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
          module.hot.invalidate();
        }
      }
    }
    /* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))
    
    /***/ }),
    
    /***/ "./src/components/Bookings.jsx":
    /*!*************************************!*\
      !*** ./src/components/Bookings.jsx ***!
      \*************************************/
    /*! exports provided: default */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    __webpack_require__.r(__webpack_exports__);
    /* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
    /* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
    /* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
    /* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
    /* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/styles */ "./node_modules/@material-ui/core/esm/styles/index.js");
    /* harmony import */ var _material_ui_core_AppBar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/AppBar */ "./node_modules/@material-ui/core/esm/AppBar/index.js");
    /* harmony import */ var _material_ui_core_Tabs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/Tabs */ "./node_modules/@material-ui/core/esm/Tabs/index.js");
    /* harmony import */ var _material_ui_core_Tab__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/core/Tab */ "./node_modules/@material-ui/core/esm/Tab/index.js");
    /* harmony import */ var _material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @material-ui/core/Typography */ "./node_modules/@material-ui/core/esm/Typography/index.js");
    /* harmony import */ var _data_appointments_json__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../data/appointments.json */ "./src/data/appointments.json");
    var _data_appointments_json__WEBPACK_IMPORTED_MODULE_8___namespace = /*#__PURE__*/__webpack_require__.t(/*! ../data/appointments.json */ "./src/data/appointments.json", 1);
    /* harmony import */ var _material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @material-ui/core/Grid */ "./node_modules/@material-ui/core/esm/Grid/index.js");
    /* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__);
    __webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
    __webpack_require__.$Refresh$.setup(module.i);
    
    var _jsxFileName = "/home/mounika/Desktop/hakeem-app/src/components/Bookings.jsx",
        _s = __webpack_require__.$Refresh$.signature();
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    function TabPanel(props) {
      const {
        children,
        value,
        index,
        ...other
      } = props;
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
        role: "tabpanel",
        hidden: value !== index,
        id: `simple-tabpanel-${index}`,
        "aria-labelledby": `simple-tab-${index}`,
        ...other,
        children: value === index &&
        /*#__PURE__*/
        // <Box p={3}>
        Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_7__["default"], {
          children: children
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 28,
          columnNumber: 11
        }, this) // </Box>
    
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 7
      }, this);
    }
    
    _c = TabPanel;
    TabPanel.propTypes = {
      children: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.node,
      index: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.any.isRequired,
      value: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.any.isRequired
    };
    
    function a11yProps(index) {
      return {
        id: `simple-tab-${index}`,
        'aria-controls': `simple-tabpanel-${index}`
      };
    }
    
    const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_3__["makeStyles"])(theme => ({
      root: {
        flexGrow: 1,
        backgroundColor: theme.palette.background.paper
      }
    }));
    
    function Bookings(props) {
      _s();
    
      const classes = useStyles();
      const [value, setValue] = react__WEBPACK_IMPORTED_MODULE_0___default.a.useState(0);
      const [language, setLanguage] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(localStorage.getItem("language"));
    
      const handleChange = (event, newValue) => {
        setValue(newValue);
      };
    
      const getTodayDate = () => {
        const date = new Date();
        const formattedDate = date.toLocaleDateString('en-GB', {
          day: 'numeric',
          month: 'short',
          year: 'numeric'
        }).replace(/ /g, ' ');
        return formattedDate;
      };
    
      Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
        document.body.style.backgroundColor = "#fff";
      });
    
      const handleNavigation = () => {
        props.history.push('/dashboard');
      };
    
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
        className: "bookings-container",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
          className: "top-container",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
            src: "/static/img/arrow.svg",
            className: "arrow-image",
            onClick: handleNavigation
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 80,
            columnNumber: 9
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
            src: "/static/img/share.svg",
            className: "share-image"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 81,
            columnNumber: 9
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 79,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
          className: "bookingtop-header",
          children: props.label.bookings_appointments
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 83,
          columnNumber: 7
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
          className: "tabs-container",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_AppBar__WEBPACK_IMPORTED_MODULE_4__["default"], {
            position: "static",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Tabs__WEBPACK_IMPORTED_MODULE_5__["default"], {
              value: value,
              onChange: handleChange,
              variant: "fullWidth",
              "aria-label": "simple tabs example",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Tab__WEBPACK_IMPORTED_MODULE_6__["default"], {
                label: props.label.chat_today,
                ...a11yProps(0)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 88,
                columnNumber: 13
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Tab__WEBPACK_IMPORTED_MODULE_6__["default"], {
                label: props.label.chat_week,
                ...a11yProps(1)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 89,
                columnNumber: 13
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Tab__WEBPACK_IMPORTED_MODULE_6__["default"], {
                label: props.label.chat_month,
                ...a11yProps(2)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 90,
                columnNumber: 13
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 86,
              columnNumber: 11
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 85,
            columnNumber: 9
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(TabPanel, {
            value: value,
            index: 0,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
              children: _data_appointments_json__WEBPACK_IMPORTED_MODULE_8__.data.map((userchat, key) => {
                let result = getTodayDate();
    
                if (userchat.display === "today") {
                  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__["default"], {
                    container: true,
                    spacing: 1,
                    direction: "row",
                    justify: "flex-start",
                    alignItems: "flex-start",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__["default"], {
                        item: true,
                        xs: 12,
                        sm: 12,
                        md: 12,
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_10__["Card"], {
                          className: `bookingschat-card ${'bookingschat-card' + key}`,
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_10__["CardBody"], {
                            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                              className: "userappointment-basic-container",
                              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                className: "user-appointmentdate",
                                children: result + "," + userchat.time
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 115,
                                columnNumber: 27
                              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                className: "userappointment-speciality",
                                children: language === "ar" ? userchat.specialityAr : userchat.speciality
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 116,
                                columnNumber: 27
                              }, this)]
                            }, void 0, true, {
                              fileName: _jsxFileName,
                              lineNumber: 114,
                              columnNumber: 27
                            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("hr", {
                              className: "appointment-breakline"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 118,
                              columnNumber: 27
                            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                              className: "userappointment-details",
                              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                                src: userchat.image
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 121,
                                columnNumber: 29
                              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                children: language === "ar" ? userchat.nameAr : userchat.name
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 122,
                                columnNumber: 29
                              }, this)]
                            }, void 0, true, {
                              fileName: _jsxFileName,
                              lineNumber: 120,
                              columnNumber: 27
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 113,
                            columnNumber: 25
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 112,
                          columnNumber: 23
                        }, this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 111,
                        columnNumber: 21
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 110,
                      columnNumber: 19
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 102,
                    columnNumber: 17
                  }, this);
                }
              })
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 97,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 95,
            columnNumber: 9
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(TabPanel, {
            value: value,
            index: 1,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
              children: _data_appointments_json__WEBPACK_IMPORTED_MODULE_8__.data.map((userchat, key) => {
                let result = getTodayDate();
    
                if (userchat.display === "week" || userchat.display === "today") {
                  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__["default"], {
                    container: true,
                    spacing: 1,
                    direction: "row",
                    justify: "flex-start",
                    alignItems: "flex-start",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__["default"], {
                        item: true,
                        xs: 12,
                        sm: 12,
                        md: 12,
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_10__["Card"], {
                          className: `bookingschat-card ${'bookingschat-card' + key}`,
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_10__["CardBody"], {
                            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                              className: "userappointment-basic-container",
                              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                className: "user-appointmentdate",
                                children: userchat.display === "today" ? result + "," + userchat.time : userchat.date + "," + userchat.time
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 160,
                                columnNumber: 27
                              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                className: "userappointment-speciality",
                                children: language === "ar" ? userchat.specialityAr : userchat.speciality
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 161,
                                columnNumber: 27
                              }, this)]
                            }, void 0, true, {
                              fileName: _jsxFileName,
                              lineNumber: 159,
                              columnNumber: 27
                            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("hr", {
                              className: "appointment-breakline"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 163,
                              columnNumber: 27
                            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                              className: "userappointment-details",
                              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                                src: userchat.image
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 166,
                                columnNumber: 29
                              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                children: language === "ar" ? userchat.nameAr : userchat.name
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 167,
                                columnNumber: 29
                              }, this)]
                            }, void 0, true, {
                              fileName: _jsxFileName,
                              lineNumber: 165,
                              columnNumber: 27
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 158,
                            columnNumber: 23
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 157,
                          columnNumber: 23
                        }, this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 156,
                        columnNumber: 21
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 155,
                      columnNumber: 19
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 147,
                    columnNumber: 17
                  }, this);
                }
              })
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 142,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 140,
            columnNumber: 9
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(TabPanel, {
            value: value,
            index: 2,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
              children: _data_appointments_json__WEBPACK_IMPORTED_MODULE_8__.data.map((userchat, key) => {
                let result = getTodayDate();
                return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__["default"], {
                  container: true,
                  spacing: 1,
                  direction: "row",
                  justify: "flex-start",
                  alignItems: "flex-start",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__["default"], {
                      item: true,
                      xs: 12,
                      sm: 12,
                      md: 12,
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_10__["Card"], {
                        className: `bookingschat-card ${'bookingschat-card' + key}`,
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_10__["CardBody"], {
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                            className: "userappointment-basic-container",
                            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                              className: "user-appointmentdate",
                              children: userchat.display === "today" ? result + "," + userchat.time : userchat.date + "," + userchat.time
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 205,
                              columnNumber: 27
                            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                              className: "userappointment-speciality",
                              children: language === "ar" ? userchat.specialityAr : userchat.speciality
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 206,
                              columnNumber: 27
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 204,
                            columnNumber: 27
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("hr", {
                            className: "appointment-breakline"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 208,
                            columnNumber: 27
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                            className: "userappointment-details",
                            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                              src: userchat.image
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 211,
                              columnNumber: 29
                            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                              children: language === "ar" ? userchat.nameAr : userchat.name
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 212,
                              columnNumber: 29
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 210,
                            columnNumber: 27
                          }, this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 203,
                          columnNumber: 25
                        }, this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 202,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 201,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 200,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 192,
                  columnNumber: 19
                }, this);
              })
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 189,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 187,
            columnNumber: 9
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 84,
          columnNumber: 7
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 78,
        columnNumber: 9
      }, this);
    }
    
    _s(Bookings, "31vWglgck0BU/gHsMQ1R3xNxod0=", false, function () {
      return [useStyles];
    });
    
    _c2 = Bookings;
    /* harmony default export */ __webpack_exports__["default"] = (_c3 = Object(react_router_dom__WEBPACK_IMPORTED_MODULE_1__["withRouter"])(Bookings));
    
    var _c, _c2, _c3;
    
    __webpack_require__.$Refresh$.register(_c, "TabPanel");
    __webpack_require__.$Refresh$.register(_c2, "Bookings");
    __webpack_require__.$Refresh$.register(_c3, "%default%");
    
    const currentExports = __react_refresh_utils__.getModuleExports(module.i);
    __react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);
    
    if (true) {
      const isHotUpdate = !!module.hot.data;
      const prevExports = isHotUpdate ? module.hot.data.prevExports : null;
    
      if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
        module.hot.dispose(
          /**
           * A callback to performs a full refresh if React has unrecoverable errors,
           * and also caches the to-be-disposed module.
           * @param {*} data A hot module data object from Webpack HMR.
           * @returns {void}
           */
          function hotDisposeCallback(data) {
            // We have to mutate the data object to get data registered and cached
            data.prevExports = currentExports;
          }
        );
        module.hot.accept(
          /**
           * An error handler to allow self-recovering behaviours.
           * @param {Error} error An error occurred during evaluation of a module.
           * @returns {void}
           */
          function hotErrorHandler(error) {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.handleRuntimeError(error);
            }
    
            if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
              if (window.onHotAcceptError) {
                window.onHotAcceptError(error.message);
              }
            }
    
            __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
          }
        );
    
        if (isHotUpdate) {
          if (
            __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
            __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
          ) {
            module.hot.invalidate();
          } else {
            __react_refresh_utils__.enqueueUpdate(
              /**
               * A function to dismiss the error overlay after performing React refresh.
               * @returns {void}
               */
              function updateCallback() {
                if (
                  typeof __react_refresh_error_overlay__ !== 'undefined' &&
                  __react_refresh_error_overlay__
                ) {
                  __react_refresh_error_overlay__.clearRuntimeErrors();
                }
              }
            );
          }
        }
      } else {
        if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
          module.hot.invalidate();
        }
      }
    }
    /* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))
    
    /***/ }),
    
    /***/ "./src/components/BottomNavbar.jsx":
    /*!*****************************************!*\
      !*** ./src/components/BottomNavbar.jsx ***!
      \*****************************************/
    /*! exports provided: default */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    __webpack_require__.r(__webpack_exports__);
    /* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
    /* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
    __webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
    __webpack_require__.$Refresh$.setup(module.i);
    
    var _jsxFileName = "/home/mounika/Desktop/hakeem-app/src/components/BottomNavbar.jsx";
    
    
    
    
    const BottomNavbar = props => {
      const handleBottombar = navbarpath => {
        if (localStorage.getItem("role") === "guest" && (navbarpath === "/chat" || navbarpath === "/dashboard")) {} else {
          props.history.push(navbarpath);
        }
      };
    
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
        class: "bottomnavbar",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("a", {
          href: "#",
          onClick: () => handleBottombar('/home'),
          children: props.label.bottomnavbar_home
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 16,
          columnNumber: 5
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("a", {
          href: "#",
          children: props.label.bottomnavbar_media
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 17,
          columnNumber: 5
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("a", {
          href: "#",
          onClick: () => handleBottombar('/search'),
          children: props.label.bottomnavbar_search
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 18,
          columnNumber: 5
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("a", {
          href: "#",
          onClick: () => handleBottombar('/chat'),
          children: props.label.bottomnavbar_post
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 19,
          columnNumber: 5
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("a", {
          href: "#",
          onClick: () => handleBottombar('/dashboard'),
          children: props.label.bottomnavbar_profile
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 20,
          columnNumber: 5
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 5
      }, undefined);
    };
    
    _c = BottomNavbar;
    /* harmony default export */ __webpack_exports__["default"] = (_c2 = Object(react_router_dom__WEBPACK_IMPORTED_MODULE_1__["withRouter"])(BottomNavbar));
    
    var _c, _c2;
    
    __webpack_require__.$Refresh$.register(_c, "BottomNavbar");
    __webpack_require__.$Refresh$.register(_c2, "%default%");
    
    const currentExports = __react_refresh_utils__.getModuleExports(module.i);
    __react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);
    
    if (true) {
      const isHotUpdate = !!module.hot.data;
      const prevExports = isHotUpdate ? module.hot.data.prevExports : null;
    
      if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
        module.hot.dispose(
          /**
           * A callback to performs a full refresh if React has unrecoverable errors,
           * and also caches the to-be-disposed module.
           * @param {*} data A hot module data object from Webpack HMR.
           * @returns {void}
           */
          function hotDisposeCallback(data) {
            // We have to mutate the data object to get data registered and cached
            data.prevExports = currentExports;
          }
        );
        module.hot.accept(
          /**
           * An error handler to allow self-recovering behaviours.
           * @param {Error} error An error occurred during evaluation of a module.
           * @returns {void}
           */
          function hotErrorHandler(error) {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.handleRuntimeError(error);
            }
    
            if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
              if (window.onHotAcceptError) {
                window.onHotAcceptError(error.message);
              }
            }
    
            __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
          }
        );
    
        if (isHotUpdate) {
          if (
            __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
            __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
          ) {
            module.hot.invalidate();
          } else {
            __react_refresh_utils__.enqueueUpdate(
              /**
               * A function to dismiss the error overlay after performing React refresh.
               * @returns {void}
               */
              function updateCallback() {
                if (
                  typeof __react_refresh_error_overlay__ !== 'undefined' &&
                  __react_refresh_error_overlay__
                ) {
                  __react_refresh_error_overlay__.clearRuntimeErrors();
                }
              }
            );
          }
        }
      } else {
        if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
          module.hot.invalidate();
        }
      }
    }
    /* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))
    
    /***/ }),
    
    /***/ "./src/components/Chat.jsx":
    /*!*********************************!*\
      !*** ./src/components/Chat.jsx ***!
      \*********************************/
    /*! exports provided: default */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    __webpack_require__.r(__webpack_exports__);
    /* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
    /* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
    /* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
    /* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
    /* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/styles */ "./node_modules/@material-ui/core/esm/styles/index.js");
    /* harmony import */ var _material_ui_core_AppBar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/AppBar */ "./node_modules/@material-ui/core/esm/AppBar/index.js");
    /* harmony import */ var _material_ui_core_Tabs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/Tabs */ "./node_modules/@material-ui/core/esm/Tabs/index.js");
    /* harmony import */ var _material_ui_core_Tab__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/core/Tab */ "./node_modules/@material-ui/core/esm/Tab/index.js");
    /* harmony import */ var _material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @material-ui/core/Typography */ "./node_modules/@material-ui/core/esm/Typography/index.js");
    /* harmony import */ var _data_chatdata_json__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../data/chatdata.json */ "./src/data/chatdata.json");
    var _data_chatdata_json__WEBPACK_IMPORTED_MODULE_8___namespace = /*#__PURE__*/__webpack_require__.t(/*! ../data/chatdata.json */ "./src/data/chatdata.json", 1);
    /* harmony import */ var _material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @material-ui/core/Grid */ "./node_modules/@material-ui/core/esm/Grid/index.js");
    /* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__);
    __webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
    __webpack_require__.$Refresh$.setup(module.i);
    
    var _jsxFileName = "/home/mounika/Desktop/hakeem-app/src/components/Chat.jsx",
        _s = __webpack_require__.$Refresh$.signature();
    
    
    
    
    
    
    
    
    
    
    
     // import Box from '@material-ui/core/Box';
    
    
    
    function TabPanel(props) {
      const {
        children,
        value,
        index,
        ...other
      } = props;
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
        role: "tabpanel",
        hidden: value !== index,
        id: `simple-tabpanel-${index}`,
        "aria-labelledby": `simple-tab-${index}`,
        ...other,
        children: value === index &&
        /*#__PURE__*/
        // <Box p={3}>
        Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_7__["default"], {
          children: children
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 31,
          columnNumber: 9
        }, this) // </Box>
    
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 22,
        columnNumber: 5
      }, this);
    }
    
    _c = TabPanel;
    TabPanel.propTypes = {
      children: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.node,
      index: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.any.isRequired,
      value: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.any.isRequired
    };
    
    function a11yProps(index) {
      return {
        id: `simple-tab-${index}`,
        'aria-controls': `simple-tabpanel-${index}`
      };
    }
    
    const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_3__["makeStyles"])(theme => ({
      root: {
        flexGrow: 1,
        backgroundColor: theme.palette.background.paper
      }
    }));
    
    function Chat(props) {
      _s();
    
      Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
        document.body.style.backgroundColor = "#fff";
      });
    
      const handleNavigation = () => {
        props.history.push('/dashboard');
      };
    
      const classes = useStyles();
      const [value, setValue] = react__WEBPACK_IMPORTED_MODULE_0___default.a.useState(0);
      const [language, setLanguage] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(localStorage.getItem("language"));
    
      const handleChange = (event, newValue) => {
        setValue(newValue);
      };
    
      const getTodayDate = () => {
        let today = new Date();
        let dd = String(today.getDate()).padStart(2, '0');
        let mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
    
        let yyyy = today.getFullYear();
        return {
          day: dd,
          month: mm,
          year: yyyy
        };
      };
    
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
        className: "userchat-container",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
          className: "top-container",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
            src: "/static/img/arrow.svg",
            className: "arrow-image",
            onClick: handleNavigation
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 87,
            columnNumber: 9
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
            src: "/static/img/share.svg",
            className: "share-image"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 88,
            columnNumber: 9
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 86,
          columnNumber: 7
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
          className: "top-header",
          children: props.label.chat_post
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 90,
          columnNumber: 7
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
          className: "tabs-container",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_AppBar__WEBPACK_IMPORTED_MODULE_4__["default"], {
            position: "static",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Tabs__WEBPACK_IMPORTED_MODULE_5__["default"], {
              value: value,
              onChange: handleChange,
              variant: "fullWidth",
              "aria-label": "simple tabs example",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Tab__WEBPACK_IMPORTED_MODULE_6__["default"], {
                label: props.label.chat_today,
                ...a11yProps(0)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 95,
                columnNumber: 13
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Tab__WEBPACK_IMPORTED_MODULE_6__["default"], {
                label: props.label.chat_week,
                ...a11yProps(1)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 96,
                columnNumber: 13
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Tab__WEBPACK_IMPORTED_MODULE_6__["default"], {
                label: props.label.chat_month,
                ...a11yProps(2)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 97,
                columnNumber: 13
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 93,
              columnNumber: 11
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 92,
            columnNumber: 9
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(TabPanel, {
            value: value,
            index: 0,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
              children: _data_chatdata_json__WEBPACK_IMPORTED_MODULE_8__.data.map((userchat, key) => {
                let result = getTodayDate();
                let userday = new Date(userchat.date).getDate();
    
                if (result.day == userday || key === 0 || key == 4 || key == 10) {
                  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__["default"], {
                    container: true,
                    spacing: 1,
                    direction: "row",
                    justify: "flex-start",
                    alignItems: "flex-start",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__["default"], {
                        item: true,
                        xs: 12,
                        sm: 12,
                        md: 12,
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_10__["Card"], {
                          className: `chat-card ${'chat-card' + key}`,
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_10__["CardBody"], {
                            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                              className: "expand",
                              src: "/static/img/angle-down.svg"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 122,
                              columnNumber: 25
                            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                              className: "user-basic-container",
                              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                className: "user-profilepic",
                                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                                  src: userchat.image
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 124,
                                  columnNumber: 60
                                }, this)
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 124,
                                columnNumber: 27
                              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                className: "user-name",
                                children: [language === "ar" ? userchat.nameAr : userchat.name, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                  className: "message-time",
                                  children: language === "ar" ? userchat.timeAr : userchat.time
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 125,
                                  columnNumber: 104
                                }, this)]
                              }, void 0, true, {
                                fileName: _jsxFileName,
                                lineNumber: 125,
                                columnNumber: 27
                              }, this)]
                            }, void 0, true, {
                              fileName: _jsxFileName,
                              lineNumber: 123,
                              columnNumber: 27
                            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                              className: "user-message",
                              children: language === "ar" ? userchat.messageAr : userchat.message
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 127,
                              columnNumber: 27
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 121,
                            columnNumber: 25
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_10__["CardFooter"], {
                            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("hr", {
                              className: "userchat-breakline"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 132,
                              columnNumber: 27
                            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                              src: "/static/img/usershare.svg",
                              className: "usershare-image"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 133,
                              columnNumber: 27
                            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                              className: "bottom-chatcontainer",
                              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                children: userchat.messagescount
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 135,
                                columnNumber: 31
                              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                                className: "userchat-icon",
                                src: "/static/img/userchat.svg"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 136,
                                columnNumber: 31
                              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                children: props.label.chat_patient
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 137,
                                columnNumber: 31
                              }, this), userchat.messagescount === "2" || userchat.messagescount === "1" ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                                className: "favourite-icon",
                                src: "/static/img/userheart.svg"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 138,
                                columnNumber: 97
                              }, this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                                className: "favourite-icon",
                                src: "/static/img/heart.svg"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 139,
                                columnNumber: 31
                              }, this)]
                            }, void 0, true, {
                              fileName: _jsxFileName,
                              lineNumber: 134,
                              columnNumber: 27
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 131,
                            columnNumber: 25
                          }, this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 120,
                          columnNumber: 23
                        }, this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 119,
                        columnNumber: 21
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 118,
                      columnNumber: 19
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 110,
                    columnNumber: 17
                  }, this);
                }
              })
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 104,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 102,
            columnNumber: 9
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(TabPanel, {
            value: value,
            index: 1,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
              children: _data_chatdata_json__WEBPACK_IMPORTED_MODULE_8__.data.map((userchat, key) => {
                let userday = new Date(userchat.date).getDate();
                let curr = new Date();
                let firstday = new Date(curr.setDate(curr.getDate() - curr.getDay())).getDate();
                let lastday = new Date(curr.setDate(curr.getDate() - curr.getDay() + 6)).getDate();
    
                if (userday >= firstday && userday <= lastday || key === 0) {
                  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__["default"], {
                    container: true,
                    spacing: 1,
                    direction: "row",
                    justify: "flex-start",
                    alignItems: "flex-start",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__["default"], {
                        item: true,
                        xs: 12,
                        sm: 12,
                        md: 12,
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_10__["Card"], {
                          className: `chat-card ${'chat-card' + key}`,
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_10__["CardBody"], {
                            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                              className: "expand",
                              src: "/static/img/angle-down.svg"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 176,
                              columnNumber: 25
                            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                              className: "user-basic-container",
                              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                className: "user-profilepic",
                                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                                  src: userchat.image
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 178,
                                  columnNumber: 60
                                }, this)
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 178,
                                columnNumber: 27
                              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                className: "user-name",
                                children: [language === "ar" ? userchat.nameAr : userchat.name, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                  className: "message-time",
                                  children: language === "ar" ? userchat.timeAr : userchat.time
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 179,
                                  columnNumber: 105
                                }, this)]
                              }, void 0, true, {
                                fileName: _jsxFileName,
                                lineNumber: 179,
                                columnNumber: 27
                              }, this)]
                            }, void 0, true, {
                              fileName: _jsxFileName,
                              lineNumber: 177,
                              columnNumber: 27
                            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                              className: "user-message",
                              children: language === "ar" ? userchat.messageAr : userchat.message
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 181,
                              columnNumber: 27
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 175,
                            columnNumber: 25
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_10__["CardFooter"], {
                            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("hr", {
                              className: "userchat-breakline"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 186,
                              columnNumber: 27
                            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                              src: "/static/img/usershare.svg",
                              className: "usershare-image"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 187,
                              columnNumber: 27
                            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                              className: "bottom-chatcontainer",
                              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                children: userchat.messagescount
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 189,
                                columnNumber: 31
                              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                                className: "userchat-icon",
                                src: "/static/img/userchat.svg"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 190,
                                columnNumber: 31
                              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                children: props.label.chat_patient
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 191,
                                columnNumber: 31
                              }, this), userchat.messagescount === "2" || userchat.messagescount === "1" ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                                className: "favourite-icon",
                                src: "/static/img/userheart.svg"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 192,
                                columnNumber: 97
                              }, this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                                className: "favourite-icon",
                                src: "/static/img/heart.svg"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 193,
                                columnNumber: 31
                              }, this)]
                            }, void 0, true, {
                              fileName: _jsxFileName,
                              lineNumber: 188,
                              columnNumber: 27
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 185,
                            columnNumber: 25
                          }, this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 174,
                          columnNumber: 23
                        }, this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 173,
                        columnNumber: 21
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 172,
                      columnNumber: 19
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 164,
                    columnNumber: 17
                  }, this);
                }
              })
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 156,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 154,
            columnNumber: 9
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(TabPanel, {
            value: value,
            index: 2,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
              children: _data_chatdata_json__WEBPACK_IMPORTED_MODULE_8__.data.map((userchat, key) => {
                let result = getTodayDate();
                let usermonth = new Date(userchat.date).getMonth() + 1;
    
                if (result.month == usermonth || key === 0) {
                  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__["default"], {
                    container: true,
                    spacing: 1,
                    direction: "row",
                    justify: "flex-start",
                    alignItems: "flex-start",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__["default"], {
                        item: true,
                        xs: 12,
                        sm: 12,
                        md: 12,
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_10__["Card"], {
                          className: `chat-card ${'chat-card' + key}`,
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_10__["CardBody"], {
                            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                              className: "expand",
                              src: "/static/img/angle-down.svg"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 228,
                              columnNumber: 27
                            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                              className: "user-basic-container",
                              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                className: "user-profilepic",
                                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                                  src: userchat.image
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 230,
                                  columnNumber: 62
                                }, this)
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 230,
                                columnNumber: 29
                              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                className: "user-name",
                                children: [language === "ar" ? userchat.nameAr : userchat.name, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                  className: "message-time",
                                  children: language === "ar" ? userchat.timeAr : userchat.time
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 231,
                                  columnNumber: 106
                                }, this)]
                              }, void 0, true, {
                                fileName: _jsxFileName,
                                lineNumber: 231,
                                columnNumber: 29
                              }, this)]
                            }, void 0, true, {
                              fileName: _jsxFileName,
                              lineNumber: 229,
                              columnNumber: 29
                            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                              className: "user-message",
                              children: language === "ar" ? userchat.messageAr : userchat.message
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 233,
                              columnNumber: 29
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 227,
                            columnNumber: 27
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_10__["CardFooter"], {
                            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("hr", {
                              className: "userchat-breakline"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 238,
                              columnNumber: 29
                            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                              src: "/static/img/usershare.svg",
                              className: "usershare-image"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 239,
                              columnNumber: 29
                            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                              className: "bottom-chatcontainer",
                              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                children: userchat.messagescount
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 241,
                                columnNumber: 33
                              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                                className: "userchat-icon",
                                src: "/static/img/userchat.svg"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 242,
                                columnNumber: 33
                              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                children: props.label.chat_patient
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 243,
                                columnNumber: 33
                              }, this), userchat.messagescount === "2" || userchat.messagescount === "1" ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                                className: "favourite-icon",
                                src: "/static/img/userheart.svg"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 244,
                                columnNumber: 99
                              }, this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                                className: "favourite-icon",
                                src: "/static/img/heart.svg"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 245,
                                columnNumber: 33
                              }, this)]
                            }, void 0, true, {
                              fileName: _jsxFileName,
                              lineNumber: 240,
                              columnNumber: 29
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 237,
                            columnNumber: 27
                          }, this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 226,
                          columnNumber: 25
                        }, this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 225,
                        columnNumber: 23
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 224,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 216,
                    columnNumber: 19
                  }, this);
                }
              })
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 211,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 209,
            columnNumber: 9
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 91,
          columnNumber: 7
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 85,
        columnNumber: 5
      }, this);
    }
    
    _s(Chat, "hbqJ9aESUZh3oB4HI36UKIMoArM=", false, function () {
      return [useStyles];
    });
    
    _c2 = Chat;
    /* harmony default export */ __webpack_exports__["default"] = (_c3 = Object(react_router_dom__WEBPACK_IMPORTED_MODULE_1__["withRouter"])(Chat));
    
    var _c, _c2, _c3;
    
    __webpack_require__.$Refresh$.register(_c, "TabPanel");
    __webpack_require__.$Refresh$.register(_c2, "Chat");
    __webpack_require__.$Refresh$.register(_c3, "%default%");
    
    const currentExports = __react_refresh_utils__.getModuleExports(module.i);
    __react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);
    
    if (true) {
      const isHotUpdate = !!module.hot.data;
      const prevExports = isHotUpdate ? module.hot.data.prevExports : null;
    
      if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
        module.hot.dispose(
          /**
           * A callback to performs a full refresh if React has unrecoverable errors,
           * and also caches the to-be-disposed module.
           * @param {*} data A hot module data object from Webpack HMR.
           * @returns {void}
           */
          function hotDisposeCallback(data) {
            // We have to mutate the data object to get data registered and cached
            data.prevExports = currentExports;
          }
        );
        module.hot.accept(
          /**
           * An error handler to allow self-recovering behaviours.
           * @param {Error} error An error occurred during evaluation of a module.
           * @returns {void}
           */
          function hotErrorHandler(error) {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.handleRuntimeError(error);
            }
    
            if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
              if (window.onHotAcceptError) {
                window.onHotAcceptError(error.message);
              }
            }
    
            __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
          }
        );
    
        if (isHotUpdate) {
          if (
            __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
            __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
          ) {
            module.hot.invalidate();
          } else {
            __react_refresh_utils__.enqueueUpdate(
              /**
               * A function to dismiss the error overlay after performing React refresh.
               * @returns {void}
               */
              function updateCallback() {
                if (
                  typeof __react_refresh_error_overlay__ !== 'undefined' &&
                  __react_refresh_error_overlay__
                ) {
                  __react_refresh_error_overlay__.clearRuntimeErrors();
                }
              }
            );
          }
        }
      } else {
        if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
          module.hot.invalidate();
        }
      }
    }
    /* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))
    
    /***/ }),
    
    /***/ "./src/components/Dashboard.jsx":
    /*!**************************************!*\
      !*** ./src/components/Dashboard.jsx ***!
      \**************************************/
    /*! exports provided: default */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    __webpack_require__.r(__webpack_exports__);
    /* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
    /* harmony import */ var _MapContainer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./MapContainer */ "./src/components/MapContainer.js");
    /* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
    /* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
    /* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_3__);
    /* harmony import */ var _ImageCarousel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ImageCarousel */ "./src/components/ImageCarousel.jsx");
    /* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__);
    __webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
    __webpack_require__.$Refresh$.setup(module.i);
    
    var _jsxFileName = "/home/mounika/Desktop/hakeem-app/src/components/Dashboard.jsx",
        _s = __webpack_require__.$Refresh$.signature();
    
    
    
     // import { Slide, Zoom } from 'react-slideshow-image';
    // import 'react-slideshow-image/dist/styles.css';
    
    
    
    
    
    
    function Dashboard(props) {
      _s();
    
      const [data, setData] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])([]);
      const [searchBox, showSearchBox] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
      const [openMap, setOpenMap] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
      const [showDashboard, setShowDashboard] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
      const [language, setLanguage] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(localStorage.getItem("language"));
    
      const getClinics = () => {
        let url = '/api/getclinics';
        axios__WEBPACK_IMPORTED_MODULE_3___default.a.get(url, {
          auth: {
            username: "admin",
            password: "Hakeem@738"
          }
        }).then(response => {
          setData(response.data.rows);
        }).catch(err => {
          console.log(err);
        });
      };
    
      Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
        getClinics();
      }, []);
      Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
        setTimeout(() => {
          getClinics();
        }, 100);
      }, []);
      Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
        document.body.style.backgroundColor = "#2A2E43";
      });
    
      const handleHome = () => {
        showSearchBox(false);
        setOpenMap(false);
      };
    
      const handleSearch = () => {
        showSearchBox(true);
      };
    
      const handleDashboard = () => {
        showSearchBox(false);
        setOpenMap(false);
        setShowDashboard(true);
      };
    
      const handleChat = () => {
        props.history.push('/chat');
      };
    
      const handleLogin = () => {
        localStorage.removeItem("language");
        localStorage.removeItem("loggedin");
        localStorage.removeItem("guest");
        window.location.href = "/";
      };
    
      const handleBookings = () => {
        props.history.push('/appointments');
      };
    
      const handleProfileInfo = () => {
        props.history.push('/profilesettings');
      };
    
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
        className: "dashboard-container",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(_ImageCarousel__WEBPACK_IMPORTED_MODULE_4__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 81,
          columnNumber: 7
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
          className: "user-details",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_2__["Card"], {
            className: "user-card",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_2__["CardBody"], {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                className: "userdetails-card",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                  className: "userdetails-image-container",
                  children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("img", {
                    src: "/static/img/patient.png"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 86,
                    columnNumber: 59
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 86,
                  columnNumber: 13
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                  className: "usercard-data",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                    className: "user-speciality",
                    children: [" ", props.label.dashboard_specility, "   "]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 88,
                    columnNumber: 15
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                    className: "",
                    children: [props.label.dashboard_name, " "]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 89,
                    columnNumber: 15
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("hr", {
                    className: "user-break-line"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 90,
                    columnNumber: 15
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                    children: props.label.dashboard_board
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 91,
                    columnNumber: 15
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                    children: props.label.dashboard_info
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 94,
                    columnNumber: 15
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                    children: props.label.dashboard_info
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 95,
                    columnNumber: 15
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                    children: props.label.dashboard_info
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 96,
                    columnNumber: 15
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                    children: props.label.dashboard_info
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 97,
                    columnNumber: 15
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                    children: props.label.dashboard_info
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 98,
                    columnNumber: 15
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                    children: props.label.dashboard_info
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 99,
                    columnNumber: 15
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                    children: props.label.dashboard_info
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 100,
                    columnNumber: 15
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 87,
                  columnNumber: 13
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 85,
                columnNumber: 13
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 84,
              columnNumber: 11
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 83,
            columnNumber: 9
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 82,
          columnNumber: 7
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
          className: "user-options-container",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
            children: ["25", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
              className: "option-label",
              children: props.label.dashboard_patients
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 114,
              columnNumber: 23
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 114,
            columnNumber: 16
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("hr", {
            className: "option-break-line"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 115,
            columnNumber: 16
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
            children: ["150", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
              className: "option-label",
              children: props.label.dashboard_followers
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 116,
              columnNumber: 24
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 116,
            columnNumber: 16
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("hr", {
            className: "option-break-line"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 117,
            columnNumber: 16
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
            children: ["10", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
              className: "option-label",
              children: props.label.dashboard_posts
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 118,
              columnNumber: 22
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 118,
            columnNumber: 15
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 113,
          columnNumber: 13
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
          className: "user-features-container",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_2__["Container"], {
            className: "row-col-container",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_2__["Row"], {
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_2__["Col"], {
                xs: "4",
                sm: "4",
                className: "userchat-card",
                onClick: handleChat,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                  className: "chat-image-container",
                  children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("img", {
                    src: "/static/img/chat.svg"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 123,
                    columnNumber: 114
                  }, this), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                    children: props.label.dashboard_chat
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 123,
                    columnNumber: 149
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 123,
                  columnNumber: 75
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 123,
                columnNumber: 9
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_2__["Col"], {
                xs: "4",
                sm: "4",
                className: "userbooking-card",
                onClick: handleBookings,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                  className: "chat-image-container",
                  children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("img", {
                    src: "/static/img/calendar1.svg"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 124,
                    columnNumber: 121
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                    children: props.label.dashboard_bookings
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 124,
                    columnNumber: 159
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 124,
                  columnNumber: 82
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 124,
                columnNumber: 9
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_2__["Col"], {
                xs: "4",
                sm: "4",
                className: "userpayments-card",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                  className: "chat-image-container",
                  children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("img", {
                    src: "/static/img/info.svg"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 125,
                    columnNumber: 97
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                    children: props.label.dashboard_payments
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 125,
                    columnNumber: 130
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 125,
                  columnNumber: 58
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 125,
                columnNumber: 9
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 122,
              columnNumber: 13
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_2__["Row"], {
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_2__["Col"], {
                xs: "4",
                sm: "4",
                className: "userprofile-card",
                onClick: handleProfileInfo,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                  className: "chat-image-container",
                  children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("img", {
                    src: "/static/img/user.svg"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 128,
                    columnNumber: 124
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                    children: props.label.dashboard_profileinfo
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 128,
                    columnNumber: 157
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 128,
                  columnNumber: 85
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 128,
                columnNumber: 9
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_2__["Col"], {
                xs: "4",
                sm: "4",
                className: "useraccount-card",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                  className: "chat-image-container",
                  children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("img", {
                    src: "/static/img/info.svg"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 129,
                    columnNumber: 96
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                    children: props.label.dashboard_account
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 129,
                    columnNumber: 129
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 129,
                  columnNumber: 57
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 129,
                columnNumber: 9
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_2__["Col"], {
                xs: "4",
                sm: "4",
                className: "userlogin-card",
                onClick: handleLogin,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                  className: "chat-image-container",
                  children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("img", {
                    src: "/static/img/logout.svg"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 130,
                    columnNumber: 116
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                    children: props.label.dashboard_login
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 130,
                    columnNumber: 151
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 130,
                  columnNumber: 77
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 130,
                columnNumber: 9
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 127,
              columnNumber: 7
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 121,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 120,
          columnNumber: 13
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 80,
        columnNumber: 5
      }, this);
    }
    
    _s(Dashboard, "jS02UBM0ZNRjUQdQvbtxi1gjKLE=");
    
    _c = Dashboard;
    /* harmony default export */ __webpack_exports__["default"] = (_c2 = Object(react_router_dom__WEBPACK_IMPORTED_MODULE_5__["withRouter"])(Dashboard));
    
    var _c, _c2;
    
    __webpack_require__.$Refresh$.register(_c, "Dashboard");
    __webpack_require__.$Refresh$.register(_c2, "%default%");
    
    const currentExports = __react_refresh_utils__.getModuleExports(module.i);
    __react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);
    
    if (true) {
      const isHotUpdate = !!module.hot.data;
      const prevExports = isHotUpdate ? module.hot.data.prevExports : null;
    
      if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
        module.hot.dispose(
          /**
           * A callback to performs a full refresh if React has unrecoverable errors,
           * and also caches the to-be-disposed module.
           * @param {*} data A hot module data object from Webpack HMR.
           * @returns {void}
           */
          function hotDisposeCallback(data) {
            // We have to mutate the data object to get data registered and cached
            data.prevExports = currentExports;
          }
        );
        module.hot.accept(
          /**
           * An error handler to allow self-recovering behaviours.
           * @param {Error} error An error occurred during evaluation of a module.
           * @returns {void}
           */
          function hotErrorHandler(error) {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.handleRuntimeError(error);
            }
    
            if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
              if (window.onHotAcceptError) {
                window.onHotAcceptError(error.message);
              }
            }
    
            __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
          }
        );
    
        if (isHotUpdate) {
          if (
            __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
            __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
          ) {
            module.hot.invalidate();
          } else {
            __react_refresh_utils__.enqueueUpdate(
              /**
               * A function to dismiss the error overlay after performing React refresh.
               * @returns {void}
               */
              function updateCallback() {
                if (
                  typeof __react_refresh_error_overlay__ !== 'undefined' &&
                  __react_refresh_error_overlay__
                ) {
                  __react_refresh_error_overlay__.clearRuntimeErrors();
                }
              }
            );
          }
        }
      } else {
        if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
          module.hot.invalidate();
        }
      }
    }
    /* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))
    
    /***/ }),
    
    /***/ "./src/components/Home.jsx":
    /*!*********************************!*\
      !*** ./src/components/Home.jsx ***!
      \*********************************/
    /*! exports provided: default */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    __webpack_require__.r(__webpack_exports__);
    /* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../App.css */ "./src/App.css");
    /* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_App_css__WEBPACK_IMPORTED_MODULE_0__);
    /* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
    /* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
    /* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
    /* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_4__);
    /* harmony import */ var _material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/Grid */ "./node_modules/@material-ui/core/esm/Grid/index.js");
    /* harmony import */ var react_toast_notifications__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-toast-notifications */ "./node_modules/react-toast-notifications/dist/index.js");
    /* harmony import */ var react_toast_notifications__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_toast_notifications__WEBPACK_IMPORTED_MODULE_6__);
    /* harmony import */ var react_select__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-select */ "./node_modules/react-select/dist/react-select.esm.js");
    /* harmony import */ var _AppLanguage__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./AppLanguage */ "./src/components/AppLanguage.jsx");
    /* harmony import */ var react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-spinners/ClipLoader */ "./node_modules/react-spinners/ClipLoader.js");
    /* harmony import */ var react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_9__);
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__);
    __webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
    __webpack_require__.$Refresh$.setup(module.i);
    
    var _jsxFileName = "/home/mounika/Desktop/hakeem-app/src/components/Home.jsx",
        _s = __webpack_require__.$Refresh$.signature();
    
    
    
    
    
    
    
    
    
    
    
    
    const initialState = {
      all: false,
      doctors: false,
      clinics: false
    };
    
    function Search(props) {
      _s();
    
      const [state, setState] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(initialState);
      const [language, setLanguage] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(localStorage.getItem("language"));
      const [clinicSpecialities, setClinicSpecialities] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])([]);
      const [doctorSpecialities, setDoctorSpecialities] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])([]);
      const [clinicspeciality, setClinicSpeciality] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(null);
      const [doctorspeciality, setDoctorSpeciality] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(null);
      const [filter, showFilter] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);
      const [saveFilter, setSaveFilter] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);
      const [searchData, setSearchData] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])([]);
      const [allData, setAllData] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(true);
      const [speciality, setSpeciality] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(null);
      const [clinicLocations, setClinicLocations] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])([]);
      const [doctorLocations, setDoctorLocations] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])([]);
      const [clinicLocation, setClinicLocation] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(null);
      const [doctorLocation, setDoctorLocation] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(null);
      const [location, setLocation] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(null);
      const [openMap, setOpenMap] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);
      Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(() => {
        document.body.style.backgroundColor = "#fff";
        Object(_AppLanguage__WEBPACK_IMPORTED_MODULE_8__["default"])(localStorage.getItem("language"));
      });
    
      const getClinics = () => {
        let url = '/api/getclinics';
        axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url).then(response => {
          setSearchData(response.data.rows);
        }).catch(err => {
          console.log(err);
        });
      };
    
      const getDoctors = () => {
        let url = '/api/getdoctors';
        axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url).then(response => {
          setSearchData(response.data.rows);
        }).catch(err => {
          console.log(err);
        });
      };
    
      const getClinicSpecialities = () => {
        let data = [];
        let url = '/api/clinicspecialities/' + language;
        axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url).then(response => {
          response.data.rows.map(clinicsdata => {
            data.push({
              value: clinicsdata.key,
              label: clinicsdata.key
            });
          });
    
          if (data.length !== 0) {
            setClinicSpecialities(data);
          }
        }).catch(err => {
          console.log(err);
        });
      };
    
      const getDoctorSpecialities = () => {
        let data = [];
        let url = '/api/doctorspecialities/' + language;
        axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url, {
          auth: {
            username: "admin",
            password: "Hakeem@738"
          }
        }).then(response => {
          response.data.rows.map(doctordata => {
            data.push({
              value: doctordata.key,
              label: doctordata.key
            });
          });
    
          if (data.length !== 0) {
            setDoctorSpecialities(data);
          }
        }).catch(err => {
          console.log(err);
        });
      };
    
      const getClinicLocations = () => {
        let data = [];
        let url = '/api/cliniclocations/' + language;
        axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url).then(response => {
          response.data.rows.map(clinicsdata => {
            data.push({
              value: clinicsdata.key,
              label: clinicsdata.key
            });
          });
    
          if (data.length !== 0) {
            setClinicLocations(data);
          }
        }).catch(err => {
          console.log(err);
        });
      };
    
      const getDoctorLocations = () => {
        let data = [];
        let url = '/api/doctorlocations/' + language;
        axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url).then(response => {
          response.data.rows.map(doctordata => {
            data.push({
              value: doctordata.key,
              label: doctordata.key
            });
          });
    
          if (data.length !== 0) {
            setDoctorLocations(data);
          }
        }).catch(err => {
          console.log(err);
        });
      };
    
      const handleClinicSpeciality = clinicspeciality => {
        setClinicSpeciality(clinicspeciality);
        setSpeciality(clinicspeciality);
      };
    
      const handleDoctorSpeciality = doctorspeciality => {
        setDoctorSpeciality(doctorspeciality);
        setSpeciality(doctorspeciality);
      };
    
      const handleClinicLocation = cliniclocation => {
        setClinicLocation(cliniclocation);
        setLocation(cliniclocation);
      };
    
      const handleDoctorLocation = doctorlocation => {
        setDoctorLocation(doctorlocation);
        setLocation(doctorlocation);
      };
    
      Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(() => {
        getAllData();
        getClinicSpecialities();
        getClinicLocations();
        getDoctorSpecialities();
        getDoctorLocations();
      }, []);
    
      const filterSearch = () => {
        showFilter(!filter);
      };
    
      const handleFirstFilter = e => {
        // showFilter(false);
        if (e.target.name === "all") {
          setState({ ...state,
            all: e.target.checked,
            doctors: e.target.checked,
            clinics: e.target.checked
          });
        } else if (e.target.name === "doctors") {
          setState({ ...state,
            doctors: e.target.checked,
            clinics: false,
            all: false
          });
        } else if (e.target.name === "clinics") {
          setState({ ...state,
            clinics: e.target.checked,
            doctors: false,
            all: false
          });
        }
      };
    
      const getAllData = () => {
        let url = '/api/getalldata';
        axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url).then(response => {
          setSearchData(response.data.rows);
        }).catch(err => {
          console.log(err);
        });
      };
    
      const ApplyFilter = () => {
        setSaveFilter(true);
        showFilter(false);
    
        if (state.all) {
          getAllData();
          setSpeciality(null);
          setLocation(null);
        } else if (state.doctors === true) {
          if (doctorspeciality !== null && doctorLocation === null) {
            let url = '/api/doctorsdatabyspeciality/' + language + "/" + doctorspeciality.value;
            axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url).then(response => {
              if (response.data.rows.length === 0) {
                setSearchData({
                  nodata: "nodata"
                });
              } else {
                setSearchData(response.data.rows);
                setSpeciality(doctorspeciality);
                setLocation(null);
              }
            }).catch(err => {
              console.log(err);
            });
          } else if (doctorLocation !== null && doctorspeciality === null) {
            let url = '/api/doctorsdatabylocation/' + language + "/" + doctorLocation.value;
            axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url).then(response => {
              if (response.data.rows.length === 0) {
                setSearchData({
                  nodata: "nodata"
                });
              } else {
                setSearchData(response.data.rows);
                setLocation(doctorLocation);
                setSpeciality(null);
              }
            }).catch(err => {
              console.log(err);
            });
          } else if (doctorspeciality !== null && doctorLocation !== null) {
            let url = '/api/doctorsdatabyspecialityandlocation/' + language + "/" + doctorspeciality.value + "/" + doctorLocation.value;
            axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url).then(response => {
              if (response.data.rows.length === 0) {
                setSearchData({
                  nodata: "nodata"
                });
              } else {
                setSearchData(response.data.rows);
                setLocation(doctorLocation);
                setSpeciality(doctorspeciality);
              }
            }).catch(err => {
              console.log(err);
            });
          } else if (doctorspeciality === null) {
            getDoctors();
            setSpeciality(null);
          } else if (doctorLocation === null) {
            getDoctors();
            setLocation(null);
          } else if (doctorspeciality === null || doctorLocation === null) {
            getDoctors();
            setLocation(null);
            setSpeciality(null);
          }
        } else if (state.clinics) {
          if (clinicspeciality !== null && clinicLocation === null) {
            let url = '/api/clinicsdatabyspeciality/' + language + "/" + clinicspeciality.value;
            axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url).then(response => {
              if (response.data.rows.length === 0) {
                setSearchData({
                  nodata: "nodata"
                });
              } else {
                setSearchData(response.data.rows);
                setSpeciality(clinicspeciality);
                setLocation(null);
              }
            }).catch(err => {
              console.log(err);
            });
          } else if (clinicLocation !== null && clinicspeciality === null) {
            let url = '/api/clinicsdatabylocation/' + language + "/" + clinicLocation.value;
            axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url).then(response => {
              if (response.data.rows.length === 0) {
                setSearchData({
                  nodata: "nodata"
                });
              } else {
                setSearchData(response.data.rows);
                setLocation(clinicspeciality);
                setSpeciality(null);
              }
            }).catch(err => {
              console.log(err);
            });
          } else if (clinicspeciality !== null && clinicLocation !== null) {
            let url = '/api/clinicsdatabyspecialityandlocation/' + language + "/" + clinicspeciality.value + "/" + clinicLocation.value;
            axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url).then(response => {
              if (response.data.rows.length === 0) {
                setSearchData({
                  nodata: "nodata"
                });
              } else {
                setSearchData(response.data.rows);
                setLocation(clinicLocation);
                setSpeciality(clinicspeciality);
              }
            }).catch(err => {
              console.log(err);
            });
          } else if (clinicspeciality === null) {
            getClinics();
            setSpeciality(null);
          } else if (clinicLocation === null) {
            getClinics();
            setLocation(null);
          } else if (clinicspeciality === null && clinicLocation === null) {
            getClinics();
            setLocation(null);
            setSpeciality(null);
          }
        }
      };
    
      const colourStyles = {
        option: (styles, {
          data,
          isDisabled,
          isFocused,
          isSelected
        }) => {
          // const color = chroma(data.color);
          // console.log({ data, isDisabled, isFocused, isSelected });
          return { ...styles,
            backgroundColor: isFocused ? "#2A2E43" : null,
            color: "#78849E"
          };
        }
      };
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
          class: "container-center-horizontal",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
            class: "clinic-doctor screen",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
              className: "doctor-filter",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("img", {
                className: "doctor-filter-search",
                src: "/static/img/filter.svg",
                alt: "Card image cap",
                onClick: filterSearch
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 423,
                columnNumber: 13
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                className: "show-data",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                  className: "show-speciality",
                  children: speciality !== null ? speciality.value : ""
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 425,
                  columnNumber: 15
                }, this), speciality !== null && location !== null ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                  className: "show-between",
                  children: "."
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 426,
                  columnNumber: 59
                }, this) : "", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                  className: "show-location",
                  children: location !== null ? location.value : ""
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 427,
                  columnNumber: 15
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 424,
                columnNumber: 13
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 422,
              columnNumber: 11
            }, this), filter ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_2__["Fragment"], {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                className: "filter-card",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Form"], {
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["FormGroup"], {
                      check: true,
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Label"], {
                        check: true,
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                          type: "checkbox",
                          name: "all",
                          onChange: e => handleFirstFilter(e),
                          checked: state.all
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 438,
                          columnNumber: 23
                        }, this), ' ', props.label.search_filter_all]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 437,
                        columnNumber: 21
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 436,
                      columnNumber: 19
                    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["FormGroup"], {
                      check: true,
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Label"], {
                        check: true,
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                          type: "checkbox",
                          name: "doctors",
                          onChange: e => handleFirstFilter(e),
                          checked: state.doctors
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 445,
                          columnNumber: 23
                        }, this), ' ', props.label.search_filter_doctors]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 444,
                        columnNumber: 21
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 443,
                      columnNumber: 19
                    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["FormGroup"], {
                      check: true,
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Label"], {
                        check: true,
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                          type: "checkbox",
                          name: "clinics",
                          onChange: e => handleFirstFilter(e),
                          checked: state.clinics
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 452,
                          columnNumber: 23
                        }, this), ' ', props.label.search_filter_clinics]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 451,
                        columnNumber: 21
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 450,
                      columnNumber: 19
                    }, this), state.doctors === true && state.all === false ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_2__["Fragment"], {
                      children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(react_select__WEBPACK_IMPORTED_MODULE_7__["default"], {
                        className: "basic-single",
                        classNamePrefix: "select",
                        defaultValue: 0 // isDisabled={isDisabled}
                        // isLoading={isLoading}
                        ,
                        isClearable: true // isRtl={isRtl}
                        ,
                        isSearchable: true,
                        name: "speciality",
                        options: doctorSpecialities,
                        value: doctorspeciality,
                        onChange: handleDoctorSpeciality,
                        placeholder: props.label.search_filter_select_speciality,
                        styles: colourStyles
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 458,
                        columnNumber: 79
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(react_select__WEBPACK_IMPORTED_MODULE_7__["default"], {
                        className: "basic-single",
                        classNamePrefix: "select",
                        defaultValue: 0 // isDisabled={isDisabled}
                        // isLoading={isLoading}
                        ,
                        isClearable: true // isRtl={isRtl}
                        ,
                        isSearchable: true,
                        name: "location",
                        options: doctorLocations,
                        value: doctorLocation,
                        onChange: handleDoctorLocation,
                        placeholder: props.label.search_filter_select_location,
                        styles: colourStyles
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 474,
                        columnNumber: 21
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 458,
                      columnNumber: 68
                    }, this) : state.clinics === true && state.all === false ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_2__["Fragment"], {
                      children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(react_select__WEBPACK_IMPORTED_MODULE_7__["default"], {
                        className: "basic-single",
                        classNamePrefix: "select",
                        defaultValue: 0 // isDisabled={isDisabled}
                        // isLoading={isLoading}
                        ,
                        isClearable: true // isRtl={isRtl}
                        ,
                        isSearchable: true,
                        name: "speciality",
                        options: clinicSpecialities,
                        value: clinicspeciality,
                        onChange: handleClinicSpeciality,
                        placeholder: props.label.search_filter_select_speciality
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 493,
                        columnNumber: 82
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(react_select__WEBPACK_IMPORTED_MODULE_7__["default"], {
                        className: "basic-single",
                        classNamePrefix: "select",
                        defaultValue: 0 // isDisabled={isDisabled}
                        // isLoading={isLoading}
                        ,
                        isClearable: true // isRtl={isRtl}
                        ,
                        isSearchable: true,
                        name: "location",
                        options: clinicLocations,
                        value: clinicLocation,
                        onChange: handleClinicLocation,
                        placeholder: props.label.search_filter_select_location,
                        styles: colourStyles
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 509,
                        columnNumber: 23
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 493,
                      columnNumber: 71
                    }, this) : "", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                      className: "filter-button",
                      onClick: ApplyFilter,
                      children: props.label.search_filter_save
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 528,
                      columnNumber: 19
                    }, this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 435,
                    columnNumber: 17
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 434,
                  columnNumber: 15
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 433,
                columnNumber: 32
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 433,
              columnNumber: 22
            }, this) : "", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
              className: "content-doctor",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__["default"], {
                container: true,
                spacing: 3,
                direction: "row",
                justify: "flex-start",
                alignItems: "flex-start",
                children: searchData.length !== 0 && searchData.nodata === "nodata" ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                  className: "no-data",
                  children: props.label.search_nodata
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 547,
                  columnNumber: 60
                }, this) : searchData.length === 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_9___default.a, {
                  color: "#ffffff",
                  loading: "false",
                  css: " display: block;\nmargin-top: 250px;\nborder-color: #2A2E43;margin-left:auto;margin-right:auto;",
                  size: 35
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 548,
                  columnNumber: 1
                }, this) : allData && openMap === false && searchData.length !== 0 && searchData.map((data, key) => {
                  if (data.doc.tableName === "doctors") {
                    if (data.doc.category === "regular") {
                      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_2__["Fragment"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__["default"], {
                          item: true,
                          xs: 12,
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                            className: "regular-card",
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                              className: "sub-card",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
                                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                                  className: "photo-text",
                                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("img", {
                                    className: "photo-registered-doctor",
                                    src: data.doc.profilePic !== undefined ? "http://192.168.43.133:3000/static/" + data.doc.profilePic : "http://192.168.43.133:3000/static/" + "img/doctors/defaultdoctor.png",
                                    alt: "img"
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 561,
                                    columnNumber: 35
                                  }, this)
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 560,
                                  columnNumber: 35
                                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                                    className: "sub-doctor-speciality",
                                    children: language === "en" && data.doc.specialities !== undefined ? data.doc.specialities[0] : language === "en" && data.doc.specialitiesAr !== undefined ? data.doc.specialitiesAr[0] : ""
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 564,
                                    columnNumber: 37
                                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                                    className: "doctor-name",
                                    children: language === "en" ? data.doc.doctorNameEn : data.doc.doctorNameAr
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 565,
                                    columnNumber: 37
                                  }, this)]
                                }, void 0, true, {
                                  fileName: _jsxFileName,
                                  lineNumber: 563,
                                  columnNumber: 35
                                }, this)]
                              }, void 0, true, {
                                fileName: _jsxFileName,
                                lineNumber: 559,
                                columnNumber: 33
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 558,
                              columnNumber: 31
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 557,
                            columnNumber: 29
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 556,
                          columnNumber: 27
                        }, this), (key + 1) % 3 === 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__["default"], {
                          item: true,
                          xs: 12,
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                            className: "add-card",
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardTitle"], {
                                tag: "h5",
                                children: props.label.search_advertisement
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 575,
                                columnNumber: 35
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 574,
                              columnNumber: 33
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 573,
                            columnNumber: 31
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 572,
                          columnNumber: 29
                        }, this) : ""]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 555,
                        columnNumber: 25
                      }, this);
                    } else if (data.doc.category === "registered") {
                      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_2__["Fragment"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__["default"], {
                          item: true,
                          xs: 12,
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                            className: "registered-card",
                            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                              className: "sub-card",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
                                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                                  className: "photo-text",
                                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("img", {
                                    className: "photo-registered-doctor",
                                    src: data.doc.profilePic !== undefined ? "http://192.168.43.133:3000/static/" + data.doc.profilePic : "http://192.168.43.133:3000/static/" + "img/doctors/defaultdoctor.png",
                                    alt: "img"
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 591,
                                    columnNumber: 35
                                  }, this)
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 590,
                                  columnNumber: 35
                                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                                    className: "sub-doctor-speciality",
                                    children: language === "en" && data.doc.specialities !== undefined ? data.doc.specialities[0] : language === "en" && data.doc.specialitiesAr !== undefined ? data.doc.specialitiesAr[0] : ""
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 594,
                                    columnNumber: 35
                                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                                    className: "doctor-name",
                                    children: language === "en" ? data.doc.doctorNameEn : data.doc.doctorNameAr
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 595,
                                    columnNumber: 37
                                  }, this)]
                                }, void 0, true, {
                                  fileName: _jsxFileName,
                                  lineNumber: 593,
                                  columnNumber: 35
                                }, this)]
                              }, void 0, true, {
                                fileName: _jsxFileName,
                                lineNumber: 589,
                                columnNumber: 33
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 588,
                              columnNumber: 31
                            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {}, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 599,
                              columnNumber: 31
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 587,
                            columnNumber: 29
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 586,
                          columnNumber: 27
                        }, this), (key + 1) % 3 === 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__["default"], {
                          item: true,
                          xs: 12,
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                            className: "add-card",
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardTitle"], {
                                tag: "h5",
                                children: props.label.search_advertisement
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 607,
                                columnNumber: 35
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 606,
                              columnNumber: 33
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 605,
                            columnNumber: 31
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 604,
                          columnNumber: 29
                        }, this) : ""]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 585,
                        columnNumber: 25
                      }, this);
                    } else if (data.doc.category === "featured") {
                      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_2__["Fragment"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__["default"], {
                          item: true,
                          xs: 12,
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                            className: "featured-card",
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                              className: "sub-card",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
                                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                                  className: "photo-text",
                                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("img", {
                                    className: "photo-registered-doctor",
                                    src: data.doc.profilePic !== undefined ? "http://192.168.43.133:3000/static/" + data.doc.profilePic : "http://192.168.43.133:3000/static/" + "img/doctors/defaultdoctor.png",
                                    alt: "img"
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 622,
                                    columnNumber: 35
                                  }, this)
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 621,
                                  columnNumber: 35
                                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                                    className: "sub-doctor-speciality",
                                    children: language === "en" && data.doc.specialities !== undefined ? data.doc.specialities[0] : language === "en" && data.doc.specialitiesAr !== undefined ? data.doc.specialitiesAr[0] : ""
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 625,
                                    columnNumber: 35
                                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                                    className: "doctor-name",
                                    children: language === "en" ? data.doc.doctorNameEn : data.doc.doctorNameAr
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 626,
                                    columnNumber: 37
                                  }, this)]
                                }, void 0, true, {
                                  fileName: _jsxFileName,
                                  lineNumber: 624,
                                  columnNumber: 35
                                }, this)]
                              }, void 0, true, {
                                fileName: _jsxFileName,
                                lineNumber: 620,
                                columnNumber: 33
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 619,
                              columnNumber: 31
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 618,
                            columnNumber: 29
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 617,
                          columnNumber: 27
                        }, this), (key + 1) % 3 === 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__["default"], {
                          item: true,
                          xs: 12,
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                            className: "add-card",
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardTitle"], {
                                tag: "h5",
                                children: props.label.search_advertisement
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 636,
                                columnNumber: 35
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 635,
                              columnNumber: 33
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 634,
                            columnNumber: 31
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 633,
                          columnNumber: 29
                        }, this) : ""]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 616,
                        columnNumber: 25
                      }, this);
                    }
                  } else if (data.doc.tableName === "clinics") {
                    if (data.doc.category === "regular") {
                      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_2__["Fragment"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__["default"], {
                          item: true,
                          xs: 12,
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                            className: "regular-card",
                            style: {
                              backgroundImage: `url(${"http://192.168.43.133:3000/static/" + data.doc.profilePic})`
                            },
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                              className: "sub-card",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
                                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                                  className: "photo-text",
                                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("img", {
                                    className: "photo-registered-clinic",
                                    src: "http://192.168.43.133:3000/static/" + data.doc.profilePic,
                                    alt: "Card image cap"
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 658,
                                    columnNumber: 37
                                  }, this)
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 657,
                                  columnNumber: 35
                                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                                    className: "clinic-name",
                                    children: language === "en" ? data.doc.clinicNameEn : data.doc.clinicNameAr
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 661,
                                    columnNumber: 37
                                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                                    className: "sub-clinic-city",
                                    children: language === "en" ? data.doc.cityEn : data.doc.cityAr
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 662,
                                    columnNumber: 37
                                  }, this)]
                                }, void 0, true, {
                                  fileName: _jsxFileName,
                                  lineNumber: 660,
                                  columnNumber: 35
                                }, this)]
                              }, void 0, true, {
                                fileName: _jsxFileName,
                                lineNumber: 656,
                                columnNumber: 33
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 655,
                              columnNumber: 31
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 652,
                            columnNumber: 29
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 651,
                          columnNumber: 27
                        }, this), (key + 1) % 3 === 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__["default"], {
                          item: true,
                          xs: 12,
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                            className: "add-card",
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardTitle"], {
                                tag: "h5",
                                children: props.label.search_advertisement
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 672,
                                columnNumber: 35
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 671,
                              columnNumber: 33
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 670,
                            columnNumber: 31
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 669,
                          columnNumber: 29
                        }, this) : ""]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 650,
                        columnNumber: 25
                      }, this);
                    } else if (data.doc.category === "registered") {
                      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_2__["Fragment"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__["default"], {
                          item: true,
                          xs: 12,
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                            className: "registered-card",
                            style: {
                              backgroundImage: `url(${"http://192.168.43.133:3000/static/" + data.doc.profilePic})`
                            },
                            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                              className: "sub-card",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
                                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                                  className: "photo-text",
                                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("img", {
                                    className: "photo-registered-clinic",
                                    src: "http://192.168.43.133:3000/static/" + data.doc.profilePic,
                                    alt: "Card image cap"
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 690,
                                    columnNumber: 37
                                  }, this)
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 689,
                                  columnNumber: 35
                                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                                    className: "clinic-name",
                                    children: language === "en" ? data.doc.clinicNameEn : data.doc.clinicNameAr
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 693,
                                    columnNumber: 37
                                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                                    className: "sub-clinic-city",
                                    children: language === "en" ? data.doc.cityEn : data.doc.cityAr
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 694,
                                    columnNumber: 37
                                  }, this)]
                                }, void 0, true, {
                                  fileName: _jsxFileName,
                                  lineNumber: 692,
                                  columnNumber: 35
                                }, this)]
                              }, void 0, true, {
                                fileName: _jsxFileName,
                                lineNumber: 688,
                                columnNumber: 33
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 687,
                              columnNumber: 31
                            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {}, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 698,
                              columnNumber: 31
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 683,
                            columnNumber: 29
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 682,
                          columnNumber: 27
                        }, this), (key + 1) % 3 === 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__["default"], {
                          item: true,
                          xs: 12,
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                            className: "add-card",
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardTitle"], {
                                tag: "h5",
                                children: props.label.search_advertisement
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 706,
                                columnNumber: 35
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 705,
                              columnNumber: 33
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 704,
                            columnNumber: 31
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 703,
                          columnNumber: 29
                        }, this) : ""]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 681,
                        columnNumber: 25
                      }, this);
                    } else if (data.doc.category === "featured") {
                      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_2__["Fragment"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__["default"], {
                          item: true,
                          xs: 12,
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                            className: "featured-card",
                            style: {
                              backgroundImage: `url(${"http://192.168.43.133:3000/static/" + data.doc.profilePic})`
                            },
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                              className: "sub-card",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
                                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                                  className: "photo-text",
                                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("img", {
                                    className: "photo-registered-clinic",
                                    src: "http://192.168.43.133:3000/static/" + data.doc.profilePic,
                                    alt: "Card image cap"
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 724,
                                    columnNumber: 37
                                  }, this)
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 723,
                                  columnNumber: 35
                                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                                    className: "clinic-name",
                                    children: language === "en" ? data.doc.clinicNameEn : data.doc.clinicNameAr
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 727,
                                    columnNumber: 37
                                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])("div", {
                                    className: "sub-clinic-city",
                                    children: language === "en" ? data.doc.cityEn : data.doc.cityAr
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 728,
                                    columnNumber: 37
                                  }, this)]
                                }, void 0, true, {
                                  fileName: _jsxFileName,
                                  lineNumber: 726,
                                  columnNumber: 35
                                }, this)]
                              }, void 0, true, {
                                fileName: _jsxFileName,
                                lineNumber: 722,
                                columnNumber: 33
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 721,
                              columnNumber: 31
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 717,
                            columnNumber: 29
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 716,
                          columnNumber: 27
                        }, this), (key + 1) % 3 === 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__["default"], {
                          item: true,
                          xs: 12,
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                            className: "add-card",
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_10__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardTitle"], {
                                tag: "h5",
                                children: props.label.search_advertisement
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 738,
                                columnNumber: 35
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 737,
                              columnNumber: 33
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 736,
                            columnNumber: 31
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 735,
                          columnNumber: 29
                        }, this) : ""]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 715,
                        columnNumber: 25
                      }, this);
                    }
                  }
                })
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 538,
                columnNumber: 13
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 536,
              columnNumber: 11
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 421,
            columnNumber: 9
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 420,
          columnNumber: 7
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 418,
        columnNumber: 5
      }, this);
    }
    
    _s(Search, "mnYK9WkFyCt4XAHEXS8VQb8It+Q=");
    
    _c = Search;
    /* harmony default export */ __webpack_exports__["default"] = (_c2 = Object(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["withRouter"])(Search));
    
    var _c, _c2;
    
    __webpack_require__.$Refresh$.register(_c, "Search");
    __webpack_require__.$Refresh$.register(_c2, "%default%");
    
    const currentExports = __react_refresh_utils__.getModuleExports(module.i);
    __react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);
    
    if (true) {
      const isHotUpdate = !!module.hot.data;
      const prevExports = isHotUpdate ? module.hot.data.prevExports : null;
    
      if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
        module.hot.dispose(
          /**
           * A callback to performs a full refresh if React has unrecoverable errors,
           * and also caches the to-be-disposed module.
           * @param {*} data A hot module data object from Webpack HMR.
           * @returns {void}
           */
          function hotDisposeCallback(data) {
            // We have to mutate the data object to get data registered and cached
            data.prevExports = currentExports;
          }
        );
        module.hot.accept(
          /**
           * An error handler to allow self-recovering behaviours.
           * @param {Error} error An error occurred during evaluation of a module.
           * @returns {void}
           */
          function hotErrorHandler(error) {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.handleRuntimeError(error);
            }
    
            if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
              if (window.onHotAcceptError) {
                window.onHotAcceptError(error.message);
              }
            }
    
            __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
          }
        );
    
        if (isHotUpdate) {
          if (
            __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
            __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
          ) {
            module.hot.invalidate();
          } else {
            __react_refresh_utils__.enqueueUpdate(
              /**
               * A function to dismiss the error overlay after performing React refresh.
               * @returns {void}
               */
              function updateCallback() {
                if (
                  typeof __react_refresh_error_overlay__ !== 'undefined' &&
                  __react_refresh_error_overlay__
                ) {
                  __react_refresh_error_overlay__.clearRuntimeErrors();
                }
              }
            );
          }
        }
      } else {
        if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
          module.hot.invalidate();
        }
      }
    }
    /* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))
    
    /***/ }),
    
    /***/ "./src/components/ImageCarousel.jsx":
    /*!******************************************!*\
      !*** ./src/components/ImageCarousel.jsx ***!
      \******************************************/
    /*! exports provided: default */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    __webpack_require__.r(__webpack_exports__);
    /* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
    /* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
    /* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
    /* harmony import */ var react_owl_carousel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-owl-carousel */ "./node_modules/react-owl-carousel/umd/OwlCarousel.js");
    /* harmony import */ var react_owl_carousel__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_owl_carousel__WEBPACK_IMPORTED_MODULE_2__);
    /* harmony import */ var owl_carousel_dist_assets_owl_carousel_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! owl.carousel/dist/assets/owl.carousel.css */ "./node_modules/owl.carousel/dist/assets/owl.carousel.css");
    /* harmony import */ var owl_carousel_dist_assets_owl_carousel_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(owl_carousel_dist_assets_owl_carousel_css__WEBPACK_IMPORTED_MODULE_3__);
    /* harmony import */ var owl_carousel_dist_assets_owl_theme_default_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! owl.carousel/dist/assets/owl.theme.default.css */ "./node_modules/owl.carousel/dist/assets/owl.theme.default.css");
    /* harmony import */ var owl_carousel_dist_assets_owl_theme_default_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(owl_carousel_dist_assets_owl_theme_default_css__WEBPACK_IMPORTED_MODULE_4__);
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__);
    __webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
    __webpack_require__.$Refresh$.setup(module.i);
    
    var _jsxFileName = "/home/mounika/Desktop/hakeem-app/src/components/ImageCarousel.jsx",
        _s = __webpack_require__.$Refresh$.signature();
    
    
    
    
    
    
    
    
    function ImageCarousel() {
      _s();
    
      const [data, setData] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])([]);
    
      const getClinics = () => {
        let url = '/api/getclinics';
        axios__WEBPACK_IMPORTED_MODULE_1___default.a.get(url, {
          auth: {
            username: "admin",
            password: "Hakeem@738"
          }
        }).then(response => {
          setData(response.data.rows);
        }).catch(err => {
          console.log(err, "clinic error carousel");
        });
      };
    
      Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
        getClinics();
      }, []);
      Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
        setTimeout(() => {
          getClinics();
        }, 100);
      }, []);
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])("div", {
        className: "images-container",
        style: {
          direction: "ltr"
        },
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])(react_owl_carousel__WEBPACK_IMPORTED_MODULE_2___default.a, {
          className: "owl-theme",
          items: 1,
          autoplay: true,
          loop: true,
          margin: 10,
          nav: true,
          children: data.map((profiledata, index) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])("div", {
            class: "item",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])("img", {
              src: "http://192.168.43.133:3000/static/" + profiledata.doc.profilePic
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 43,
              columnNumber: 14
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 42,
            columnNumber: 15
          }, this))
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 39,
          columnNumber: 9
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 9
      }, this);
    }
    
    _s(ImageCarousel, "MNW7rnkI9oNPb711ySWHHHkbM9Y=");
    
    _c = ImageCarousel;
    /* harmony default export */ __webpack_exports__["default"] = (ImageCarousel);
    
    var _c;
    
    __webpack_require__.$Refresh$.register(_c, "ImageCarousel");
    
    const currentExports = __react_refresh_utils__.getModuleExports(module.i);
    __react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);
    
    if (true) {
      const isHotUpdate = !!module.hot.data;
      const prevExports = isHotUpdate ? module.hot.data.prevExports : null;
    
      if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
        module.hot.dispose(
          /**
           * A callback to performs a full refresh if React has unrecoverable errors,
           * and also caches the to-be-disposed module.
           * @param {*} data A hot module data object from Webpack HMR.
           * @returns {void}
           */
          function hotDisposeCallback(data) {
            // We have to mutate the data object to get data registered and cached
            data.prevExports = currentExports;
          }
        );
        module.hot.accept(
          /**
           * An error handler to allow self-recovering behaviours.
           * @param {Error} error An error occurred during evaluation of a module.
           * @returns {void}
           */
          function hotErrorHandler(error) {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.handleRuntimeError(error);
            }
    
            if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
              if (window.onHotAcceptError) {
                window.onHotAcceptError(error.message);
              }
            }
    
            __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
          }
        );
    
        if (isHotUpdate) {
          if (
            __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
            __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
          ) {
            module.hot.invalidate();
          } else {
            __react_refresh_utils__.enqueueUpdate(
              /**
               * A function to dismiss the error overlay after performing React refresh.
               * @returns {void}
               */
              function updateCallback() {
                if (
                  typeof __react_refresh_error_overlay__ !== 'undefined' &&
                  __react_refresh_error_overlay__
                ) {
                  __react_refresh_error_overlay__.clearRuntimeErrors();
                }
              }
            );
          }
        }
      } else {
        if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
          module.hot.invalidate();
        }
      }
    }
    /* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))
    
    /***/ }),
    
    /***/ "./src/components/MapContainer.js":
    /*!****************************************!*\
      !*** ./src/components/MapContainer.js ***!
      \****************************************/
    /*! exports provided: default */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    __webpack_require__.r(__webpack_exports__);
    /* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
    /* harmony import */ var google_maps_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! google-maps-react */ "./node_modules/google-maps-react/dist/index.js");
    /* harmony import */ var google_maps_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(google_maps_react__WEBPACK_IMPORTED_MODULE_1__);
    /* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);
    __webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
    __webpack_require__.$Refresh$.setup(module.i);
    
    var _jsxFileName = "/home/mounika/Desktop/hakeem-app/src/components/MapContainer.js",
        _s = __webpack_require__.$Refresh$.signature();
    
    
    
    
    
    const mapStyles = {
      width: '100%',
      height: '100%'
    };
    
    function MapContainer(props) {
      _s();
    
      const [state, setState] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])({
        latitude: props.latitude,
        longitude: props.longitude
      });
      Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
        setState({
          latitude: props.latitude,
          longitude: props.longitude
        });
      }, [props]);
    
      const handleClick = e => {
        localStorage.setItem("profilePic", props.profilePic);
    
        if (localStorage.getItem("language") == "en") {
          localStorage.setItem("nameEn", props.searchData[0].doc.clinicNameEn !== undefined ? props.searchData[0].doc.clinicNameEn : props.searchData[0].doc.doctorNameEn);
          localStorage.setItem("city", props.searchData[0].doc.cityEn);
          localStorage.setItem("speciality", props.searchData[0].doc.specialities[0]);
        } else if (localStorage.getItem("language") == "ar") {
          localStorage.setItem("nameEn", props.searchData[0].doc.clinicNameAr !== undefined ? props.searchData[0].doc.clinicNameAr : props.searchData[0].doc.doctorNameAr);
          localStorage.setItem("city", props.searchData[0].doc.cityAr);
          localStorage.setItem("speciality", props.searchData[0].doc.specialitiesAr[0]);
        }
    
        localStorage.setItem("email", props.searchData[0].doc.email);
        localStorage.setItem("phone", props.searchData[0].doc.phone);
        props.history.push('/profile');
      };
    
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__["jsxDEV"])(google_maps_react__WEBPACK_IMPORTED_MODULE_1__["Map"], {
        google: props.google,
        center: {
          lat: props.latitude,
          lng: props.longitude
        },
        zoom: 8,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__["jsxDEV"])(google_maps_react__WEBPACK_IMPORTED_MODULE_1__["Marker"], {
          position: {
            lat: state.latitude,
            lng: state.longitude
          },
          icon: {
            url: "http://192.168.43.133:3000/static/" + props.profilePic,
            // anchor: new props.google.maps.Point(80,80),
            scaledSize: new props.google.maps.Size(80, 80)
          },
          onClick: e => handleClick(e)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 35,
          columnNumber: 15
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 15
      }, this);
    }
    
    _s(MapContainer, "+00GhcqBH+RxrHBiSkh8ZIYUD8M=");
    
    _c = MapContainer;
    /* harmony default export */ __webpack_exports__["default"] = (Object(react_router_dom__WEBPACK_IMPORTED_MODULE_2__["withRouter"])(Object(google_maps_react__WEBPACK_IMPORTED_MODULE_1__["GoogleApiWrapper"])({
      apiKey: 'AIzaSyBU6riCbVu-wyHDX255THOd9u--RQW-guo'
    })(MapContainer)));
    
    var _c;
    
    __webpack_require__.$Refresh$.register(_c, "MapContainer");
    
    const currentExports = __react_refresh_utils__.getModuleExports(module.i);
    __react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);
    
    if (true) {
      const isHotUpdate = !!module.hot.data;
      const prevExports = isHotUpdate ? module.hot.data.prevExports : null;
    
      if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
        module.hot.dispose(
          /**
           * A callback to performs a full refresh if React has unrecoverable errors,
           * and also caches the to-be-disposed module.
           * @param {*} data A hot module data object from Webpack HMR.
           * @returns {void}
           */
          function hotDisposeCallback(data) {
            // We have to mutate the data object to get data registered and cached
            data.prevExports = currentExports;
          }
        );
        module.hot.accept(
          /**
           * An error handler to allow self-recovering behaviours.
           * @param {Error} error An error occurred during evaluation of a module.
           * @returns {void}
           */
          function hotErrorHandler(error) {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.handleRuntimeError(error);
            }
    
            if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
              if (window.onHotAcceptError) {
                window.onHotAcceptError(error.message);
              }
            }
    
            __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
          }
        );
    
        if (isHotUpdate) {
          if (
            __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
            __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
          ) {
            module.hot.invalidate();
          } else {
            __react_refresh_utils__.enqueueUpdate(
              /**
               * A function to dismiss the error overlay after performing React refresh.
               * @returns {void}
               */
              function updateCallback() {
                if (
                  typeof __react_refresh_error_overlay__ !== 'undefined' &&
                  __react_refresh_error_overlay__
                ) {
                  __react_refresh_error_overlay__.clearRuntimeErrors();
                }
              }
            );
          }
        }
      } else {
        if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
          module.hot.invalidate();
        }
      }
    }
    /* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))
    
    /***/ }),
    
    /***/ "./src/components/Navigation.jsx":
    /*!***************************************!*\
      !*** ./src/components/Navigation.jsx ***!
      \***************************************/
    /*! exports provided: default */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    __webpack_require__.r(__webpack_exports__);
    /* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
    __webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
    __webpack_require__.$Refresh$.setup(module.i);
    
    var _jsxFileName = "/home/mounika/Desktop/hakeem-app/src/components/Navigation.jsx";
    
    
    
    function Navigation(props) {
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("nav", {
        class: "navbar navbar-expand-lg navbar-dark bg-dark fixed-top",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
          class: "container",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("a", {
            class: "navbar-brand",
            href: "#",
            children: "Hakeem"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 7,
            columnNumber: 9
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
            className: "language-select",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("select", {
              className: "custom-select",
              value: props.language,
              onChange: e => props.handleSetLanguage(e.target.value),
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("option", {
                value: "english",
                children: "English"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 16,
                columnNumber: 13
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("option", {
                value: "arabic",
                children: "Arabic"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 17,
                columnNumber: 13
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 11,
              columnNumber: 11
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 10,
            columnNumber: 9
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 6,
          columnNumber: 7
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 5,
        columnNumber: 5
      }, this);
    }
    
    _c = Navigation;
    /* harmony default export */ __webpack_exports__["default"] = (Navigation);
    
    var _c;
    
    __webpack_require__.$Refresh$.register(_c, "Navigation");
    
    const currentExports = __react_refresh_utils__.getModuleExports(module.i);
    __react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);
    
    if (true) {
      const isHotUpdate = !!module.hot.data;
      const prevExports = isHotUpdate ? module.hot.data.prevExports : null;
    
      if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
        module.hot.dispose(
          /**
           * A callback to performs a full refresh if React has unrecoverable errors,
           * and also caches the to-be-disposed module.
           * @param {*} data A hot module data object from Webpack HMR.
           * @returns {void}
           */
          function hotDisposeCallback(data) {
            // We have to mutate the data object to get data registered and cached
            data.prevExports = currentExports;
          }
        );
        module.hot.accept(
          /**
           * An error handler to allow self-recovering behaviours.
           * @param {Error} error An error occurred during evaluation of a module.
           * @returns {void}
           */
          function hotErrorHandler(error) {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.handleRuntimeError(error);
            }
    
            if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
              if (window.onHotAcceptError) {
                window.onHotAcceptError(error.message);
              }
            }
    
            __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
          }
        );
    
        if (isHotUpdate) {
          if (
            __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
            __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
          ) {
            module.hot.invalidate();
          } else {
            __react_refresh_utils__.enqueueUpdate(
              /**
               * A function to dismiss the error overlay after performing React refresh.
               * @returns {void}
               */
              function updateCallback() {
                if (
                  typeof __react_refresh_error_overlay__ !== 'undefined' &&
                  __react_refresh_error_overlay__
                ) {
                  __react_refresh_error_overlay__.clearRuntimeErrors();
                }
              }
            );
          }
        }
      } else {
        if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
          module.hot.invalidate();
        }
      }
    }
    /* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))
    
    /***/ }),
    
    /***/ "./src/components/Orthis.jsx":
    /*!***********************************!*\
      !*** ./src/components/Orthis.jsx ***!
      \***********************************/
    /*! exports provided: default */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    __webpack_require__.r(__webpack_exports__);
    /* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../App.css */ "./src/App.css");
    /* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_App_css__WEBPACK_IMPORTED_MODULE_0__);
    /* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
    /* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__);
    __webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
    __webpack_require__.$Refresh$.setup(module.i);
    
    var _jsxFileName = "/home/mounika/Desktop/hakeem-app/src/components/Orthis.jsx",
        _s = __webpack_require__.$Refresh$.signature();
    
    
    
    
    
    
    const initialState = {
      mobileNumber: '',
      password: "",
      mobileNumberError: "",
      passwordError: ""
    };
    
    function Orthis(props) {
      _s();
    
      const [state, setState] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(initialState);
    
      const signin = () => {
        props.history.push("/signin");
      };
    
      Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(() => {
        document.body.style.backgroundColor = "#2e3649";
      });
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
        class: "orthis-container",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
          class: "welcome-to",
          children: ["Welcome to ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("br", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 26,
            columnNumber: 40
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("span", {
            className: "sub-text",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("span", {
              className: "i-text",
              children: "i"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 26,
              columnNumber: 73
            }, this), " Hakem"]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 26,
            columnNumber: 46
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 26,
          columnNumber: 5
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
          className: "continue-with",
          children: "CONTINUE WITH:"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 27,
          columnNumber: 5
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
          className: "buttons-continue",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
            className: "btn-green-tCXEIx",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              className: "bg-phone",
              onClick: signin,
              children: "Phone"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 31,
              columnNumber: 17
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 30,
            columnNumber: 15
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
            className: "btn-green-tCXEIx",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              className: "bg-email",
              children: "EMAIL"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 36,
              columnNumber: 17
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 35,
            columnNumber: 12
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
            className: "btn-green-tCXEIx",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              className: "bg-facebook",
              children: "FACEBOOK"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 41,
              columnNumber: 17
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 40,
            columnNumber: 12
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
            className: "btn-green-tCXEIx",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              className: "bg-whatsapp",
              children: "WhatsAPP"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 46,
              columnNumber: 17
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 45,
            columnNumber: 12
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 28,
          columnNumber: 6
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
          className: "bottom-C61RwL",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
            className: "home-indicatordark-7YEL5c",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
              className: "indicator-LHZjI1"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 53,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 52,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 51,
          columnNumber: 14
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 5
      }, this);
    }
    
    _s(Orthis, "g9yWDQF6ixWa1r5sfsm7YAeGJG4=");
    
    _c = Orthis;
    /* harmony default export */ __webpack_exports__["default"] = (_c2 = Object(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["withRouter"])(Orthis));
    
    var _c, _c2;
    
    __webpack_require__.$Refresh$.register(_c, "Orthis");
    __webpack_require__.$Refresh$.register(_c2, "%default%");
    
    const currentExports = __react_refresh_utils__.getModuleExports(module.i);
    __react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);
    
    if (true) {
      const isHotUpdate = !!module.hot.data;
      const prevExports = isHotUpdate ? module.hot.data.prevExports : null;
    
      if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
        module.hot.dispose(
          /**
           * A callback to performs a full refresh if React has unrecoverable errors,
           * and also caches the to-be-disposed module.
           * @param {*} data A hot module data object from Webpack HMR.
           * @returns {void}
           */
          function hotDisposeCallback(data) {
            // We have to mutate the data object to get data registered and cached
            data.prevExports = currentExports;
          }
        );
        module.hot.accept(
          /**
           * An error handler to allow self-recovering behaviours.
           * @param {Error} error An error occurred during evaluation of a module.
           * @returns {void}
           */
          function hotErrorHandler(error) {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.handleRuntimeError(error);
            }
    
            if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
              if (window.onHotAcceptError) {
                window.onHotAcceptError(error.message);
              }
            }
    
            __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
          }
        );
    
        if (isHotUpdate) {
          if (
            __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
            __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
          ) {
            module.hot.invalidate();
          } else {
            __react_refresh_utils__.enqueueUpdate(
              /**
               * A function to dismiss the error overlay after performing React refresh.
               * @returns {void}
               */
              function updateCallback() {
                if (
                  typeof __react_refresh_error_overlay__ !== 'undefined' &&
                  __react_refresh_error_overlay__
                ) {
                  __react_refresh_error_overlay__.clearRuntimeErrors();
                }
              }
            );
          }
        }
      } else {
        if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
          module.hot.invalidate();
        }
      }
    }
    /* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))
    
    /***/ }),
    
    /***/ "./src/components/Profile.jsx":
    /*!************************************!*\
      !*** ./src/components/Profile.jsx ***!
      \************************************/
    /*! exports provided: default */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    __webpack_require__.r(__webpack_exports__);
    /* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
    /* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
    /* harmony import */ var _ImageCarousel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ImageCarousel */ "./src/components/ImageCarousel.jsx");
    /* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__);
    __webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
    __webpack_require__.$Refresh$.setup(module.i);
    
    var _jsxFileName = "/home/mounika/Desktop/hakeem-app/src/components/Profile.jsx",
        _s = __webpack_require__.$Refresh$.signature();
    
    
    
    
    
    
    
    function Profile(props) {
      _s();
    
      const [searchBox, showSearchBox] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
      const [openMap, setOpenMap] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
      const [showDashboard, setShowDashboard] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
      const [role, setROle] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(localStorage.getItem("role"));
      const [modal, setModal] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
    
      const toggle = () => setModal(!modal);
    
      const handleHome = () => {
        showSearchBox(false);
        setOpenMap(false);
      };
    
      const handleSearch = () => {
        showSearchBox(true);
      };
    
      const handleDashboard = () => {
        showSearchBox(false);
        setOpenMap(false);
        setShowDashboard(true);
      };
    
      const handleAppointment = () => {
        if (role === "guest") {
          toggle();
        } else {
          props.history.push('/appointment');
        }
      };
    
      const handleSignup = () => {
        localStorage.removeItem("language");
        localStorage.removeItem("loggedin");
        localStorage.removeItem("guest"); // props.history.push("/");
    
        window.location.href = "/";
      };
    
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
        className: "profile-container",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(_ImageCarousel__WEBPACK_IMPORTED_MODULE_2__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 51,
          columnNumber: 7
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
          className: "profile-details",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
            className: "profile-card",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                className: "photo-name",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("img", {
                  className: "profile-pic",
                  src: "http://192.168.43.133:3000/static/" + localStorage.getItem("profilePic"),
                  alt: "Card image cap"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 56,
                  columnNumber: 15
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                  className: "profile-name",
                  children: [localStorage.getItem("nameEn"), " "]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 57,
                  columnNumber: 15
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 55,
                columnNumber: 13
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("hr", {
                className: "break-line"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 59,
                columnNumber: 13
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                className: "sub-container",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                  children: localStorage.getItem("speciality")
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 61,
                  columnNumber: 15
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                  children: localStorage.getItem("city")
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 62,
                  columnNumber: 15
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 60,
                columnNumber: 13
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("hr", {
                className: "sub-break-line"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 66,
                columnNumber: 13
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                className: "profile-icons",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                  className: "profilepic-container",
                  children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("img", {
                    src: "/static/img/call.svg",
                    alt: "Card image cap",
                    className: "call"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 68,
                    columnNumber: 54
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 68,
                  columnNumber: 15
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                  className: "profilepic-container",
                  children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("img", {
                    src: "/static/img/message.svg",
                    alt: "Card image cap",
                    className: "message"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 69,
                    columnNumber: 54
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 69,
                  columnNumber: 15
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                  className: "profilepic-container",
                  children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("img", {
                    src: "/static/img/chat.svg",
                    alt: "Card image cap",
                    className: "chatting"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 70,
                    columnNumber: 54
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 70,
                  columnNumber: 15
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 67,
                columnNumber: 13
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                className: "address-container",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                  className: "address",
                  children: props.label.profile_address
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 73,
                  columnNumber: 15
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                  className: "phone-email",
                  children: [props.label.profile_phone, " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("span", {
                    className: "link-icons",
                    children: props.label.profile_link_message
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 74,
                    columnNumber: 72
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 74,
                  columnNumber: 15
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 72,
                columnNumber: 13
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                className: "appointment-container",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                  className: "appointment-button",
                  onClick: handleAppointment,
                  children: ["   ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("img", {
                    src: "/static/img/calendar.svg",
                    alt: "Card image cap",
                    className: "appointment-icon"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 77,
                    columnNumber: 84
                  }, this), props.label.profile_appointment]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 77,
                  columnNumber: 13
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 76,
                columnNumber: 13
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 54,
              columnNumber: 11
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 53,
            columnNumber: 9
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 52,
          columnNumber: 7
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Modal"], {
          isOpen: modal,
          toggle: toggle,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["ModalHeader"], {
            toggle: toggle,
            children: "Thank you for viewing"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 89,
            columnNumber: 9
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["ModalBody"], {
            children: ["Please Signup to make an appointment", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              color: "primary",
              onClick: handleSignup,
              className: "handlesignup",
              children: "Sign Up"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 92,
              columnNumber: 11
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 90,
            columnNumber: 9
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 88,
          columnNumber: 7
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 49,
        columnNumber: 5
      }, this);
    }
    
    _s(Profile, "Qgruw6qPaar3SYG3TMSSGenKPps=");
    
    _c = Profile;
    /* harmony default export */ __webpack_exports__["default"] = (_c2 = Object(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["withRouter"])(Profile));
    
    var _c, _c2;
    
    __webpack_require__.$Refresh$.register(_c, "Profile");
    __webpack_require__.$Refresh$.register(_c2, "%default%");
    
    const currentExports = __react_refresh_utils__.getModuleExports(module.i);
    __react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);
    
    if (true) {
      const isHotUpdate = !!module.hot.data;
      const prevExports = isHotUpdate ? module.hot.data.prevExports : null;
    
      if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
        module.hot.dispose(
          /**
           * A callback to performs a full refresh if React has unrecoverable errors,
           * and also caches the to-be-disposed module.
           * @param {*} data A hot module data object from Webpack HMR.
           * @returns {void}
           */
          function hotDisposeCallback(data) {
            // We have to mutate the data object to get data registered and cached
            data.prevExports = currentExports;
          }
        );
        module.hot.accept(
          /**
           * An error handler to allow self-recovering behaviours.
           * @param {Error} error An error occurred during evaluation of a module.
           * @returns {void}
           */
          function hotErrorHandler(error) {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.handleRuntimeError(error);
            }
    
            if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
              if (window.onHotAcceptError) {
                window.onHotAcceptError(error.message);
              }
            }
    
            __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
          }
        );
    
        if (isHotUpdate) {
          if (
            __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
            __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
          ) {
            module.hot.invalidate();
          } else {
            __react_refresh_utils__.enqueueUpdate(
              /**
               * A function to dismiss the error overlay after performing React refresh.
               * @returns {void}
               */
              function updateCallback() {
                if (
                  typeof __react_refresh_error_overlay__ !== 'undefined' &&
                  __react_refresh_error_overlay__
                ) {
                  __react_refresh_error_overlay__.clearRuntimeErrors();
                }
              }
            );
          }
        }
      } else {
        if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
          module.hot.invalidate();
        }
      }
    }
    /* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))
    
    /***/ }),
    
    /***/ "./src/components/ProfileSettings.jsx":
    /*!********************************************!*\
      !*** ./src/components/ProfileSettings.jsx ***!
      \********************************************/
    /*! exports provided: default */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    __webpack_require__.r(__webpack_exports__);
    /* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
    /* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
    /* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
    /* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
    /* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/styles */ "./node_modules/@material-ui/core/esm/styles/index.js");
    /* harmony import */ var _material_ui_core_AppBar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/AppBar */ "./node_modules/@material-ui/core/esm/AppBar/index.js");
    /* harmony import */ var _material_ui_core_Tabs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/Tabs */ "./node_modules/@material-ui/core/esm/Tabs/index.js");
    /* harmony import */ var _material_ui_core_Tab__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/core/Tab */ "./node_modules/@material-ui/core/esm/Tab/index.js");
    /* harmony import */ var _material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @material-ui/core/Typography */ "./node_modules/@material-ui/core/esm/Typography/index.js");
    /* harmony import */ var _data_chatdata_json__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../data/chatdata.json */ "./src/data/chatdata.json");
    var _data_chatdata_json__WEBPACK_IMPORTED_MODULE_8___namespace = /*#__PURE__*/__webpack_require__.t(/*! ../data/chatdata.json */ "./src/data/chatdata.json", 1);
    /* harmony import */ var _material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @material-ui/core/Grid */ "./node_modules/@material-ui/core/esm/Grid/index.js");
    /* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
    /* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_10__);
    /* harmony import */ var react_toast_notifications__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! react-toast-notifications */ "./node_modules/react-toast-notifications/dist/index.js");
    /* harmony import */ var react_toast_notifications__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_toast_notifications__WEBPACK_IMPORTED_MODULE_11__);
    /* harmony import */ var _Toggle__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./Toggle */ "./src/components/Toggle.js");
    /* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__);
    __webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
    __webpack_require__.$Refresh$.setup(module.i);
    
    var _jsxFileName = "/home/mounika/Desktop/hakeem-app/src/components/ProfileSettings.jsx",
        _s = __webpack_require__.$Refresh$.signature();
    
    
    
    
    
    
    
    
    
    
    
    
    
    
     // import Box from '@material-ui/core/Box';
    
    
    const initialState = {
      mobileNumber: '',
      password: "",
      mobileNumberError: "",
      passwordError: "",
      userName: '',
      userNameError: '',
      email: '',
      emailError: '',
      address: '',
      addressError: '',
      city: '',
      cityError: '',
      zipcode: '',
      zipcodeError: '',
      language: '',
      languageError: '',
      role: "",
      roleError: "",
      website: "",
      websiteError: ""
    };
    const initialslotstate = {
      day: "",
      startbnoontime: "",
      endbnoontime: "",
      startanoontime: "",
      endanoontime: "",
      starttuesdaybnoontime: "",
      endtuesdaybnoontime: "",
      starttuesdayanoontime: "",
      endtuesdayanoontime: "",
      startwednesdaybnoontime: "",
      endwednesdaybnoontime: "",
      startwednesdayanoontime: "",
      endwednesdayanoontime: "",
      startthursdaybnoontime: "",
      endthursdaybnoontime: "",
      startthursdayanoontime: "",
      endthursdayanoontime: "",
      startfridaybnoontime: "",
      endfridaybnoontime: "",
      startfridayanoontime: "",
      endfridayanoontime: "",
      startsaturdaybnoontime: "",
      endsaturdaybnoontime: "",
      startsaturdayanoontime: "",
      endsaturdayanoontime: "",
      startbnoontimeError: "",
      endbnoontimeError: "",
      startanoontimeError: "",
      endanoontimeError: ""
    };
    
    function TabPanel(props) {
      const {
        children,
        value,
        index,
        ...other
      } = props;
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
        role: "tabpanel",
        hidden: value !== index,
        id: `simple-tabpanel-${index}`,
        "aria-labelledby": `simple-tab-${index}`,
        ...other,
        children: value === index &&
        /*#__PURE__*/
        // <Box p={3}>
        Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(_material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_7__["default"], {
          children: children
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 92,
          columnNumber: 9
        }, this) // </Box>
    
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 83,
        columnNumber: 5
      }, this);
    }
    
    _c = TabPanel;
    TabPanel.propTypes = {
      children: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.node,
      index: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.any.isRequired,
      value: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.any.isRequired
    };
    
    function a11yProps(index) {
      return {
        id: `simple-tab-${index}`,
        'aria-controls': `simple-tabpanel-${index}`
      };
    }
    
    const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_3__["makeStyles"])(theme => ({
      root: {
        flexGrow: 1,
        backgroundColor: theme.palette.background.paper
      }
    }));
    
    function ProfileSettings(props) {
      _s();
    
      Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
        document.body.style.backgroundColor = "#fff";
      });
    
      const handleNavigation = () => {
        props.history.push('/dashboard');
      };
    
      const classes = useStyles();
      const [value, setValue] = react__WEBPACK_IMPORTED_MODULE_0___default.a.useState(0);
      const [language, setLanguage] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(localStorage.getItem("language"));
      const [state, setState] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(initialState);
      const {
        addToast
      } = Object(react_toast_notifications__WEBPACK_IMPORTED_MODULE_11__["useToasts"])();
      const [doctor, setDoctor] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])([]);
      const [toggleChecked, setToggleChecked] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(true);
      const [modal, setModal] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
      const [noon, setNoon] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])("");
      const [slotState, setSlotState] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(initialslotstate);
      const [toggletuesdayChecked, setToggleTuesdayChecked] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(true);
      const [togglewednesdayChecked, setToggleWednesdayChecked] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(true);
      const [togglethursdayChecked, setToggleThursdayChecked] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(true);
      const [togglefridayChecked, setToggleFridayChecked] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(true);
      const [togglesaturdayChecked, setToggleSaturdayChecked] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(true);
      const [tuesdaymodal, setTuesdayModal] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
      const [wednesdaymodal, setWednesdayModal] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
      const [thursdaymodal, setThursdayModal] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
      const [fridaymodal, setFridayModal] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
      const [saturdaymodal, setSaturdayModal] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
    
      const toggle = () => setModal(!modal);
    
      const tuesdaytoggle = () => setTuesdayModal(!tuesdaymodal);
    
      const wednesdaytoggle = () => setWednesdayModal(!wednesdaymodal);
    
      const thursdaytoggle = () => setThursdayModal(!thursdaymodal);
    
      const fridaytoggle = () => setFridayModal(!fridaymodal);
    
      const saturdaytoggle = () => setSaturdayModal(!saturdaymodal);
    
      const handleToggleChange = e => {
        setToggleChecked(e.target.checked);
      };
    
      const handleToggleThuesdayChange = e => {
        setToggleTuesdayChecked(e.target.checked);
      };
    
      const handleToggleWednesdayChange = e => {
        setToggleWednesdayChecked(e.target.checked);
      };
    
      const handleToggleThursdayChange = e => {
        setToggleThursdayChecked(e.target.checked);
      };
    
      const handleToggleFridayChange = e => {
        setToggleFridayChecked(e.target.checked);
      };
    
      const handleToggleSaturdayChange = e => {
        setToggleSaturdayChecked(e.target.checked);
      };
    
      const handleChange = (event, newValue) => {
        const isValid = validate();
    
        if (isValid) {
          setValue(newValue);
        }
      };
    
      const handleTimings = (noon, time) => {
        if (time === "toggle") {
          toggle();
        } else if (time === "tuesday") {
          tuesdaytoggle();
        } else if (time === "wednesday") {
          wednesdaytoggle();
        } else if (time === "thursday") {
          thursdaytoggle();
        } else if (time === "friday") {
          fridaytoggle();
        } else if (time === "saturday") {
          saturdaytoggle();
        }
    
        setNoon(noon);
      };
    
      const validate = () => {
        let userNameError;
    
        if (!state.userName) {
          userNameError = 'Name is required';
        }
    
        if (userNameError) {
          setState({ ...state,
            userNameError
          });
          return false;
        }
    
        return true;
      };
    
      const updateprofile = () => {
        const isValid = validate();
        let url = '/api/updatedoctordetails';
    
        if (isValid) {
          axios__WEBPACK_IMPORTED_MODULE_10___default.a.post(url, {
            id: doctor._id,
            rev: doctor._rev,
            category: doctor.category,
            doctorNameAr: doctor.doctorNameAr,
            doctorNameEn: state.userName,
            email: doctor.email,
            isDeleted: doctor.isDeleted,
            language: doctor.language,
            mobileNumber: doctor.mobileNumber,
            password: doctor.password,
            tableName: doctor.tableName,
            userStatus: doctor.userStatus,
            userType: doctor.userType,
            website: state.website,
            address: state.address,
            city: state.city,
            zipcode: state.zipcode
          }).then(function (response) {
            if (response.data.status === 200) {
              addToast('Doctor Profile Updated Successfully', {
                appearance: 'success',
                autoDismiss: true,
                autoDismissTimeout: 1000,
                onDismiss: () => {
                  setState(initialState); // localStorage.setItem("language",response.data.language)
                  // localStorage.setItem("loggedin",true);
                  // localStorage.setItem("role","user");
    
                  props.history.push("/dashboard");
                }
              });
            } else if (response.data.status === 400) {
              addToast('User already exists', {
                appearance: 'error',
                autoDismiss: true,
                autoDismissTimeout: 2000
              });
            }
          }).catch(err => {
            console.log(err);
          });
        }
      };
    
      const getdoctordetails = () => {
        let url = '/api/doctordetailsbyid/' + localStorage.getItem('id');
        axios__WEBPACK_IMPORTED_MODULE_10___default.a.get(url).then(function (response) {
          if (response.data.status === 200) {
            setDoctor(response.data.rows);
            setState({
              userName: response.data.rows.doctorNameEn,
              email: response.data.rows.email,
              mobileNumber: response.data.rows.mobileNumber,
              website: response.data.rows.website,
              address: response.data.rows.address,
              city: response.data.rows.city,
              zipcode: response.data.rows.zipcode
            });
          } else if (response.data.status === 400) {}
        }).catch(err => {
          console.log(err);
        });
      };
    
      Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
        getdoctordetails();
      }, []);
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
        className: "doctortimeslot-container",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
          className: "top-container",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("img", {
            src: "/static/img/arrow.svg",
            className: "arrow-image",
            onClick: handleNavigation
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 310,
            columnNumber: 9
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("img", {
            src: "/static/img/share.svg",
            className: "share-image"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 311,
            columnNumber: 9
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 309,
          columnNumber: 7
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
          className: "top-header",
          children: props.label.profilesettings
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 313,
          columnNumber: 7
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
          className: "tabs-container",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(_material_ui_core_AppBar__WEBPACK_IMPORTED_MODULE_4__["default"], {
            position: "static",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(_material_ui_core_Tabs__WEBPACK_IMPORTED_MODULE_5__["default"], {
              value: value,
              onChange: handleChange,
              variant: "fullWidth",
              "aria-label": "simple tabs example",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(_material_ui_core_Tab__WEBPACK_IMPORTED_MODULE_6__["default"], {
                label: props.label.profilesettings_basicinfo,
                ...a11yProps(0)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 318,
                columnNumber: 13
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(_material_ui_core_Tab__WEBPACK_IMPORTED_MODULE_6__["default"], {
                label: props.label.profilesettings_contactdetails,
                ...a11yProps(1)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 319,
                columnNumber: 13
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(_material_ui_core_Tab__WEBPACK_IMPORTED_MODULE_6__["default"], {
                label: props.label.profilesetting_scheduletimings,
                ...a11yProps(2)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 320,
                columnNumber: 13
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 316,
              columnNumber: 11
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 315,
            columnNumber: 9
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(TabPanel, {
            value: value,
            index: 0,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__["default"], {
                container: true,
                spacing: 1,
                direction: "row",
                justify: "flex-start",
                alignItems: "flex-start",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__["default"], {
                    item: true,
                    xs: 12,
                    sm: 12,
                    md: 12,
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Card"], {
                      className: `chat-profilecard`,
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                        className: "content-profilesettings",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          class: "textfields-signup",
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            className: "group",
                            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                                type: "text",
                                name: "userName",
                                value: state.userName,
                                onChange: event => event.target.value ? setState({ ...state,
                                  userName: event.target.value,
                                  userNameError: ""
                                }) : setState({ ...state,
                                  userName: event.target.value,
                                  userNameError: "Name is required"
                                }),
                                placeholder: "Name"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 343,
                                columnNumber: 29
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 342,
                              columnNumber: 27
                            }, this), state.userNameError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                              className: "validation-error",
                              children: state.userNameError
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 356,
                              columnNumber: 50
                            }, this) : ""]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 341,
                            columnNumber: 25
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            className: "group",
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                                type: "text",
                                name: "email",
                                value: state.email,
                                onChange: event => event.target.value ? setState({ ...state,
                                  email: event.target.value,
                                  emailError: ""
                                }) : setState({ ...state,
                                  email: event.target.value,
                                  emailError: ""
                                }),
                                placeholder: "Email",
                                readOnly: true
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 362,
                                columnNumber: 29
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 361,
                              columnNumber: 27
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 360,
                            columnNumber: 25
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            className: "group",
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                                type: "text",
                                name: "mobileNumber",
                                value: state.mobileNumber,
                                onChange: event => event.target.value ? setState({ ...state,
                                  mobileNumber: event.target.value,
                                  mobileNumberError: ""
                                }) : setState({ ...state,
                                  mobileNumber: event.target.value,
                                  mobileNumberError: ""
                                }),
                                placeholder: "Mobile",
                                readOnly: true
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 381,
                                columnNumber: 29
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 380,
                              columnNumber: 27
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 379,
                            columnNumber: 25
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            className: "group",
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                                type: "text",
                                name: "website",
                                value: state.website,
                                onChange: event => event.target.value ? setState({ ...state,
                                  website: event.target.value,
                                  websiteError: ""
                                }) : setState({ ...state,
                                  website: event.target.value,
                                  websiteError: ""
                                }),
                                placeholder: "Website"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 400,
                                columnNumber: 29
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 399,
                              columnNumber: 27
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 398,
                            columnNumber: 25
                          }, this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 340,
                          columnNumber: 23
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          className: "buttonslargeblue-xUsx1L",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Button"], {
                            className: "profilesettings-button",
                            onClick: e => handleChange(e, 1),
                            children: "NEXT"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 421,
                            columnNumber: 25
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 420,
                          columnNumber: 23
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 339,
                        columnNumber: 21
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 338,
                      columnNumber: 19
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 337,
                    columnNumber: 17
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 336,
                  columnNumber: 15
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 328,
                columnNumber: 13
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 327,
              columnNumber: 11
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 325,
            columnNumber: 9
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(TabPanel, {
            value: value,
            index: 1,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__["default"], {
                container: true,
                spacing: 1,
                direction: "row",
                justify: "flex-start",
                alignItems: "flex-start",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__["default"], {
                    item: true,
                    xs: 12,
                    sm: 12,
                    md: 12,
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Card"], {
                      className: `chat-profilecard`,
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                        className: "content-profilesettings",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          class: "textfields-signup",
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            className: "group",
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                                type: "text",
                                name: "address",
                                value: state.address,
                                onChange: event => event.target.value ? setState({ ...state,
                                  address: event.target.value,
                                  addressError: ""
                                }) : setState({ ...state,
                                  address: event.target.value,
                                  addressError: ""
                                }),
                                placeholder: "Address"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 456,
                                columnNumber: 29
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 455,
                              columnNumber: 27
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 454,
                            columnNumber: 25
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            className: "group",
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                                type: "text",
                                name: "city",
                                value: state.city,
                                onChange: event => event.target.value ? setState({ ...state,
                                  city: event.target.value,
                                  cityError: ""
                                }) : setState({ ...state,
                                  city: event.target.value,
                                  cityError: ""
                                }),
                                placeholder: "City"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 473,
                                columnNumber: 29
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 472,
                              columnNumber: 27
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 471,
                            columnNumber: 25
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            className: "group",
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                                type: "text",
                                name: "zipcode",
                                value: state.zipcode,
                                onChange: event => event.target.value ? setState({ ...state,
                                  zipcode: event.target.value,
                                  zipcodeError: ""
                                }) : setState({ ...state,
                                  zipcode: event.target.value,
                                  zipcodeError: ""
                                }),
                                placeholder: "Zip Code"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 491,
                                columnNumber: 29
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 490,
                              columnNumber: 27
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 489,
                            columnNumber: 25
                          }, this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 453,
                          columnNumber: 23
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          class: "buttonslargeblue-xUsx1L",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Button"], {
                            className: "profilesettings-button",
                            onClick: updateprofile,
                            children: "Save"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 533,
                            columnNumber: 25
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 532,
                          columnNumber: 23
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 452,
                        columnNumber: 21
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 451,
                      columnNumber: 19
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 450,
                    columnNumber: 17
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 449,
                  columnNumber: 15
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 441,
                columnNumber: 13
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 440,
              columnNumber: 11
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 436,
            columnNumber: 9
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(TabPanel, {
            value: value,
            index: 2,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__["default"], {
                container: true,
                spacing: 1,
                direction: "row",
                justify: "flex-start",
                alignItems: "flex-start",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__["default"], {
                    item: true,
                    xs: 12,
                    sm: 12,
                    md: 12,
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Card"], {
                      className: `chat-profilecard`,
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                        className: "scheduleday-container",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          className: "day",
                          children: "Monday"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 565,
                          columnNumber: 23
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          className: "day-toggle",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(_Toggle__WEBPACK_IMPORTED_MODULE_12__["default"], {
                            checked: toggleChecked // text="Is Active"
                            ,
                            size: "default",
                            disabled: false,
                            onChange: handleToggleChange,
                            offstyle: "toggle_off",
                            onstyle: "toggle_on"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 567,
                            columnNumber: 25
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 566,
                          columnNumber: 23
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 564,
                        columnNumber: 21
                      }, this), toggleChecked ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                        className: "scheduletime-container",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          className: "scheduletime-slot",
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            children: "Before Noon"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 580,
                            columnNumber: 25
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            children: ["  ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Button"], {
                              className: "scheduletime-button",
                              onClick: () => handleTimings("beforenoon", "toggle"),
                              children: "Set Timings"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 581,
                              columnNumber: 32
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 581,
                            columnNumber: 25
                          }, this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 579,
                          columnNumber: 23
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          className: "scheduletime-slot",
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            children: "After Noon"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 587,
                            columnNumber: 25
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Button"], {
                              className: "scheduletime-button",
                              onClick: () => handleTimings("afternoon", "toggle"),
                              children: "Set Timings"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 589,
                              columnNumber: 27
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 588,
                            columnNumber: 25
                          }, this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 586,
                          columnNumber: 23
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 578,
                        columnNumber: 38
                      }, this) : ""]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 563,
                      columnNumber: 19
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 562,
                    columnNumber: 17
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__["default"], {
                    item: true,
                    xs: 12,
                    sm: 12,
                    md: 12,
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Card"], {
                      className: `chat-profilecard`,
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                        className: "scheduleday-container",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          className: "day",
                          children: "Tuesday"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 602,
                          columnNumber: 23
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          className: "day-toggle",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(_Toggle__WEBPACK_IMPORTED_MODULE_12__["default"], {
                            checked: toggletuesdayChecked // text="Is Active"
                            ,
                            size: "default",
                            disabled: false,
                            onChange: handleToggleThuesdayChange,
                            offstyle: "toggle_off",
                            onstyle: "toggle_on"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 604,
                            columnNumber: 25
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 603,
                          columnNumber: 23
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 601,
                        columnNumber: 21
                      }, this), toggletuesdayChecked ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                        className: "scheduletime-container",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          className: "scheduletime-slot",
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            children: "Before Noon"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 617,
                            columnNumber: 25
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            children: ["  ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Button"], {
                              className: "scheduletime-button",
                              onClick: () => handleTimings("beforenoon", "tuesday"),
                              children: "Set Timings"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 618,
                              columnNumber: 32
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 618,
                            columnNumber: 25
                          }, this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 616,
                          columnNumber: 23
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          className: "scheduletime-slot",
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            children: "After Noon"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 624,
                            columnNumber: 25
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Button"], {
                              className: "scheduletime-button",
                              onClick: () => handleTimings("afternoon", "tuesday"),
                              children: "Set Timings"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 626,
                              columnNumber: 27
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 625,
                            columnNumber: 25
                          }, this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 623,
                          columnNumber: 23
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 615,
                        columnNumber: 45
                      }, this) : ""]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 600,
                      columnNumber: 19
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 599,
                    columnNumber: 17
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__["default"], {
                    item: true,
                    xs: 12,
                    sm: 12,
                    md: 12,
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Card"], {
                      className: `chat-profilecard`,
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                        className: "scheduleday-container",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          className: "day",
                          children: "Wednesday"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 638,
                          columnNumber: 23
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          className: "day-toggle",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(_Toggle__WEBPACK_IMPORTED_MODULE_12__["default"], {
                            checked: togglewednesdayChecked // text="Is Active"
                            ,
                            size: "default",
                            disabled: false,
                            onChange: handleToggleWednesdayChange,
                            offstyle: "toggle_off",
                            onstyle: "toggle_on"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 640,
                            columnNumber: 25
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 639,
                          columnNumber: 23
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 637,
                        columnNumber: 21
                      }, this), togglewednesdayChecked ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                        className: "scheduletime-container",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          className: "scheduletime-slot",
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            children: "Before Noon"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 653,
                            columnNumber: 25
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            children: ["  ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Button"], {
                              className: "scheduletime-button",
                              onClick: () => handleTimings("beforenoon", "wednesday"),
                              children: "Set Timings"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 654,
                              columnNumber: 32
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 654,
                            columnNumber: 25
                          }, this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 652,
                          columnNumber: 23
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          className: "scheduletime-slot",
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            children: "After Noon"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 660,
                            columnNumber: 25
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Button"], {
                              className: "scheduletime-button",
                              onClick: () => handleTimings("afternoon", "wednesday"),
                              children: "Set Timings"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 662,
                              columnNumber: 27
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 661,
                            columnNumber: 25
                          }, this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 659,
                          columnNumber: 23
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 651,
                        columnNumber: 47
                      }, this) : ""]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 636,
                      columnNumber: 19
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 635,
                    columnNumber: 17
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__["default"], {
                    item: true,
                    xs: 12,
                    sm: 12,
                    md: 12,
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Card"], {
                      className: `chat-profilecard`,
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                        className: "scheduleday-container",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          className: "day",
                          children: "Thursday"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 674,
                          columnNumber: 23
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          className: "day-toggle",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(_Toggle__WEBPACK_IMPORTED_MODULE_12__["default"], {
                            checked: togglethursdayChecked // text="Is Active"
                            ,
                            size: "default",
                            disabled: false,
                            onChange: handleToggleThursdayChange,
                            offstyle: "toggle_off",
                            onstyle: "toggle_on"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 676,
                            columnNumber: 25
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 675,
                          columnNumber: 23
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 673,
                        columnNumber: 21
                      }, this), togglethursdayChecked ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                        className: "scheduletime-container",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          className: "scheduletime-slot",
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            children: "Before Noon"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 689,
                            columnNumber: 25
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            children: ["  ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Button"], {
                              className: "scheduletime-button",
                              onClick: () => handleTimings("beforenoon", "thursday"),
                              children: "Set Timings"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 690,
                              columnNumber: 32
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 690,
                            columnNumber: 25
                          }, this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 688,
                          columnNumber: 23
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          className: "scheduletime-slot",
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            children: "After Noon"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 696,
                            columnNumber: 25
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Button"], {
                              className: "scheduletime-button",
                              onClick: () => handleTimings("afternoon", "thursday"),
                              children: "Set Timings"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 698,
                              columnNumber: 27
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 697,
                            columnNumber: 25
                          }, this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 695,
                          columnNumber: 23
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 687,
                        columnNumber: 46
                      }, this) : ""]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 672,
                      columnNumber: 19
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 671,
                    columnNumber: 17
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__["default"], {
                    item: true,
                    xs: 12,
                    sm: 12,
                    md: 12,
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Card"], {
                      className: `chat-profilecard`,
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                        className: "scheduleday-container",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          className: "day",
                          children: "Friday"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 710,
                          columnNumber: 23
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          className: "day-toggle",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(_Toggle__WEBPACK_IMPORTED_MODULE_12__["default"], {
                            checked: togglefridayChecked // text="Is Active"
                            ,
                            size: "default",
                            disabled: false,
                            onChange: handleToggleFridayChange,
                            offstyle: "toggle_off",
                            onstyle: "toggle_on"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 712,
                            columnNumber: 25
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 711,
                          columnNumber: 23
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 709,
                        columnNumber: 21
                      }, this), togglefridayChecked ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                        className: "scheduletime-container",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          className: "scheduletime-slot",
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            children: "Before Noon"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 725,
                            columnNumber: 25
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            children: ["  ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Button"], {
                              className: "scheduletime-button",
                              onClick: () => handleTimings("beforenoon", "friday"),
                              children: "Set Timings"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 726,
                              columnNumber: 32
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 726,
                            columnNumber: 25
                          }, this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 724,
                          columnNumber: 23
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          className: "scheduletime-slot",
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            children: "After Noon"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 732,
                            columnNumber: 25
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Button"], {
                              className: "scheduletime-button",
                              onClick: () => handleTimings("afternoon", "friday"),
                              children: "Set Timings"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 734,
                              columnNumber: 27
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 733,
                            columnNumber: 25
                          }, this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 731,
                          columnNumber: 23
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 723,
                        columnNumber: 44
                      }, this) : ""]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 708,
                      columnNumber: 19
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 707,
                    columnNumber: 17
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_9__["default"], {
                    item: true,
                    xs: 12,
                    sm: 12,
                    md: 12,
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Card"], {
                      className: `chat-profilecard`,
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                        className: "scheduleday-container",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          className: "day",
                          children: "Saturday"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 746,
                          columnNumber: 23
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          className: "day-toggle",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(_Toggle__WEBPACK_IMPORTED_MODULE_12__["default"], {
                            checked: togglesaturdayChecked // text="Is Active"
                            ,
                            size: "default",
                            disabled: false,
                            onChange: handleToggleSaturdayChange,
                            offstyle: "toggle_off",
                            onstyle: "toggle_on"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 748,
                            columnNumber: 25
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 747,
                          columnNumber: 23
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 745,
                        columnNumber: 21
                      }, this), togglesaturdayChecked ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                        className: "scheduletime-container",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          className: "scheduletime-slot",
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            children: "Before Noon"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 761,
                            columnNumber: 25
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            children: ["  ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Button"], {
                              className: "scheduletime-button",
                              onClick: () => handleTimings("beforenoon", "saturday"),
                              children: "Set Timings"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 762,
                              columnNumber: 32
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 762,
                            columnNumber: 25
                          }, this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 760,
                          columnNumber: 23
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                          className: "scheduletime-slot",
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            children: "After Noon"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 768,
                            columnNumber: 25
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Button"], {
                              className: "scheduletime-button",
                              onClick: () => handleTimings("afternoon", "saturday"),
                              children: "Set Timings"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 770,
                              columnNumber: 27
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 769,
                            columnNumber: 25
                          }, this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 767,
                          columnNumber: 23
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 759,
                        columnNumber: 46
                      }, this) : ""]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 744,
                      columnNumber: 19
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 743,
                    columnNumber: 17
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 561,
                  columnNumber: 15
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 553,
                columnNumber: 13
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 552,
              columnNumber: 11
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 549,
            columnNumber: 9
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 314,
          columnNumber: 7
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Modal"], {
          isOpen: modal,
          toggle: toggle,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["ModalHeader"], {
            toggle: toggle,
            children: [noon === "beforenoon" ? "Add Before Noon Time Slot" : "Add After Noon Time Slot", " "]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 786,
            columnNumber: 9
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["ModalBody"], {
            children: noon === "beforenoon" ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
              children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                className: "timeslotform",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                      type: "select",
                      name: "startbnoontime",
                      value: slotState.startbnoontime,
                      onChange: event => event.target.value ? setSlotState({ ...slotState,
                        startbnoontime: event.target.value,
                        startbnoontimeError: ""
                      }) : setSlotState({ ...slotState,
                        startbnoontime: event.target.value,
                        startbnoontimeError: ""
                      }),
                      className: "bg-qq7RjC",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "",
                        children: "Start Time"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 796,
                        columnNumber: 17
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "10",
                        children: "10:00 AM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 797,
                        columnNumber: 17
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "doctor",
                        children: "11:00 AM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 798,
                        columnNumber: 17
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "12:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 799,
                        columnNumber: 17
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "01:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 800,
                        columnNumber: 17
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 791,
                      columnNumber: 15
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 790,
                    columnNumber: 13
                  }, this), slotState.startbnoontimeError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: slotState.startbnoontimeError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 804,
                    columnNumber: 46
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 789,
                  columnNumber: 11
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                      type: "select",
                      name: "endbnoontime",
                      value: slotState.endbnoontime,
                      onChange: event => event.target.value ? setSlotState({ ...slotState,
                        endbnoontime: event.target.value,
                        endbnoontimeError: ""
                      }) : setSlotState({ ...slotState,
                        endbnoontime: event.target.value,
                        endbnoontimeError: ""
                      }),
                      className: "bg-qq7RjC",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "",
                        children: "End Time"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 815,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "10",
                        children: "10:00 AM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 816,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "doctor",
                        children: "11:00 AM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 817,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "12:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 818,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "01:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 819,
                        columnNumber: 19
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 810,
                      columnNumber: 17
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 809,
                    columnNumber: 15
                  }, this), slotState.endbnoontimeError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: slotState.endbnoontimeError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 824,
                    columnNumber: 46
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 808,
                  columnNumber: 13
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Button"], {
                  className: "savetimeslot-button",
                  onClick: toggle,
                  children: "Save"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 828,
                  columnNumber: 13
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 788,
                columnNumber: 47
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 788,
              columnNumber: 36
            }, this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
              children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                className: "timeslotform",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                      type: "select",
                      name: "startanoontime",
                      value: slotState.startanoontime,
                      onChange: event => event.target.value ? setSlotState({ ...slotState,
                        startanoontime: event.target.value,
                        startanoontimeError: ""
                      }) : setSlotState({ ...slotState,
                        startanoontime: event.target.value,
                        startanoontimeError: ""
                      }),
                      className: "bg-qq7RjC",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "",
                        children: "Start Time"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 841,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "3",
                        children: "03:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 842,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "doctor",
                        children: "04:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 843,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "05:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 844,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "06:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 845,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "07:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 846,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "08:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 847,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "09:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 848,
                        columnNumber: 19
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 836,
                      columnNumber: 17
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 835,
                    columnNumber: 15
                  }, this), slotState.startanoontimeError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: slotState.startanoontimeError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 853,
                    columnNumber: 48
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 834,
                  columnNumber: 56
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                      type: "select",
                      name: "endanoontime",
                      value: slotState.endanoontime,
                      onChange: event => event.target.value ? setSlotState({ ...slotState,
                        endanoontime: event.target.value,
                        endanoontimeError: ""
                      }) : setSlotState({ ...slotState,
                        endanoontime: event.target.value,
                        endanoontimeError: ""
                      }),
                      className: "bg-qq7RjC",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "",
                        children: "End Time"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 865,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "3",
                        children: "03:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 866,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "doctor",
                        children: "04:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 867,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "05:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 868,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "06:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 869,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "07:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 870,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "08:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 871,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "09:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 872,
                        columnNumber: 21
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 859,
                      columnNumber: 19
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 858,
                    columnNumber: 17
                  }, this), slotState.endanoontimeError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: slotState.endanoontimeError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 877,
                    columnNumber: 48
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 857,
                  columnNumber: 15
                }, this), "      ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Button"], {
                  className: "savetimeslot-button",
                  onClick: toggle,
                  children: "Save"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 880,
                  columnNumber: 27
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 834,
                columnNumber: 24
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 834,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 787,
            columnNumber: 9
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 785,
          columnNumber: 7
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Modal"], {
          isOpen: tuesdaymodal,
          toggle: tuesdaytoggle,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["ModalHeader"], {
            toggle: tuesdaytoggle,
            children: [noon === "beforenoon" ? "Add Before Noon Time Slot" : "Add After Noon Time Slot", " "]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 895,
            columnNumber: 9
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["ModalBody"], {
            children: noon === "beforenoon" ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
              children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                className: "timeslotform",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                      type: "select",
                      name: "starttuesdaybnoontime",
                      value: slotState.starttuesdaybnoontime,
                      onChange: event => event.target.value ? setSlotState({ ...slotState,
                        starttuesdaybnoontime: event.target.value,
                        starttuesdaybnoontimeError: ""
                      }) : setSlotState({ ...slotState,
                        starttuesdaybnoontime: event.target.value,
                        starttuesdaybnoontimeError: ""
                      }),
                      className: "bg-qq7RjC",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "",
                        children: "Start Time"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 905,
                        columnNumber: 17
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "10",
                        children: "10:00 AM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 906,
                        columnNumber: 17
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "doctor",
                        children: "11:00 AM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 907,
                        columnNumber: 17
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "12:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 908,
                        columnNumber: 17
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "01:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 909,
                        columnNumber: 17
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 900,
                      columnNumber: 15
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 899,
                    columnNumber: 13
                  }, this), slotState.starttuesdaybnoontimeError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: slotState.starttuesdaybnoontimeError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 913,
                    columnNumber: 53
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 898,
                  columnNumber: 11
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                      type: "select",
                      name: "endtuesdaybnoontime",
                      value: slotState.endtuesdaybnoontime,
                      onChange: event => event.target.value ? setSlotState({ ...slotState,
                        endtuesdaybnoontime: event.target.value,
                        endtuesdaybnoontimeError: ""
                      }) : setSlotState({ ...slotState,
                        endtuesdaybnoontime: event.target.value,
                        endtuesdaybnoontimeError: ""
                      }),
                      className: "bg-qq7RjC",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "",
                        children: "End Time"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 924,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "10",
                        children: "10:00 AM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 925,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "doctor",
                        children: "11:00 AM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 926,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "12:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 927,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "01:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 928,
                        columnNumber: 19
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 919,
                      columnNumber: 17
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 918,
                    columnNumber: 15
                  }, this), slotState.endtuesdaybnoontimeError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: slotState.endtuesdaybnoontimeError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 933,
                    columnNumber: 53
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 917,
                  columnNumber: 13
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Button"], {
                  className: "savetimeslot-button",
                  onClick: tuesdaytoggle,
                  children: "Save"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 937,
                  columnNumber: 13
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 897,
                columnNumber: 47
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 897,
              columnNumber: 36
            }, this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
              children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                className: "timeslotform",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                      type: "select",
                      name: "starttuesdayanoontime",
                      value: slotState.starttuesdayanoontime,
                      onChange: event => event.target.value ? setSlotState({ ...slotState,
                        starttuesdayanoontime: event.target.value,
                        starttuesdayanoontimeError: ""
                      }) : setSlotState({ ...slotState,
                        starttuesdayanoontime: event.target.value,
                        starttuesdayanoontimeError: ""
                      }),
                      className: "bg-qq7RjC",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "",
                        children: "Start Time"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 950,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "3",
                        children: "03:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 951,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "doctor",
                        children: "04:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 952,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "05:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 953,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "06:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 954,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "07:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 955,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "08:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 956,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "09:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 957,
                        columnNumber: 19
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 945,
                      columnNumber: 17
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 944,
                    columnNumber: 15
                  }, this), slotState.starttuesdayanoontimeError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: slotState.starttuesdayanoontimeError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 962,
                    columnNumber: 55
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 943,
                  columnNumber: 56
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                      type: "select",
                      name: "endtuesdayanoontime",
                      value: slotState.endtuesdayanoontime,
                      onChange: event => event.target.value ? setSlotState({ ...slotState,
                        endtuesdayanoontime: event.target.value,
                        endtuesdayanoontimeError: ""
                      }) : setSlotState({ ...slotState,
                        endtuesdayanoontime: event.target.value,
                        endtuesdayanoontimeError: ""
                      }),
                      className: "bg-qq7RjC",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "",
                        children: "End Time"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 974,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "3",
                        children: "03:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 975,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "doctor",
                        children: "04:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 976,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "05:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 977,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "06:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 978,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "07:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 979,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "08:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 980,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "09:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 981,
                        columnNumber: 21
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 968,
                      columnNumber: 19
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 967,
                    columnNumber: 17
                  }, this), slotState.endtuesdayanoontimeError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: slotState.endtuesdayanoontimeError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 986,
                    columnNumber: 55
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 966,
                  columnNumber: 15
                }, this), "      ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Button"], {
                  className: "savetimeslot-button",
                  onClick: tuesdaytoggle,
                  children: "Save"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 989,
                  columnNumber: 27
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 943,
                columnNumber: 24
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 943,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 896,
            columnNumber: 9
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 894,
          columnNumber: 7
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Modal"], {
          isOpen: wednesdaymodal,
          toggle: wednesdaytoggle,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["ModalHeader"], {
            toggle: wednesdaytoggle,
            children: [noon === "beforenoon" ? "Add Before Noon Time Slot" : "Add After Noon Time Slot", " "]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 999,
            columnNumber: 9
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["ModalBody"], {
            children: noon === "beforenoon" ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
              children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                className: "timeslotform",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                      type: "select",
                      name: "startwednesdaybnoontime",
                      value: slotState.startwednesdaybnoontime,
                      onChange: event => event.target.value ? setSlotState({ ...slotState,
                        startwednesdaybnoontime: event.target.value,
                        startwednesdaybnoontimeError: ""
                      }) : setSlotState({ ...slotState,
                        startwednesdaybnoontime: event.target.value,
                        startwednesdaybnoontimeError: ""
                      }),
                      className: "bg-qq7RjC",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "",
                        children: "Start Time"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1009,
                        columnNumber: 17
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "10",
                        children: "10:00 AM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1010,
                        columnNumber: 17
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "doctor",
                        children: "11:00 AM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1011,
                        columnNumber: 17
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "12:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1012,
                        columnNumber: 17
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "01:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1013,
                        columnNumber: 17
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 1004,
                      columnNumber: 15
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1003,
                    columnNumber: 13
                  }, this), slotState.startwednesdaybnoontimeError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: slotState.startwednesdaybnoontimeError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1017,
                    columnNumber: 55
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 1002,
                  columnNumber: 11
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                      type: "select",
                      name: "endwednesdaybnoontime",
                      value: slotState.endwednesdaybnoontime,
                      onChange: event => event.target.value ? setSlotState({ ...slotState,
                        endwednesdaybnoontime: event.target.value,
                        endwednesdaybnoontimeError: ""
                      }) : setSlotState({ ...slotState,
                        endwednesdaybnoontime: event.target.value,
                        endwednesdaybnoontimeError: ""
                      }),
                      className: "bg-qq7RjC",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "",
                        children: "End Time"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1028,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "10",
                        children: "10:00 AM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1029,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "doctor",
                        children: "11:00 AM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1030,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "12:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1031,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "01:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1032,
                        columnNumber: 19
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 1023,
                      columnNumber: 17
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1022,
                    columnNumber: 15
                  }, this), slotState.endwednesdaybnoontimeError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: slotState.endwednesdaybnoontimeError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1037,
                    columnNumber: 55
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 1021,
                  columnNumber: 13
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Button"], {
                  className: "savetimeslot-button",
                  onClick: wednesdaytoggle,
                  children: "Save"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1041,
                  columnNumber: 13
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 1001,
                columnNumber: 47
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 1001,
              columnNumber: 36
            }, this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
              children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                className: "timeslotform",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                      type: "select",
                      name: "startwednesdayanoontime",
                      value: slotState.startwednesdayanoontime,
                      onChange: event => event.target.value ? setSlotState({ ...slotState,
                        startwednesdayanoontime: event.target.value,
                        startwednesdayanoontimeError: ""
                      }) : setSlotState({ ...slotState,
                        startwednesdayanoontime: event.target.value,
                        startwednesdayanoontimeError: ""
                      }),
                      className: "bg-qq7RjC",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "",
                        children: "Start Time"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1054,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "3",
                        children: "03:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1055,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "doctor",
                        children: "04:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1056,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "05:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1057,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "06:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1058,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "07:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1059,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "08:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1060,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "09:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1061,
                        columnNumber: 19
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 1049,
                      columnNumber: 17
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1048,
                    columnNumber: 15
                  }, this), slotState.startwednesdayanoontimeError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: slotState.startwednesdayanoontimeError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1066,
                    columnNumber: 57
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 1047,
                  columnNumber: 56
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                      type: "select",
                      name: "endwednesdayanoontime",
                      value: slotState.endwednesdayanoontime,
                      onChange: event => event.target.value ? setSlotState({ ...slotState,
                        endwednesdayanoontime: event.target.value,
                        endwednesdayanoontimeError: ""
                      }) : setSlotState({ ...slotState,
                        endwednesdayanoontime: event.target.value,
                        endwednesdayanoontimeError: ""
                      }),
                      className: "bg-qq7RjC",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "",
                        children: "End Time"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1078,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "3",
                        children: "03:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1079,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "doctor",
                        children: "04:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1080,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "05:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1081,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "06:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1082,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "07:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1083,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "08:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1084,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "09:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1085,
                        columnNumber: 21
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 1072,
                      columnNumber: 19
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1071,
                    columnNumber: 17
                  }, this), slotState.endwednesdayanoontimeError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: slotState.endwednesdayanoontimeError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1090,
                    columnNumber: 57
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 1070,
                  columnNumber: 15
                }, this), "      ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Button"], {
                  className: "savetimeslot-button",
                  onClick: wednesdaytoggle,
                  children: "Save"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1093,
                  columnNumber: 27
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 1047,
                columnNumber: 24
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 1047,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 1000,
            columnNumber: 9
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 998,
          columnNumber: 7
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Modal"], {
          isOpen: thursdaymodal,
          toggle: thursdaytoggle,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["ModalHeader"], {
            toggle: thursdaytoggle,
            children: [noon === "beforenoon" ? "Add Before Noon Time Slot" : "Add After Noon Time Slot", " "]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 1103,
            columnNumber: 9
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["ModalBody"], {
            children: noon === "beforenoon" ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
              children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                className: "timeslotform",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                      type: "select",
                      name: "startthursdaybnoontime",
                      value: slotState.startthursdaybnoontime,
                      onChange: event => event.target.value ? setSlotState({ ...slotState,
                        startthursdaybnoontime: event.target.value,
                        startthursdaybnoontimeError: ""
                      }) : setSlotState({ ...slotState,
                        startthursdaybnoontime: event.target.value,
                        startthursdaybnoontimeError: ""
                      }),
                      className: "bg-qq7RjC",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "",
                        children: "Start Time"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1113,
                        columnNumber: 17
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "10",
                        children: "10:00 AM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1114,
                        columnNumber: 17
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "doctor",
                        children: "11:00 AM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1115,
                        columnNumber: 17
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "12:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1116,
                        columnNumber: 17
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "01:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1117,
                        columnNumber: 17
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 1108,
                      columnNumber: 15
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1107,
                    columnNumber: 13
                  }, this), slotState.startthursdaybnoontimeError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: slotState.startthursdaybnoontimeError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1121,
                    columnNumber: 54
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 1106,
                  columnNumber: 11
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                      type: "select",
                      name: "endthursdaybnoontime",
                      value: slotState.endthursdaybnoontime,
                      onChange: event => event.target.value ? setSlotState({ ...slotState,
                        endthursdaybnoontime: event.target.value,
                        endthursdaybnoontimeError: ""
                      }) : setSlotState({ ...slotState,
                        endthursdaybnoontime: event.target.value,
                        endthursdaybnoontimeError: ""
                      }),
                      className: "bg-qq7RjC",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "",
                        children: "End Time"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1132,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "10",
                        children: "10:00 AM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1133,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "doctor",
                        children: "11:00 AM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1134,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "12:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1135,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "01:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1136,
                        columnNumber: 19
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 1127,
                      columnNumber: 17
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1126,
                    columnNumber: 15
                  }, this), slotState.endthursdaybnoontimeError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: slotState.endthursdaybnoontimeError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1141,
                    columnNumber: 54
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 1125,
                  columnNumber: 13
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Button"], {
                  className: "savetimeslot-button",
                  onClick: thursdaytoggle,
                  children: "Save"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1145,
                  columnNumber: 13
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 1105,
                columnNumber: 47
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 1105,
              columnNumber: 36
            }, this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
              children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                className: "timeslotform",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                      type: "select",
                      name: "startthursdayanoontime",
                      value: slotState.startthursdayanoontime,
                      onChange: event => event.target.value ? setSlotState({ ...slotState,
                        startthursdayanoontime: event.target.value,
                        startthursdayanoontimeError: ""
                      }) : setSlotState({ ...slotState,
                        startthursdayanoontime: event.target.value,
                        startthursdayanoontimeError: ""
                      }),
                      className: "bg-qq7RjC",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "",
                        children: "Start Time"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1158,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "3",
                        children: "03:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1159,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "doctor",
                        children: "04:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1160,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "05:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1161,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "06:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1162,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "07:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1163,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "08:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1164,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "09:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1165,
                        columnNumber: 19
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 1153,
                      columnNumber: 17
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1152,
                    columnNumber: 15
                  }, this), slotState.startthursdayanoontimeError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: slotState.startthursdayanoontimeError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1170,
                    columnNumber: 56
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 1151,
                  columnNumber: 56
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                      type: "select",
                      name: "endthursdayanoontime",
                      value: slotState.endthursdayanoontime,
                      onChange: event => event.target.value ? setSlotState({ ...slotState,
                        endthursdayanoontime: event.target.value,
                        endthursdayanoontimeError: ""
                      }) : setSlotState({ ...slotState,
                        endthursdayanoontime: event.target.value,
                        endthursdayanoontimeError: ""
                      }),
                      className: "bg-qq7RjC",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "",
                        children: "End Time"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1182,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "3",
                        children: "03:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1183,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "doctor",
                        children: "04:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1184,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "05:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1185,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "06:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1186,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "07:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1187,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "08:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1188,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "09:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1189,
                        columnNumber: 21
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 1176,
                      columnNumber: 19
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1175,
                    columnNumber: 17
                  }, this), slotState.endthursdayanoontimeError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: slotState.endthursdayanoontimeError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1194,
                    columnNumber: 56
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 1174,
                  columnNumber: 15
                }, this), "      ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Button"], {
                  className: "savetimeslot-button",
                  onClick: thursdaytoggle,
                  children: "Save"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1197,
                  columnNumber: 27
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 1151,
                columnNumber: 24
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 1151,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 1104,
            columnNumber: 9
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 1102,
          columnNumber: 7
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Modal"], {
          isOpen: fridaymodal,
          toggle: fridaytoggle,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["ModalHeader"], {
            toggle: fridaytoggle,
            children: [noon === "beforenoon" ? "Add Before Noon Time Slot" : "Add After Noon Time Slot", " "]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 1207,
            columnNumber: 9
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["ModalBody"], {
            children: noon === "beforenoon" ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
              children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                className: "timeslotform",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                      type: "select",
                      name: "startfridaybnoontime",
                      value: slotState.startfridaybnoontime,
                      onChange: event => event.target.value ? setSlotState({ ...slotState,
                        startfridaybnoontime: event.target.value,
                        startfridaybnoontimeError: ""
                      }) : setSlotState({ ...slotState,
                        startfridaybnoontime: event.target.value,
                        startfridaybnoontimeError: ""
                      }),
                      className: "bg-qq7RjC",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "",
                        children: "Start Time"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1217,
                        columnNumber: 17
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "10",
                        children: "10:00 AM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1218,
                        columnNumber: 17
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "doctor",
                        children: "11:00 AM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1219,
                        columnNumber: 17
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "12:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1220,
                        columnNumber: 17
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "01:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1221,
                        columnNumber: 17
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 1212,
                      columnNumber: 15
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1211,
                    columnNumber: 13
                  }, this), slotState.startfridaybnoontimeError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: slotState.startfridaybnoontimeError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1225,
                    columnNumber: 52
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 1210,
                  columnNumber: 11
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                      type: "select",
                      name: "endfridaybnoontime",
                      value: slotState.endfridaybnoontime,
                      onChange: event => event.target.value ? setSlotState({ ...slotState,
                        endfridaybnoontime: event.target.value,
                        endfridaybnoontimeError: ""
                      }) : setSlotState({ ...slotState,
                        endfridaybnoontime: event.target.value,
                        endfridaybnoontimeError: ""
                      }),
                      className: "bg-qq7RjC",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "",
                        children: "End Time"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1236,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "10",
                        children: "10:00 AM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1237,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "doctor",
                        children: "11:00 AM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1238,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "12:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1239,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "01:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1240,
                        columnNumber: 19
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 1231,
                      columnNumber: 17
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1230,
                    columnNumber: 15
                  }, this), slotState.endfridaybnoontimeError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: slotState.endfridaybnoontimeError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1245,
                    columnNumber: 52
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 1229,
                  columnNumber: 13
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Button"], {
                  className: "savetimeslot-button",
                  onClick: fridaytoggle,
                  children: "Save"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1249,
                  columnNumber: 13
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 1209,
                columnNumber: 47
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 1209,
              columnNumber: 36
            }, this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
              children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                className: "timeslotform",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                      type: "select",
                      name: "startfridayanoontime",
                      value: slotState.startfridayanoontime,
                      onChange: event => event.target.value ? setSlotState({ ...slotState,
                        startfridayanoontime: event.target.value,
                        startfridayanoontimeError: ""
                      }) : setSlotState({ ...slotState,
                        startfridayanoontime: event.target.value,
                        startfridayanoontimeError: ""
                      }),
                      className: "bg-qq7RjC",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "",
                        children: "Start Time"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1262,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "3",
                        children: "03:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1263,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "doctor",
                        children: "04:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1264,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "05:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1265,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "06:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1266,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "07:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1267,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "08:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1268,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "09:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1269,
                        columnNumber: 19
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 1257,
                      columnNumber: 17
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1256,
                    columnNumber: 15
                  }, this), slotState.startfridayanoontimeError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: slotState.startfridayanoontimeError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1274,
                    columnNumber: 54
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 1255,
                  columnNumber: 56
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                      type: "select",
                      name: "endfridayanoontime",
                      value: slotState.endfridayanoontime,
                      onChange: event => event.target.value ? setSlotState({ ...slotState,
                        endfridayanoontime: event.target.value,
                        endfridayanoontimeError: ""
                      }) : setSlotState({ ...slotState,
                        endfridayanoontime: event.target.value,
                        endfridayanoontimeError: ""
                      }),
                      className: "bg-qq7RjC",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "",
                        children: "End Time"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1286,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "3",
                        children: "03:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1287,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "doctor",
                        children: "04:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1288,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "05:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1289,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "06:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1290,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "07:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1291,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "08:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1292,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "09:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1293,
                        columnNumber: 21
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 1280,
                      columnNumber: 19
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1279,
                    columnNumber: 17
                  }, this), slotState.endfridayanoontimeError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: slotState.endfridayanoontimeError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1298,
                    columnNumber: 54
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 1278,
                  columnNumber: 15
                }, this), "      ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Button"], {
                  className: "savetimeslot-button",
                  onClick: fridaytoggle,
                  children: "Save"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1301,
                  columnNumber: 27
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 1255,
                columnNumber: 24
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 1255,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 1208,
            columnNumber: 9
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 1206,
          columnNumber: 7
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Modal"], {
          isOpen: saturdaymodal,
          toggle: saturdaytoggle,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["ModalHeader"], {
            toggle: saturdaytoggle,
            children: [noon === "beforenoon" ? "Add Before Noon Time Slot" : "Add After Noon Time Slot", " "]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 1311,
            columnNumber: 9
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["ModalBody"], {
            children: noon === "beforenoon" ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
              children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                className: "timeslotform",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                      type: "select",
                      name: "startsaturdaybnoontime",
                      value: slotState.startsaturdaybnoontime,
                      onChange: event => event.target.value ? setSlotState({ ...slotState,
                        startsaturdaybnoontime: event.target.value,
                        startsaturdaybnoontimeError: ""
                      }) : setSlotState({ ...slotState,
                        startsaturdaybnoontime: event.target.value,
                        startsaturdaybnoontimeError: ""
                      }),
                      className: "bg-qq7RjC",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "",
                        children: "Start Time"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1321,
                        columnNumber: 17
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "10",
                        children: "10:00 AM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1322,
                        columnNumber: 17
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "doctor",
                        children: "11:00 AM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1323,
                        columnNumber: 17
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "12:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1324,
                        columnNumber: 17
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "01:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1325,
                        columnNumber: 17
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 1316,
                      columnNumber: 15
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1315,
                    columnNumber: 13
                  }, this), slotState.startsaturdaybnoontimeError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: slotState.startsaturdaybnoontimeError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1329,
                    columnNumber: 54
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 1314,
                  columnNumber: 11
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                      type: "select",
                      name: "endsaturdaybnoontime",
                      value: slotState.endsaturdaybnoontime,
                      onChange: event => event.target.value ? setSlotState({ ...slotState,
                        endsaturdaybnoontime: event.target.value,
                        endsaturdaybnoontimeError: ""
                      }) : setSlotState({ ...slotState,
                        endsaturdaybnoontime: event.target.value,
                        endsaturdaybnoontimeError: ""
                      }),
                      className: "bg-qq7RjC",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "",
                        children: "End Time"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1340,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "10",
                        children: "10:00 AM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1341,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "doctor",
                        children: "11:00 AM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1342,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "12:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1343,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "01:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1344,
                        columnNumber: 19
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 1335,
                      columnNumber: 17
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1334,
                    columnNumber: 15
                  }, this), slotState.endsaturdaybnoontimeError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: slotState.endsaturdaybnoontimeError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1349,
                    columnNumber: 54
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 1333,
                  columnNumber: 13
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Button"], {
                  className: "savetimeslot-button",
                  onClick: saturdaytoggle,
                  children: "Save"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1353,
                  columnNumber: 13
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 1313,
                columnNumber: 47
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 1313,
              columnNumber: 36
            }, this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
              children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                className: "timeslotform",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                      type: "select",
                      name: "startsaturdayanoontime",
                      value: slotState.startsaturdayanoontime,
                      onChange: event => event.target.value ? setSlotState({ ...slotState,
                        startsaturdayanoontime: event.target.value,
                        startsaturdayanoontimeError: ""
                      }) : setSlotState({ ...slotState,
                        startsaturdayanoontime: event.target.value,
                        startsaturdayanoontimeError: ""
                      }),
                      className: "bg-qq7RjC",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "",
                        children: "Start Time"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1366,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "3",
                        children: "03:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1367,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "doctor",
                        children: "04:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1368,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "05:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1369,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "06:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1370,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "07:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1371,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "08:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1372,
                        columnNumber: 19
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "09:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1373,
                        columnNumber: 19
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 1361,
                      columnNumber: 17
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1360,
                    columnNumber: 15
                  }, this), slotState.startsaturdayanoontimeError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: slotState.startsaturdayanoontimeError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1378,
                    columnNumber: 56
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 1359,
                  columnNumber: 56
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Input"], {
                      type: "select",
                      name: "endsaturdayanoontime",
                      value: slotState.endsaturdayanoontime,
                      onChange: event => event.target.value ? setSlotState({ ...slotState,
                        endsaturdayanoontime: event.target.value,
                        endsaturdayanoontimeError: ""
                      }) : setSlotState({ ...slotState,
                        endsaturdayanoontime: event.target.value,
                        endsaturdayanoontimeError: ""
                      }),
                      className: "bg-qq7RjC",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "",
                        children: "End Time"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1390,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "3",
                        children: "03:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1391,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "doctor",
                        children: "04:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1392,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "05:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1393,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "06:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1394,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "07:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1395,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "08:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1396,
                        columnNumber: 21
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("option", {
                        value: "patient",
                        children: "09:00 PM"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 1397,
                        columnNumber: 21
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 1384,
                      columnNumber: 19
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1383,
                    columnNumber: 17
                  }, this), slotState.endsaturdayanoontimeError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: slotState.endsaturdayanoontimeError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 1402,
                    columnNumber: 56
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 1382,
                  columnNumber: 15
                }, this), "      ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_14__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_13__["Button"], {
                  className: "savetimeslot-button",
                  onClick: saturdaytoggle,
                  children: "Save"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 1405,
                  columnNumber: 27
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 1359,
                columnNumber: 24
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 1359,
              columnNumber: 13
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 1312,
            columnNumber: 9
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 1310,
          columnNumber: 7
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 308,
        columnNumber: 5
      }, this);
    }
    
    _s(ProfileSettings, "LvTf6tQhJ2gBSw0/JQ16qi1CWuU=", false, function () {
      return [useStyles, react_toast_notifications__WEBPACK_IMPORTED_MODULE_11__["useToasts"]];
    });
    
    _c2 = ProfileSettings;
    /* harmony default export */ __webpack_exports__["default"] = (_c3 = Object(react_router_dom__WEBPACK_IMPORTED_MODULE_1__["withRouter"])(ProfileSettings));
    
    var _c, _c2, _c3;
    
    __webpack_require__.$Refresh$.register(_c, "TabPanel");
    __webpack_require__.$Refresh$.register(_c2, "ProfileSettings");
    __webpack_require__.$Refresh$.register(_c3, "%default%");
    
    const currentExports = __react_refresh_utils__.getModuleExports(module.i);
    __react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);
    
    if (true) {
      const isHotUpdate = !!module.hot.data;
      const prevExports = isHotUpdate ? module.hot.data.prevExports : null;
    
      if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
        module.hot.dispose(
          /**
           * A callback to performs a full refresh if React has unrecoverable errors,
           * and also caches the to-be-disposed module.
           * @param {*} data A hot module data object from Webpack HMR.
           * @returns {void}
           */
          function hotDisposeCallback(data) {
            // We have to mutate the data object to get data registered and cached
            data.prevExports = currentExports;
          }
        );
        module.hot.accept(
          /**
           * An error handler to allow self-recovering behaviours.
           * @param {Error} error An error occurred during evaluation of a module.
           * @returns {void}
           */
          function hotErrorHandler(error) {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.handleRuntimeError(error);
            }
    
            if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
              if (window.onHotAcceptError) {
                window.onHotAcceptError(error.message);
              }
            }
    
            __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
          }
        );
    
        if (isHotUpdate) {
          if (
            __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
            __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
          ) {
            module.hot.invalidate();
          } else {
            __react_refresh_utils__.enqueueUpdate(
              /**
               * A function to dismiss the error overlay after performing React refresh.
               * @returns {void}
               */
              function updateCallback() {
                if (
                  typeof __react_refresh_error_overlay__ !== 'undefined' &&
                  __react_refresh_error_overlay__
                ) {
                  __react_refresh_error_overlay__.clearRuntimeErrors();
                }
              }
            );
          }
        }
      } else {
        if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
          module.hot.invalidate();
        }
      }
    }
    /* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))
    
    /***/ }),
    
    /***/ "./src/components/Search.jsx":
    /*!***********************************!*\
      !*** ./src/components/Search.jsx ***!
      \***********************************/
    /*! exports provided: default */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    __webpack_require__.r(__webpack_exports__);
    /* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../App.css */ "./src/App.css");
    /* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_App_css__WEBPACK_IMPORTED_MODULE_0__);
    /* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
    /* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
    /* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
    /* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_4__);
    /* harmony import */ var _material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/Grid */ "./node_modules/@material-ui/core/esm/Grid/index.js");
    /* harmony import */ var react_toast_notifications__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-toast-notifications */ "./node_modules/react-toast-notifications/dist/index.js");
    /* harmony import */ var react_toast_notifications__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_toast_notifications__WEBPACK_IMPORTED_MODULE_6__);
    /* harmony import */ var react_select__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-select */ "./node_modules/react-select/dist/react-select.esm.js");
    /* harmony import */ var _MapContainer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./MapContainer */ "./src/components/MapContainer.js");
    /* harmony import */ var _AppLanguage__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./AppLanguage */ "./src/components/AppLanguage.jsx");
    /* harmony import */ var react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-spinners/ClipLoader */ "./node_modules/react-spinners/ClipLoader.js");
    /* harmony import */ var react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_10__);
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__);
    __webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
    __webpack_require__.$Refresh$.setup(module.i);
    
    var _jsxFileName = "/home/mounika/Desktop/hakeem-app/src/components/Search.jsx",
        _s = __webpack_require__.$Refresh$.signature();
    
    
    
    
    
    
    
    
    
    
    
    
    
    const initialState = {
      all: false,
      doctors: false,
      clinics: false
    };
    const initialLoginState = {
      password: "",
      passwordError: "",
      mobileNumber: '',
      mobileNumberError: ''
    };
    const mapStyles = {
      width: '100%',
      height: '100%'
    };
    
    function Search(props) {
      _s();
    
      const [state, setState] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(initialState);
      const [change, setChange] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])("doctor");
      const [loginState, setLoginState] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(initialLoginState);
      const {
        addToast
      } = Object(react_toast_notifications__WEBPACK_IMPORTED_MODULE_6__["useToasts"])();
      const [clinics, setClinics] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])([]);
      const [doctors, setDoctors] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])([]);
      const [language, setLanguage] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(localStorage.getItem("language"));
      const [clinicSpecialities, setClinicSpecialities] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])([]);
      const [doctorSpecialities, setDoctorSpecialities] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])([]);
      const [clinicspeciality, setClinicSpeciality] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(null);
      const [doctorspeciality, setDoctorSpeciality] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(null);
      const [clinicColor, setClinicColor] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])('');
      const [doctorColor, setDoctorColor] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])('#5773ff');
      const [filter, showFilter] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);
      const [saveFilter, setSaveFilter] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);
      const [searchData, setSearchData] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])([]);
      const [allData, setAllData] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(true);
      const [speciality, setSpeciality] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(null);
      const [clinicLocations, setClinicLocations] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])([]);
      const [doctorLocations, setDoctorLocations] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])([]);
      const [clinicLocation, setClinicLocation] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(null);
      const [doctorLocation, setDoctorLocation] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(null);
      const [location, setLocation] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(null);
      const [searchBox, showSearchBox] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);
      const [searchValue, setSearchValue] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])("");
      const [openMap, setOpenMap] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);
      const [sidebar, setSidebar] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);
      const [showDashboard, setShowDashboard] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(false);
      Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(() => {
        document.body.style.backgroundColor = "#fff";
        Object(_AppLanguage__WEBPACK_IMPORTED_MODULE_9__["default"])(localStorage.getItem("language"));
      });
    
      const getClinics = () => {
        let url = '/api/getclinics';
        axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url).then(response => {
          setSearchData(response.data.rows);
        }).catch(err => {
          console.log(err);
        });
      };
    
      const getDoctors = () => {
        let url = '/api/getdoctors';
        axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url).then(response => {
          setSearchData(response.data.rows);
        }).catch(err => {
          console.log(err);
        });
      };
    
      const getClinicSpecialities = () => {
        let data = [];
        let url = '/api/clinicspecialities/' + language;
        axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url).then(response => {
          response.data.rows.map(clinicsdata => {
            data.push({
              value: clinicsdata.key,
              label: clinicsdata.key
            });
          });
    
          if (data.length !== 0) {
            setClinicSpecialities(data);
          }
        }).catch(err => {
          console.log(err);
        });
      };
    
      const getDoctorSpecialities = () => {
        let data = [];
        let url = '/api/doctorspecialities/' + language;
        axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url, {
          auth: {
            username: "admin",
            password: "Hakeem@738"
          }
        }).then(response => {
          response.data.rows.map(doctordata => {
            data.push({
              value: doctordata.key,
              label: doctordata.key
            });
          });
    
          if (data.length !== 0) {
            setDoctorSpecialities(data);
          }
        }).catch(err => {
          console.log(err);
        });
      };
    
      const getClinicLocations = () => {
        let data = [];
        let url = '/api/cliniclocations/' + language;
        axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url).then(response => {
          response.data.rows.map(clinicsdata => {
            data.push({
              value: clinicsdata.key,
              label: clinicsdata.key
            });
          });
    
          if (data.length !== 0) {
            setClinicLocations(data);
          }
        }).catch(err => {
          console.log(err);
        });
      };
    
      const getDoctorLocations = () => {
        let data = [];
        let url = '/api/doctorlocations/' + language;
        axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url).then(response => {
          response.data.rows.map(doctordata => {
            data.push({
              value: doctordata.key,
              label: doctordata.key
            });
          });
    
          if (data.length !== 0) {
            setDoctorLocations(data);
          }
        }).catch(err => {
          console.log(err);
        });
      };
    
      const handleClinicSpeciality = clinicspeciality => {
        setClinicSpeciality(clinicspeciality);
        setSpeciality(clinicspeciality);
      };
    
      const handleDoctorSpeciality = doctorspeciality => {
        setDoctorSpeciality(doctorspeciality);
        setSpeciality(doctorspeciality);
      };
    
      const handleClinicLocation = cliniclocation => {
        setClinicLocation(cliniclocation);
        setLocation(cliniclocation);
      };
    
      const handleDoctorLocation = doctorlocation => {
        setDoctorLocation(doctorlocation);
        setLocation(doctorlocation);
      };
    
      Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(() => {
        // getClinics();
        // getDoctors();
        getAllData();
        getClinicSpecialities();
        getClinicLocations();
        getDoctorSpecialities();
        getDoctorLocations();
      }, []);
    
      const updateStatus = value => {
        if (value === "clinic") {
          setClinicColor("#5773ff");
          setDoctorColor("");
        } else {
          setDoctorColor("#5773ff");
          setClinicColor("");
        }
    
        setChange(value);
        setState(initialState);
        setLoginState(initialLoginState); // setDoctorSpeciality('');
        // setClinicSpeciality('');
      };
    
      const logout = () => {
        localStorage.removeItem("language");
        localStorage.removeItem("loggedin"); // props.history.push("/signin");
    
        window.location.href = "/";
      };
    
      const filterSearch = () => {
        showFilter(!filter);
      };
    
      const handleFirstFilter = e => {
        // showFilter(false);
        if (e.target.name === "all") {
          setState({ ...state,
            all: e.target.checked,
            doctors: e.target.checked,
            clinics: e.target.checked
          });
        } else if (e.target.name === "doctors") {
          setState({ ...state,
            doctors: e.target.checked,
            clinics: false,
            all: false
          });
        } else if (e.target.name === "clinics") {
          setState({ ...state,
            clinics: e.target.checked,
            doctors: false,
            all: false
          });
        }
      };
    
      const getAllData = () => {
        let url = '/api/getalldata';
        axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url).then(response => {
          setSearchData(response.data.rows);
        }).catch(err => {
          console.log(err);
        });
      };
    
      const ApplyFilter = () => {
        setSaveFilter(true);
        showFilter(false);
    
        if (state.all) {
          getAllData();
          setSpeciality(null);
          setLocation(null);
        } else if (state.doctors === true) {
          if (doctorspeciality !== null && doctorLocation === null) {
            let url = '/api/doctorsdatabyspeciality/' + language + "/" + doctorspeciality.value;
            axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url).then(response => {
              if (response.data.rows.length === 0) {
                setSearchData({
                  nodata: "nodata"
                });
              } else {
                setSearchData(response.data.rows);
                setSpeciality(doctorspeciality);
                setLocation(null);
              }
            }).catch(err => {
              console.log(err);
            });
          } else if (doctorLocation !== null && doctorspeciality === null) {
            let url = '/api/doctorsdatabylocation/' + language + "/" + doctorLocation.value;
            axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url).then(response => {
              if (response.data.rows.length === 0) {
                setSearchData({
                  nodata: "nodata"
                });
              } else {
                setSearchData(response.data.rows);
                setLocation(doctorLocation);
                setSpeciality(null);
              }
            }).catch(err => {
              console.log(err);
            });
          } else if (doctorspeciality !== null && doctorLocation !== null) {
            let url = '/api/doctorsdatabyspecialityandlocation/' + language + "/" + doctorspeciality.value + "/" + doctorLocation.value;
            axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url).then(response => {
              if (response.data.rows.length === 0) {
                setSearchData({
                  nodata: "nodata"
                });
              } else {
                setSearchData(response.data.rows);
                setLocation(doctorLocation);
                setSpeciality(doctorspeciality);
              }
            }).catch(err => {
              console.log(err);
            });
          } else if (doctorspeciality === null) {
            getDoctors();
            setSpeciality(null);
          } else if (doctorLocation === null) {
            getDoctors();
            setLocation(null);
          } else if (doctorspeciality === null || doctorLocation === null) {
            getDoctors();
            setLocation(null);
            setSpeciality(null);
          }
        } else if (state.clinics) {
          if (clinicspeciality !== null && clinicLocation === null) {
            let url = '/api/clinicsdatabyspeciality/' + language + "/" + clinicspeciality.value;
            axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url).then(response => {
              if (response.data.rows.length === 0) {
                setSearchData({
                  nodata: "nodata"
                });
              } else {
                setSearchData(response.data.rows);
                setSpeciality(clinicspeciality);
                setLocation(null);
              }
            }).catch(err => {
              console.log(err);
            });
          } else if (clinicLocation !== null && clinicspeciality === null) {
            let url = '/api/clinicsdatabylocation/' + language + "/" + clinicLocation.value;
            axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url).then(response => {
              if (response.data.rows.length === 0) {
                setSearchData({
                  nodata: "nodata"
                });
              } else {
                setSearchData(response.data.rows);
                setLocation(clinicspeciality);
                setSpeciality(null);
              }
            }).catch(err => {
              console.log(err);
            });
          } else if (clinicspeciality !== null && clinicLocation !== null) {
            let url = '/api/clinicsdatabyspecialityandlocation/' + language + "/" + clinicspeciality.value + "/" + clinicLocation.value;
            axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url).then(response => {
              if (response.data.rows.length === 0) {
                setSearchData({
                  nodata: "nodata"
                });
              } else {
                setSearchData(response.data.rows);
                setLocation(clinicLocation);
                setSpeciality(clinicspeciality);
              }
            }).catch(err => {
              console.log(err);
            });
          } else if (clinicspeciality === null) {
            getClinics();
            setSpeciality(null);
          } else if (clinicLocation === null) {
            getClinics();
            setLocation(null);
          } else if (clinicspeciality === null && clinicLocation === null) {
            getClinics();
            setLocation(null);
            setSpeciality(null);
          }
        }
      };
    
      const colourStyles = {
        option: (styles, {
          data,
          isDisabled,
          isFocused,
          isSelected
        }) => {
          // const color = chroma(data.color);
          // console.log({ data, isDisabled, isFocused, isSelected });
          return { ...styles,
            backgroundColor: isFocused ? "#2A2E43" : null,
            color: "#78849E"
          };
        }
      };
    
      const handleSearch = () => {
        showSearchBox(true);
      };
    
      const handleHome = () => {
        showSearchBox(false);
        setOpenMap(false);
        props.history.push('/home');
      };
    
      const handleDashboard = () => {
        showSearchBox(false);
        setOpenMap(false);
        setShowDashboard(true);
      };
    
      const updateSearch = e => {
        setSearchValue(e.target.value);
    
        if (e.target.value === "") {
          getAllData();
        } else {
          let url = "";
    
          if (language === "ar") {
            url = `${"http://192.168.43.133:5984"}/hakeem/_design/alldatabyspecialityarabic/_view/alldatabyspecialityarabic?startkey=%22${e.target.value}%22&endkey=%22${e.target.value + "Z"}%22&include_docs=true`;
          } else {
            url = `${"http://192.168.43.133:5984"}/hakeem/_design/alldatabyspeciality/_view/alldatabyspeciality?startkey=%22${e.target.value.charAt(0).toUpperCase() + e.target.value.slice(1)}%22&endkey=%22${e.target.value.charAt(0).toUpperCase() + e.target.value.slice(1) + "Z"}%22&include_docs=true`;
          }
    
          axios__WEBPACK_IMPORTED_MODULE_4___default.a.get(url, {
            auth: {
              username: "admin",
              password: "Hakeem@738"
            }
          }).then(response => {
            if (response.data.rows.length === 0) {
              setSearchData({
                nodata: "nodata"
              });
            } else {
              setSearchData(response.data.rows);
            }
          }).catch(err => {
            console.log(err);
          });
        }
      };
    
      const handleMaps = () => {
        setOpenMap(true); // props.history.push("/profile")
      };
    
      const handleSidebar = () => {
        setSidebar(!sidebar);
      };
    
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
          class: "container-center-horizontal",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
            class: "clinic-doctor screen",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
              className: "doctor-filter",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                className: "doctor-filter-search",
                src: "/static/img/filter.svg",
                alt: "Card image cap",
                onClick: filterSearch
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 536,
                columnNumber: 13
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                className: "show-data",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                  className: "show-speciality",
                  children: speciality !== null ? speciality.value : ""
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 538,
                  columnNumber: 15
                }, this), speciality !== null && location !== null ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                  className: "show-between",
                  children: "."
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 539,
                  columnNumber: 59
                }, this) : "", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                  className: "show-location",
                  children: location !== null ? location.value : ""
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 540,
                  columnNumber: 15
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 537,
                columnNumber: 13
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 535,
              columnNumber: 11
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
              className: "search-box",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                type: "text",
                name: "mobileNumber",
                value: searchValue // onChange={(event) =>
                //   event.target.value ?
                //     setLoginState({ ...loginState, mobileNumber: event.target.value, mobileNumberError: "" }) : setLoginState({ ...loginState, mobileNumber: event.target.value, mobileNumberError: "Mobile Number is required" })
                // }
                ,
                onChange: e => updateSearch(e),
                placeholder: props.label.search_search
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 545,
                columnNumber: 13
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 544,
              columnNumber: 12
            }, this), filter ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_2__["Fragment"], {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                className: "filter-card",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Form"], {
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["FormGroup"], {
                      check: true,
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Label"], {
                        check: true,
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                          type: "checkbox",
                          name: "all",
                          onChange: e => handleFirstFilter(e),
                          checked: state.all
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 566,
                          columnNumber: 23
                        }, this), ' ', props.label.search_filter_all]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 565,
                        columnNumber: 21
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 564,
                      columnNumber: 19
                    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["FormGroup"], {
                      check: true,
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Label"], {
                        check: true,
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                          type: "checkbox",
                          name: "doctors",
                          onChange: e => handleFirstFilter(e),
                          checked: state.doctors
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 573,
                          columnNumber: 23
                        }, this), ' ', props.label.search_filter_doctors]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 572,
                        columnNumber: 21
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 571,
                      columnNumber: 19
                    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["FormGroup"], {
                      check: true,
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Label"], {
                        check: true,
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                          type: "checkbox",
                          name: "clinics",
                          onChange: e => handleFirstFilter(e),
                          checked: state.clinics
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 580,
                          columnNumber: 23
                        }, this), ' ', props.label.search_filter_clinics]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 579,
                        columnNumber: 21
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 578,
                      columnNumber: 19
                    }, this), state.doctors === true && state.all === false ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_2__["Fragment"], {
                      children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(react_select__WEBPACK_IMPORTED_MODULE_7__["default"], {
                        className: "basic-single",
                        classNamePrefix: "select",
                        defaultValue: 0 // isDisabled={isDisabled}
                        // isLoading={isLoading}
                        ,
                        isClearable: true // isRtl={isRtl}
                        ,
                        isSearchable: true,
                        name: "speciality",
                        options: doctorSpecialities,
                        value: doctorspeciality,
                        onChange: handleDoctorSpeciality,
                        placeholder: props.label.search_filter_select_speciality,
                        styles: colourStyles
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 586,
                        columnNumber: 79
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(react_select__WEBPACK_IMPORTED_MODULE_7__["default"], {
                        className: "basic-single",
                        classNamePrefix: "select",
                        defaultValue: 0 // isDisabled={isDisabled}
                        // isLoading={isLoading}
                        ,
                        isClearable: true // isRtl={isRtl}
                        ,
                        isSearchable: true,
                        name: "location",
                        options: doctorLocations,
                        value: doctorLocation,
                        onChange: handleDoctorLocation,
                        placeholder: props.label.search_filter_select_location,
                        styles: colourStyles
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 602,
                        columnNumber: 21
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 586,
                      columnNumber: 68
                    }, this) : state.clinics === true && state.all === false ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_2__["Fragment"], {
                      children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(react_select__WEBPACK_IMPORTED_MODULE_7__["default"], {
                        className: "basic-single",
                        classNamePrefix: "select",
                        defaultValue: 0 // isDisabled={isDisabled}
                        // isLoading={isLoading}
                        ,
                        isClearable: true // isRtl={isRtl}
                        ,
                        isSearchable: true,
                        name: "speciality",
                        options: clinicSpecialities,
                        value: clinicspeciality,
                        onChange: handleClinicSpeciality,
                        placeholder: props.label.search_filter_select_speciality
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 621,
                        columnNumber: 82
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(react_select__WEBPACK_IMPORTED_MODULE_7__["default"], {
                        className: "basic-single",
                        classNamePrefix: "select",
                        defaultValue: 0 // isDisabled={isDisabled}
                        // isLoading={isLoading}
                        ,
                        isClearable: true // isRtl={isRtl}
                        ,
                        isSearchable: true,
                        name: "location",
                        options: clinicLocations,
                        value: clinicLocation,
                        onChange: handleClinicLocation,
                        placeholder: props.label.search_filter_select_location,
                        styles: colourStyles
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 637,
                        columnNumber: 23
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 621,
                      columnNumber: 71
                    }, this) : "", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                      className: "filter-button",
                      onClick: ApplyFilter,
                      children: props.label.search_filter_save
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 656,
                      columnNumber: 19
                    }, this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 563,
                    columnNumber: 17
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 562,
                  columnNumber: 15
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 561,
                columnNumber: 32
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 561,
              columnNumber: 22
            }, this) : "", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
              className: "content-doctor",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__["default"], {
                container: true,
                spacing: 3,
                direction: "row",
                justify: "flex-start",
                alignItems: "flex-start",
                children: searchData.length !== 0 && searchData.nodata === "nodata" ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                  className: "no-data",
                  children: props.label.search_nodata
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 675,
                  columnNumber: 60
                }, this) : searchData.length === 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_10___default.a, {
                  color: "#ffffff",
                  loading: "false",
                  css: " display: block;\nmargin-top: 250px;\nborder-color: #2A2E43;margin-left:auto;margin-right:auto;",
                  size: 35
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 676,
                  columnNumber: 1
                }, this) : allData && openMap === false && searchData.length !== 0 && searchData.map((data, key) => {
                  if (data.doc.tableName === "doctors") {
                    if (data.doc.category === "regular") {
                      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_2__["Fragment"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__["default"], {
                          item: true,
                          xs: 12,
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                            className: "regular-card",
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                              className: "sub-card",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
                                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                  className: "photo-text",
                                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                                    className: "photo-registered-doctor",
                                    src: data.doc.profilePic !== undefined ? "http://192.168.43.133:3000/static/" + data.doc.profilePic : "http://192.168.43.133:3000/static/" + "img/doctors/defaultdoctor.png",
                                    alt: "img"
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 689,
                                    columnNumber: 35
                                  }, this)
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 688,
                                  columnNumber: 33
                                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                    className: "sub-doctor-speciality",
                                    children: language === "en" && data.doc.specialities !== undefined ? data.doc.specialities[0] : language === "en" && data.doc.specialitiesAr !== undefined ? data.doc.specialitiesAr[0] : ""
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 692,
                                    columnNumber: 37
                                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                    className: "doctor-name",
                                    children: language === "en" ? data.doc.doctorNameEn : data.doc.doctorNameAr
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 693,
                                    columnNumber: 37
                                  }, this)]
                                }, void 0, true, {
                                  fileName: _jsxFileName,
                                  lineNumber: 691,
                                  columnNumber: 35
                                }, this)]
                              }, void 0, true, {
                                fileName: _jsxFileName,
                                lineNumber: 687,
                                columnNumber: 33
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 686,
                              columnNumber: 31
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 685,
                            columnNumber: 29
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 684,
                          columnNumber: 27
                        }, this), (key + 1) % 3 === 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__["default"], {
                          item: true,
                          xs: 12,
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                            className: "add-card",
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardTitle"], {
                                tag: "h5",
                                children: props.label.search_advertisement
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 703,
                                columnNumber: 35
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 702,
                              columnNumber: 33
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 701,
                            columnNumber: 31
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 700,
                          columnNumber: 29
                        }, this) : ""]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 683,
                        columnNumber: 25
                      }, this);
                    } else if (data.doc.category === "registered") {
                      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_2__["Fragment"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__["default"], {
                          item: true,
                          xs: 12,
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                            className: "registered-card",
                            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                              className: "sub-card",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
                                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                  className: "photo-text",
                                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                                    className: "photo-registered-doctor",
                                    src: data.doc.profilePic !== undefined ? "http://192.168.43.133:3000/static/" + data.doc.profilePic : "http://192.168.43.133:3000/static/" + "img/doctors/defaultdoctor.png",
                                    alt: "img"
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 719,
                                    columnNumber: 35
                                  }, this)
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 718,
                                  columnNumber: 33
                                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                    className: "sub-doctor-speciality",
                                    children: language === "en" && data.doc.specialities !== undefined ? data.doc.specialities[0] : language === "en" && data.doc.specialitiesAr !== undefined ? data.doc.specialitiesAr[0] : ""
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 722,
                                    columnNumber: 35
                                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                    className: "doctor-name",
                                    children: language === "en" ? data.doc.doctorNameEn : data.doc.doctorNameAr
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 723,
                                    columnNumber: 37
                                  }, this)]
                                }, void 0, true, {
                                  fileName: _jsxFileName,
                                  lineNumber: 721,
                                  columnNumber: 35
                                }, this)]
                              }, void 0, true, {
                                fileName: _jsxFileName,
                                lineNumber: 717,
                                columnNumber: 33
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 716,
                              columnNumber: 31
                            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {}, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 727,
                              columnNumber: 31
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 715,
                            columnNumber: 29
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 714,
                          columnNumber: 27
                        }, this), (key + 1) % 3 === 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__["default"], {
                          item: true,
                          xs: 12,
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                            className: "add-card",
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardTitle"], {
                                tag: "h5",
                                children: props.label.search_advertisement
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 735,
                                columnNumber: 35
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 734,
                              columnNumber: 33
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 733,
                            columnNumber: 31
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 732,
                          columnNumber: 29
                        }, this) : ""]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 713,
                        columnNumber: 25
                      }, this);
                    } else if (data.doc.category === "featured") {
                      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_2__["Fragment"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__["default"], {
                          item: true,
                          xs: 12,
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                            className: "featured-card",
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                              className: "sub-card",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
                                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                  className: "photo-text",
                                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                                    className: "photo-registered-doctor",
                                    src: data.doc.profilePic !== undefined ? "http://192.168.43.133:3000/static/" + data.doc.profilePic : "http://192.168.43.133:3000/static/" + "img/doctors/defaultdoctor.png",
                                    alt: "img"
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 750,
                                    columnNumber: 35
                                  }, this)
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 749,
                                  columnNumber: 33
                                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                    className: "sub-doctor-speciality",
                                    children: language === "en" && data.doc.specialities !== undefined ? data.doc.specialities[0] : language === "en" && data.doc.specialitiesAr !== undefined ? data.doc.specialitiesAr[0] : ""
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 753,
                                    columnNumber: 35
                                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                    className: "doctor-name",
                                    children: language === "en" ? data.doc.doctorNameEn : data.doc.doctorNameAr
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 754,
                                    columnNumber: 37
                                  }, this)]
                                }, void 0, true, {
                                  fileName: _jsxFileName,
                                  lineNumber: 752,
                                  columnNumber: 35
                                }, this)]
                              }, void 0, true, {
                                fileName: _jsxFileName,
                                lineNumber: 748,
                                columnNumber: 33
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 747,
                              columnNumber: 31
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 746,
                            columnNumber: 29
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 745,
                          columnNumber: 27
                        }, this), (key + 1) % 3 === 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__["default"], {
                          item: true,
                          xs: 12,
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                            className: "add-card",
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardTitle"], {
                                tag: "h5",
                                children: props.label.search_advertisement
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 764,
                                columnNumber: 35
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 763,
                              columnNumber: 33
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 762,
                            columnNumber: 31
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 761,
                          columnNumber: 29
                        }, this) : ""]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 744,
                        columnNumber: 25
                      }, this);
                    }
                  } else if (data.doc.tableName === "clinics") {
                    if (data.doc.category === "regular") {
                      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_2__["Fragment"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__["default"], {
                          item: true,
                          xs: 12,
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                            className: "regular-card",
                            style: {
                              backgroundImage: `url(${"http://192.168.43.133:3000/static/" + data.doc.profilePic})`
                            },
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                              className: "sub-card",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
                                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                  className: "photo-text",
                                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                                    className: "photo-registered-clinic",
                                    src: "http://192.168.43.133:3000/static/" + data.doc.profilePic,
                                    alt: "Card image cap"
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 786,
                                    columnNumber: 37
                                  }, this)
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 785,
                                  columnNumber: 35
                                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                    className: "clinic-name",
                                    children: language === "en" ? data.doc.clinicNameEn : data.doc.clinicNameAr
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 789,
                                    columnNumber: 37
                                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                    className: "sub-clinic-city",
                                    children: language === "en" ? data.doc.cityEn : data.doc.cityAr
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 790,
                                    columnNumber: 37
                                  }, this)]
                                }, void 0, true, {
                                  fileName: _jsxFileName,
                                  lineNumber: 788,
                                  columnNumber: 35
                                }, this)]
                              }, void 0, true, {
                                fileName: _jsxFileName,
                                lineNumber: 784,
                                columnNumber: 33
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 783,
                              columnNumber: 31
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 780,
                            columnNumber: 29
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 779,
                          columnNumber: 27
                        }, this), (key + 1) % 3 === 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__["default"], {
                          item: true,
                          xs: 12,
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                            className: "add-card",
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardTitle"], {
                                tag: "h5",
                                children: props.label.search_advertisement
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 800,
                                columnNumber: 35
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 799,
                              columnNumber: 33
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 798,
                            columnNumber: 31
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 797,
                          columnNumber: 29
                        }, this) : ""]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 778,
                        columnNumber: 25
                      }, this);
                    } else if (data.doc.category === "registered") {
                      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_2__["Fragment"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__["default"], {
                          item: true,
                          xs: 12,
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                            className: "registered-card",
                            style: {
                              backgroundImage: `url(${"http://192.168.43.133:3000/static/" + data.doc.profilePic})`
                            },
                            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                              className: "sub-card",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
                                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                  className: "photo-text",
                                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                                    className: "photo-registered-clinic",
                                    src: "http://192.168.43.133:3000/static/" + data.doc.profilePic,
                                    alt: "Card image cap"
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 818,
                                    columnNumber: 37
                                  }, this)
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 817,
                                  columnNumber: 35
                                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                    className: "clinic-name",
                                    children: language === "en" ? data.doc.clinicNameEn : data.doc.clinicNameAr
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 821,
                                    columnNumber: 37
                                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                    className: "sub-clinic-city",
                                    children: language === "en" ? data.doc.cityEn : data.doc.cityAr
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 822,
                                    columnNumber: 37
                                  }, this)]
                                }, void 0, true, {
                                  fileName: _jsxFileName,
                                  lineNumber: 820,
                                  columnNumber: 35
                                }, this)]
                              }, void 0, true, {
                                fileName: _jsxFileName,
                                lineNumber: 816,
                                columnNumber: 33
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 815,
                              columnNumber: 31
                            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {}, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 826,
                              columnNumber: 31
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 811,
                            columnNumber: 29
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 810,
                          columnNumber: 27
                        }, this), (key + 1) % 3 === 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__["default"], {
                          item: true,
                          xs: 12,
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                            className: "add-card",
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardTitle"], {
                                tag: "h5",
                                children: props.label.search_advertisement
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 834,
                                columnNumber: 35
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 833,
                              columnNumber: 33
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 832,
                            columnNumber: 31
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 831,
                          columnNumber: 29
                        }, this) : ""]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 809,
                        columnNumber: 25
                      }, this);
                    } else if (data.doc.category === "featured") {
                      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_2__["Fragment"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__["default"], {
                          item: true,
                          xs: 12,
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                            className: "featured-card",
                            style: {
                              backgroundImage: `url(${"http://192.168.43.133:3000/static/" + data.doc.profilePic})`
                            },
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                              className: "sub-card",
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
                                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                  className: "photo-text",
                                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
                                    className: "photo-registered-clinic",
                                    src: "http://192.168.43.133:3000/static/" + data.doc.profilePic,
                                    alt: "Card image cap"
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 852,
                                    columnNumber: 37
                                  }, this)
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 851,
                                  columnNumber: 35
                                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                    className: "clinic-name",
                                    children: language === "en" ? data.doc.clinicNameEn : data.doc.clinicNameAr
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 855,
                                    columnNumber: 37
                                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
                                    className: "sub-clinic-city",
                                    children: language === "en" ? data.doc.cityEn : data.doc.cityAr
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 856,
                                    columnNumber: 37
                                  }, this)]
                                }, void 0, true, {
                                  fileName: _jsxFileName,
                                  lineNumber: 854,
                                  columnNumber: 35
                                }, this)]
                              }, void 0, true, {
                                fileName: _jsxFileName,
                                lineNumber: 850,
                                columnNumber: 33
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 849,
                              columnNumber: 31
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 845,
                            columnNumber: 29
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 844,
                          columnNumber: 27
                        }, this), (key + 1) % 3 === 0 ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_5__["default"], {
                          item: true,
                          xs: 12,
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Card"], {
                            className: "add-card",
                            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardBody"], {
                              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["CardTitle"], {
                                tag: "h5",
                                children: props.label.search_advertisement
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 866,
                                columnNumber: 35
                              }, this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 865,
                              columnNumber: 33
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 864,
                            columnNumber: 31
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 863,
                          columnNumber: 29
                        }, this) : ""]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 843,
                        columnNumber: 25
                      }, this);
                    }
                  }
                })
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 666,
                columnNumber: 13
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 664,
              columnNumber: 11
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 534,
            columnNumber: 9
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 533,
          columnNumber: 7
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
          className: "bottom-menu",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
            className: "heart-container",
            children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
              src: "/static/img/filter_black.svg",
              alt: "Card image cap",
              onClick: filterSearch,
              className: "like"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 887,
              columnNumber: 43
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 887,
            columnNumber: 9
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
            className: "heart-container",
            children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
              src: "/static/img/feature/maps.png",
              onClick: handleMaps,
              className: "maps"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 889,
              columnNumber: 43
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 889,
            columnNumber: 9
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
            className: "chat-container",
            children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("img", {
              src: "/static/img/chat.png",
              className: "chat"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 891,
              columnNumber: 42
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 891,
            columnNumber: 9
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 886,
          columnNumber: 7
        }, this), openMap ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
          className: "map-container",
          children: ["    ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_MapContainer__WEBPACK_IMPORTED_MODULE_8__["default"], {
            latitude: searchData.length !== 0 ? searchData[0].doc.latitude : "",
            longitude: searchData.length !== 0 ? searchData[0].doc.longitude : "",
            profilePic: searchData.length !== 0 ? searchData[0].doc.profilePic : "",
            searchData: searchData.length !== 0 ? searchData : ""
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 894,
            columnNumber: 53
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 894,
          columnNumber: 18
        }, this) : ""]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 530,
        columnNumber: 5
      }, this);
    }
    
    _s(Search, "De198+yMEpnmNlrtkc/6MvexaTk=", false, function () {
      return [react_toast_notifications__WEBPACK_IMPORTED_MODULE_6__["useToasts"]];
    });
    
    _c = Search;
    /* harmony default export */ __webpack_exports__["default"] = (_c2 = Object(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["withRouter"])(Search));
    
    var _c, _c2;
    
    __webpack_require__.$Refresh$.register(_c, "Search");
    __webpack_require__.$Refresh$.register(_c2, "%default%");
    
    const currentExports = __react_refresh_utils__.getModuleExports(module.i);
    __react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);
    
    if (true) {
      const isHotUpdate = !!module.hot.data;
      const prevExports = isHotUpdate ? module.hot.data.prevExports : null;
    
      if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
        module.hot.dispose(
          /**
           * A callback to performs a full refresh if React has unrecoverable errors,
           * and also caches the to-be-disposed module.
           * @param {*} data A hot module data object from Webpack HMR.
           * @returns {void}
           */
          function hotDisposeCallback(data) {
            // We have to mutate the data object to get data registered and cached
            data.prevExports = currentExports;
          }
        );
        module.hot.accept(
          /**
           * An error handler to allow self-recovering behaviours.
           * @param {Error} error An error occurred during evaluation of a module.
           * @returns {void}
           */
          function hotErrorHandler(error) {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.handleRuntimeError(error);
            }
    
            if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
              if (window.onHotAcceptError) {
                window.onHotAcceptError(error.message);
              }
            }
    
            __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
          }
        );
    
        if (isHotUpdate) {
          if (
            __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
            __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
          ) {
            module.hot.invalidate();
          } else {
            __react_refresh_utils__.enqueueUpdate(
              /**
               * A function to dismiss the error overlay after performing React refresh.
               * @returns {void}
               */
              function updateCallback() {
                if (
                  typeof __react_refresh_error_overlay__ !== 'undefined' &&
                  __react_refresh_error_overlay__
                ) {
                  __react_refresh_error_overlay__.clearRuntimeErrors();
                }
              }
            );
          }
        }
      } else {
        if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
          module.hot.invalidate();
        }
      }
    }
    /* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))
    
    /***/ }),
    
    /***/ "./src/components/Sidebar.jsx":
    /*!************************************!*\
      !*** ./src/components/Sidebar.jsx ***!
      \************************************/
    /*! exports provided: default */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    __webpack_require__.r(__webpack_exports__);
    /* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
    /* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
    /* harmony import */ var react_burger_menu__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-burger-menu */ "./node_modules/react-burger-menu/lib/BurgerMenu.js");
    /* harmony import */ var react_burger_menu__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_burger_menu__WEBPACK_IMPORTED_MODULE_2__);
    /* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__);
    __webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
    __webpack_require__.$Refresh$.setup(module.i);
    
    var _jsxFileName = "/home/mounika/Desktop/hakeem-app/src/components/Sidebar.jsx";
    
    
    
    
    
    
    const Sidebar = props => {
      const logout = () => {
        localStorage.removeItem("language");
        localStorage.removeItem("loggedin");
        localStorage.removeItem("guest"); // props.history.push("/signin");
    
        window.location.href = "/";
      };
    
      const handleSearch = () => {
        props.history.push("/search");
      };
    
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
        style: {
          direction: "ltr"
        },
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("p", {
          className: "where-to",
          children: props.label.search_whereto
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 20,
          columnNumber: 8
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(react_burger_menu__WEBPACK_IMPORTED_MODULE_2__["slide"], {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("a", {
            id: "home",
            className: "menu-item",
            href: "#",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
              className: "userimage-container",
              children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("img", {
                src: "/static/img/patient.png"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 22,
                columnNumber: 91
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 22,
              columnNumber: 53
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 22,
            columnNumber: 9
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("a", {
            id: "home",
            className: "menu-item",
            href: "#",
            onClick: () => handleSearch(),
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("img", {
              src: "/static/img/home.svg",
              className: "menu-image-container"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 23,
              columnNumber: 82
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 23,
            columnNumber: 9
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("a", {
            id: "about",
            className: "menu-item",
            href: "#",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("img", {
              src: "/static/img/calendar1.svg",
              className: "menu-image-container"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 24,
              columnNumber: 54
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 24,
            columnNumber: 9
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("a", {
            id: "contact",
            className: "menu-item",
            href: "#",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("img", {
              src: "/static/img/user.svg",
              className: "menu-image-container"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 25,
              columnNumber: 56
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 25,
            columnNumber: 9
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("a", {
            className: "menu-item",
            href: "#",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("img", {
              src: "/static/img/info.svg",
              className: "menu-image-container"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 26,
              columnNumber: 44
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 26,
            columnNumber: 9
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("a", {
            className: "menu-item",
            href: "#",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("img", {
              src: "/static/img/logout.svg",
              onClick: logout,
              className: "menu-image-container"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 27,
              columnNumber: 44
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 27,
            columnNumber: 9
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 21,
          columnNumber: 9
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 5
      }, undefined);
    };
    
    _c = Sidebar;
    /* harmony default export */ __webpack_exports__["default"] = (_c2 = Object(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["withRouter"])(Sidebar));
    
    var _c, _c2;
    
    __webpack_require__.$Refresh$.register(_c, "Sidebar");
    __webpack_require__.$Refresh$.register(_c2, "%default%");
    
    const currentExports = __react_refresh_utils__.getModuleExports(module.i);
    __react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);
    
    if (true) {
      const isHotUpdate = !!module.hot.data;
      const prevExports = isHotUpdate ? module.hot.data.prevExports : null;
    
      if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
        module.hot.dispose(
          /**
           * A callback to performs a full refresh if React has unrecoverable errors,
           * and also caches the to-be-disposed module.
           * @param {*} data A hot module data object from Webpack HMR.
           * @returns {void}
           */
          function hotDisposeCallback(data) {
            // We have to mutate the data object to get data registered and cached
            data.prevExports = currentExports;
          }
        );
        module.hot.accept(
          /**
           * An error handler to allow self-recovering behaviours.
           * @param {Error} error An error occurred during evaluation of a module.
           * @returns {void}
           */
          function hotErrorHandler(error) {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.handleRuntimeError(error);
            }
    
            if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
              if (window.onHotAcceptError) {
                window.onHotAcceptError(error.message);
              }
            }
    
            __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
          }
        );
    
        if (isHotUpdate) {
          if (
            __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
            __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
          ) {
            module.hot.invalidate();
          } else {
            __react_refresh_utils__.enqueueUpdate(
              /**
               * A function to dismiss the error overlay after performing React refresh.
               * @returns {void}
               */
              function updateCallback() {
                if (
                  typeof __react_refresh_error_overlay__ !== 'undefined' &&
                  __react_refresh_error_overlay__
                ) {
                  __react_refresh_error_overlay__.clearRuntimeErrors();
                }
              }
            );
          }
        }
      } else {
        if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
          module.hot.invalidate();
        }
      }
    }
    /* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))
    
    /***/ }),
    
    /***/ "./src/components/Signin.jsx":
    /*!***********************************!*\
      !*** ./src/components/Signin.jsx ***!
      \***********************************/
    /*! exports provided: default */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    __webpack_require__.r(__webpack_exports__);
    /* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../App.css */ "./src/App.css");
    /* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_App_css__WEBPACK_IMPORTED_MODULE_0__);
    /* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
    /* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__);
    __webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
    __webpack_require__.$Refresh$.setup(module.i);
    
    var _jsxFileName = "/home/mounika/Desktop/hakeem-app/src/components/Signin.jsx",
        _s = __webpack_require__.$Refresh$.signature();
    
    
    
    
    
    
    const initialState = {
      mobileNumber: '',
      password: "",
      mobileNumberError: "",
      passwordError: ""
    };
    
    function Signin(props) {
      _s();
    
      const [state, setState] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(initialState);
      Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(() => {
        document.body.style.backgroundColor = "#fff";
      });
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("input", {
          type: "hidden",
          id: "anPageName",
          name: "page",
          value: "sign-in"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 25,
          columnNumber: 7
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
          className: "container-center-horizontal",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
            className: "sign-in screen",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
              className: "bggray-C61RwL",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("img", {
                className: "bg-CZcDTC",
                src: "img/bg-3@1x.png"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 28,
                columnNumber: 42
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 28,
              columnNumber: 11
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
              className: "content-C61RwL",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                className: "buttonslargegreen-xUsx1L",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                  className: "bg-4SZvY2",
                  children: "CONTINUE"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 31,
                  columnNumber: 15
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 30,
                columnNumber: 13
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                className: "textfields-xUsx1L",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                  className: "x03-9vz9IC",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                    className: "textfield-vNiHFc",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["FormGroup"], {
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                        type: "text",
                        name: "mobileNumber",
                        value: state.mobileNumber,
                        onChange: event => event.target.value ? setState({ ...state,
                          mobileNumber: event.target.value
                        }) : setState({ ...state,
                          mobileNumber: event.target.value
                        }),
                        className: "bg-pshOva",
                        placeholder: "Phone #"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 39,
                        columnNumber: 21
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 38,
                      columnNumber: 19
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 37,
                    columnNumber: 17
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 36,
                  columnNumber: 15
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                  className: "x13-9vz9IC",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                    className: "textfield-1uxxOd",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["FormGroup"], {
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                        type: "password",
                        name: "password",
                        value: state.password,
                        onChange: event => event.target.value ? setState({ ...state,
                          password: event.target.value
                        }) : setState({ ...state,
                          password: event.target.value
                        }),
                        className: "bg-3nzt4I",
                        placeholder: "Password"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 58,
                        columnNumber: 21
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 57,
                      columnNumber: 19
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 56,
                    columnNumber: 17
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 55,
                  columnNumber: 15
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 35,
                columnNumber: 13
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                className: "forgot-password-xUsx1L",
                children: "FORGOT PASSWORD"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 76,
                columnNumber: 13
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 29,
              columnNumber: 11
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
              className: "top-C61RwL",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                className: "tab2-options1-7AdSuJ",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                  className: "bg-Wmv07K"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 81,
                  columnNumber: 15
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                  className: "sign-in-Wmv07K",
                  children: "SIGN IN"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 82,
                  columnNumber: 15
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                  className: "sign-up-Wmv07K",
                  children: "SIGN UP"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 83,
                  columnNumber: 15
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                  className: "divider-Wmv07K"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 84,
                  columnNumber: 15
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                  className: "gradient-Wmv07K",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                    className: "rectangle-DJwlLK"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 86,
                    columnNumber: 17
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                    className: "rectangle-5DR9Zg"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 87,
                    columnNumber: 17
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                    className: "rectangle-qInBZx"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 88,
                    columnNumber: 17
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                    className: "rectangle-Nclfcv"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 89,
                    columnNumber: 17
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 85,
                  columnNumber: 15
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])("div", {
                  className: "divider-EwvRE5"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 91,
                  columnNumber: 15
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 80,
                columnNumber: 13
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 79,
              columnNumber: 11
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 27,
            columnNumber: 9
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 26,
          columnNumber: 7
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 24,
        columnNumber: 5
      }, this);
    }
    
    _s(Signin, "g9yWDQF6ixWa1r5sfsm7YAeGJG4=");
    
    _c = Signin;
    /* harmony default export */ __webpack_exports__["default"] = (_c2 = Object(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["withRouter"])(Signin));
    
    var _c, _c2;
    
    __webpack_require__.$Refresh$.register(_c, "Signin");
    __webpack_require__.$Refresh$.register(_c2, "%default%");
    
    const currentExports = __react_refresh_utils__.getModuleExports(module.i);
    __react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);
    
    if (true) {
      const isHotUpdate = !!module.hot.data;
      const prevExports = isHotUpdate ? module.hot.data.prevExports : null;
    
      if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
        module.hot.dispose(
          /**
           * A callback to performs a full refresh if React has unrecoverable errors,
           * and also caches the to-be-disposed module.
           * @param {*} data A hot module data object from Webpack HMR.
           * @returns {void}
           */
          function hotDisposeCallback(data) {
            // We have to mutate the data object to get data registered and cached
            data.prevExports = currentExports;
          }
        );
        module.hot.accept(
          /**
           * An error handler to allow self-recovering behaviours.
           * @param {Error} error An error occurred during evaluation of a module.
           * @returns {void}
           */
          function hotErrorHandler(error) {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.handleRuntimeError(error);
            }
    
            if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
              if (window.onHotAcceptError) {
                window.onHotAcceptError(error.message);
              }
            }
    
            __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
          }
        );
    
        if (isHotUpdate) {
          if (
            __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
            __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
          ) {
            module.hot.invalidate();
          } else {
            __react_refresh_utils__.enqueueUpdate(
              /**
               * A function to dismiss the error overlay after performing React refresh.
               * @returns {void}
               */
              function updateCallback() {
                if (
                  typeof __react_refresh_error_overlay__ !== 'undefined' &&
                  __react_refresh_error_overlay__
                ) {
                  __react_refresh_error_overlay__.clearRuntimeErrors();
                }
              }
            );
          }
        }
      } else {
        if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
          module.hot.invalidate();
        }
      }
    }
    /* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))
    
    /***/ }),
    
    /***/ "./src/components/Signup.jsx":
    /*!***********************************!*\
      !*** ./src/components/Signup.jsx ***!
      \***********************************/
    /*! exports provided: default */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    __webpack_require__.r(__webpack_exports__);
    /* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../App.css */ "./src/App.css");
    /* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_App_css__WEBPACK_IMPORTED_MODULE_0__);
    /* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
    /* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
    /* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
    /* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_4__);
    /* harmony import */ var react_toast_notifications__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-toast-notifications */ "./node_modules/react-toast-notifications/dist/index.js");
    /* harmony import */ var react_toast_notifications__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_toast_notifications__WEBPACK_IMPORTED_MODULE_5__);
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__);
    __webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
    __webpack_require__.$Refresh$.setup(module.i);
    
    var _jsxFileName = "/home/mounika/Desktop/hakeem-app/src/components/Signup.jsx",
        _s = __webpack_require__.$Refresh$.signature();
    
    
    
    
    
    
    
    
    const initialState = {
      mobileNumber: '',
      password: "",
      mobileNumberError: "",
      passwordError: "",
      userName: '',
      userNameError: '',
      email: '',
      emailError: '',
      address: '',
      addressError: '',
      city: '',
      cityError: '',
      zipCode: '',
      zipCodeError: '',
      language: '',
      languageError: '',
      role: "",
      roleError: ""
    };
    const initialLoginState = {
      password: "",
      passwordError: "",
      mobileNumber: '',
      mobileNumberError: ''
    };
    
    function Signin(props) {
      _s();
    
      const [state, setState] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(initialState);
      const [change, setChange] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])("signin");
      const [loginState, setLoginState] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(initialLoginState);
      const {
        addToast
      } = Object(react_toast_notifications__WEBPACK_IMPORTED_MODULE_5__["useToasts"])();
      const [signinColor, setSigninColor] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])('#5773ff');
      const [signupColor, setSignupColor] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])('');
      Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(() => {
        document.body.style.backgroundColor = "#2e3649";
      });
    
      const updateStatus = value => {
        if (value === "signin") {
          setSigninColor("#5773ff");
          setSignupColor("");
        } else {
          setSignupColor("#5773ff");
          setSigninColor("");
        }
    
        setChange(value);
        setState(initialState);
        setLoginState(initialLoginState);
      };
    
      const validate = () => {
        let userNameError, emailError, mobileNumberError, passwordError, languageError, roleError;
    
        if (!state.userName) {
          userNameError = 'Name is required';
        }
    
        if (!state.email) {
          emailError = 'Email is required';
        }
    
        if (!state.mobileNumber) {
          mobileNumberError = 'Mobile Number is required';
        }
    
        let mobileRegex = "(0/91)?[6-9][0-9]{9}";
    
        if (state.mobileNumber && !state.mobileNumber.match(mobileRegex)) {
          mobileNumberError = "Invalid Mobile Number";
        }
    
        if (!state.password) {
          passwordError = 'Password is required';
        }
    
        if (!state.role) {
          roleError = 'User Type is required';
        } // let passwordRegex = "/^[A-Za-z]\w{7,14}$/"
        // if (state.password && !state.password.match(passwordRegex)) {
        //   passwordError = "Password should containe one Captial letter, special character";
        // }
    
    
        if (!state.language) {
          languageError = 'Language is required';
        }
    
        if (userNameError || emailError || mobileNumberError || passwordError || languageError || roleError) {
          setState({ ...state,
            userNameError,
            emailError,
            mobileNumberError,
            passwordError,
            languageError,
            roleError
          });
          return false;
        }
    
        return true;
      };
    
      const validateLogin = () => {
        let mobileNumberError, passwordError;
    
        if (!loginState.mobileNumber) {
          mobileNumberError = 'Mobile Number is required';
        }
    
        let mobileRegex = "(0/91)?[6-9][0-9]{9}";
    
        if (loginState.mobileNumber && !loginState.mobileNumber.match(mobileRegex)) {
          mobileNumberError = "Invalid Mobile Number";
        }
    
        if (!loginState.password) {
          passwordError = 'Password is required';
        }
    
        if (mobileNumberError || passwordError) {
          setLoginState({ ...loginState,
            mobileNumberError,
            passwordError
          });
          return false;
        }
    
        return true;
      };
    
      const signup = () => {
        const isValid = validate();
        let url = '/api/user';
    
        if (isValid) {
          axios__WEBPACK_IMPORTED_MODULE_4___default.a.post(url, {
            userName: state.userName,
            email: state.email,
            password: state.password,
            mobileNumber: state.mobileNumber,
            userType: state.role,
            userStatus: 'active',
            language: state.language
          }).then(function (response) {
            console.log(response, "res");
    
            if (response.data.status === 200) {
              addToast('User Registered Successfully', {
                appearance: 'success',
                autoDismiss: true,
                autoDismissTimeout: 1000,
                onDismiss: () => {
                  setState(initialState);
                  localStorage.setItem("language", response.data.language);
                  localStorage.setItem("loggedin", true);
                  localStorage.setItem("role", "user");
                  localStorage.setItem("id", response.data.data._id);
                  props.history.push("/home");
                }
              });
            } else if (response.data.status === 400) {
              addToast('User already exists', {
                appearance: 'error',
                autoDismiss: true,
                autoDismissTimeout: 2000
              });
            }
          }).catch(err => {
            console.log(err);
          });
        }
      };
    
      const signin = () => {
        const isValid = validateLogin();
        let url = '/api/login';
    
        if (isValid) {
          axios__WEBPACK_IMPORTED_MODULE_4___default.a.post(url, {
            mobileNumber: loginState.mobileNumber,
            password: loginState.password
          }).then(function (response) {
            console.log(response, "res");
    
            if (response.data.status === 200) {
              addToast('User Loggedin Successfully', {
                appearance: 'success',
                autoDismiss: true,
                autoDismissTimeout: 1000,
                onDismiss: () => {
                  setState(initialLoginState);
                  localStorage.setItem("language", response.data.language);
                  localStorage.setItem("loggedin", true);
                  localStorage.setItem("role", "user");
                  localStorage.setItem("id", response.data.data._id);
                  localStorage.setItem("rev", response.data.data._rev);
                  props.history.push("/home");
                }
              });
            } else if (response.data.status === 400) {
              addToast('User does not exists', {
                appearance: 'error',
                autoDismiss: true,
                autoDismissTimeout: 2000
              });
            } else if (response.data.status === 401) {
              addToast('Password is incorrect', {
                appearance: 'error',
                autoDismiss: true,
                autoDismissTimeout: 2000
              });
            }
          }).catch(err => {
            console.log(err);
          });
        }
      };
    
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
          class: "container-center-horizontal",
          children: change === "signup" ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
            class: "sign-up-dark screen",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
              class: "top-C61RwL",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                className: "sign-in-SJ3nmS",
                style: {
                  backgroundColor: signinColor
                },
                onClick: () => updateStatus("signin"),
                children: "SIGN IN"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 226,
                columnNumber: 15
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                className: "sign-up-SJ3nmS",
                style: {
                  backgroundColor: signupColor
                },
                onClick: () => updateStatus("signup"),
                children: "SIGN UP"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 227,
                columnNumber: 15
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 225,
              columnNumber: 9
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
              className: "content-signup",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                class: "textfields-signup",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                      type: "text",
                      name: "userName",
                      value: state.userName,
                      onChange: event => event.target.value ? setState({ ...state,
                        userName: event.target.value,
                        userNameError: ""
                      }) : setState({ ...state,
                        userName: event.target.value,
                        userNameError: "Name is required"
                      }),
                      placeholder: "Name"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 233,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 232,
                    columnNumber: 19
                  }, this), state.userNameError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: state.userNameError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 246,
                    columnNumber: 40
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 231,
                  columnNumber: 13
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                      type: "text",
                      name: "email",
                      value: state.email,
                      onChange: event => event.target.value ? setState({ ...state,
                        email: event.target.value,
                        emailError: ""
                      }) : setState({ ...state,
                        email: event.target.value,
                        emailError: "Email is required"
                      }),
                      placeholder: "Email"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 252,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 251,
                    columnNumber: 19
                  }, this), state.emailError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: state.emailError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 267,
                    columnNumber: 37
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 250,
                  columnNumber: 17
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                      type: "password",
                      name: "password",
                      value: state.password,
                      onChange: event => event.target.value ? setState({ ...state,
                        password: event.target.value,
                        passwordError: ""
                      }) : setState({ ...state,
                        password: event.target.value,
                        passwordError: "Password is required"
                      }),
                      placeholder: "Password"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 273,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 272,
                    columnNumber: 19
                  }, this), state.passwordError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: state.passwordError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 287,
                    columnNumber: 40
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 271,
                  columnNumber: 17
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                      type: "text",
                      name: "mobileNumber",
                      value: state.mobileNumber,
                      onChange: event => event.target.value ? setState({ ...state,
                        mobileNumber: event.target.value,
                        mobileNumberError: ""
                      }) : setState({ ...state,
                        mobileNumber: event.target.value,
                        mobileNumberError: "Mobile Number is required"
                      }),
                      placeholder: "Mobile"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 293,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 292,
                    columnNumber: 19
                  }, this), state.mobileNumberError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: state.mobileNumberError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 308,
                    columnNumber: 44
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 291,
                  columnNumber: 17
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                      type: "select",
                      name: "language",
                      value: state.language,
                      onChange: event => event.target.value ? setState({ ...state,
                        language: event.target.value,
                        languageError: ""
                      }) : setState({ ...state,
                        language: event.target.value,
                        languageError: "Language is required"
                      }),
                      className: "bg-qq7RjC",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("option", {
                        value: "",
                        children: "Choose Language"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 319,
                        columnNumber: 23
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("option", {
                        value: "en",
                        children: "English"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 320,
                        columnNumber: 23
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("option", {
                        value: "ar",
                        children: "Arabic"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 321,
                        columnNumber: 23
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 314,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 313,
                    columnNumber: 19
                  }, this), state.languageError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: state.languageError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 325,
                    columnNumber: 40
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 312,
                  columnNumber: 17
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                      type: "select",
                      name: "role",
                      value: state.role,
                      onChange: event => event.target.value ? setState({ ...state,
                        role: event.target.value,
                        roleError: ""
                      }) : setState({ ...state,
                        role: event.target.value,
                        roleError: "Role is required"
                      }),
                      className: "bg-qq7RjC",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("option", {
                        value: "",
                        children: "Choose User"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 336,
                        columnNumber: 23
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("option", {
                        value: "doctor",
                        children: "Doctor"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 337,
                        columnNumber: 23
                      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("option", {
                        value: "patient",
                        children: "Patient"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 338,
                        columnNumber: 23
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 331,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 330,
                    columnNumber: 19
                  }, this), state.roleError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: state.roleError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 342,
                    columnNumber: 36
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 329,
                  columnNumber: 17
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 230,
                columnNumber: 11
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                class: "buttonslargeblue-xUsx1L",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                  className: "signup-button",
                  onClick: signup,
                  children: "CONTINUE"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 348,
                  columnNumber: 15
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 347,
                columnNumber: 13
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 229,
              columnNumber: 11
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 224,
            columnNumber: 32
          }, this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
            class: "sign-up-dark screen",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
              class: "top-C61RwL",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                class: "sign-in-SJ3nmS",
                style: {
                  backgroundColor: signinColor
                },
                onClick: () => updateStatus("signin"),
                children: "SIGN IN"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 356,
                columnNumber: 15
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                class: "sign-up-SJ3nmS",
                style: {
                  backgroundColor: signupColor
                },
                onClick: () => updateStatus("signup"),
                children: "SIGN UP"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 357,
                columnNumber: 15
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 355,
              columnNumber: 9
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
              class: "content-signin",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                class: "textfields-signin",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                      type: "text",
                      name: "mobileNumber",
                      value: loginState.mobileNumber,
                      onChange: event => event.target.value ? setLoginState({ ...loginState,
                        mobileNumber: event.target.value,
                        mobileNumberError: ""
                      }) : setLoginState({ ...loginState,
                        mobileNumber: event.target.value,
                        mobileNumberError: "Mobile Number is required"
                      }),
                      placeholder: "Mobile"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 363,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 362,
                    columnNumber: 19
                  }, this), loginState.mobileNumberError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: loginState.mobileNumberError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 377,
                    columnNumber: 49
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 361,
                  columnNumber: 11
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                  className: "group",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["FormGroup"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Input"], {
                      type: "password",
                      name: "password",
                      value: loginState.password,
                      onChange: event => event.target.value ? setLoginState({ ...loginState,
                        password: event.target.value,
                        passwordError: ""
                      }) : setLoginState({ ...loginState,
                        password: event.target.value,
                        passwordError: "Password is required"
                      }),
                      placeholder: "Password"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 383,
                      columnNumber: 21
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 382,
                    columnNumber: 19
                  }, this), loginState.passwordError ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                    className: "validation-error",
                    children: loginState.passwordError
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 396,
                    columnNumber: 45
                  }, this) : ""]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 381,
                  columnNumber: 17
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 360,
                columnNumber: 11
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])("div", {
                class: "buttonslargeblue-signin",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                  className: "signin-button",
                  onClick: signin,
                  children: "CONTINUE"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 402,
                  columnNumber: 15
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 401,
                columnNumber: 13
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 359,
              columnNumber: 11
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 354,
            columnNumber: 18
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 223,
          columnNumber: 7
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 222,
        columnNumber: 5
      }, this);
    }
    
    _s(Signin, "aPL+mXDIqFledmv+H1fNz1tL1XY=", false, function () {
      return [react_toast_notifications__WEBPACK_IMPORTED_MODULE_5__["useToasts"]];
    });
    
    _c = Signin;
    /* harmony default export */ __webpack_exports__["default"] = (_c2 = Object(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["withRouter"])(Signin));
    
    var _c, _c2;
    
    __webpack_require__.$Refresh$.register(_c, "Signin");
    __webpack_require__.$Refresh$.register(_c2, "%default%");
    
    const currentExports = __react_refresh_utils__.getModuleExports(module.i);
    __react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);
    
    if (true) {
      const isHotUpdate = !!module.hot.data;
      const prevExports = isHotUpdate ? module.hot.data.prevExports : null;
    
      if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
        module.hot.dispose(
          /**
           * A callback to performs a full refresh if React has unrecoverable errors,
           * and also caches the to-be-disposed module.
           * @param {*} data A hot module data object from Webpack HMR.
           * @returns {void}
           */
          function hotDisposeCallback(data) {
            // We have to mutate the data object to get data registered and cached
            data.prevExports = currentExports;
          }
        );
        module.hot.accept(
          /**
           * An error handler to allow self-recovering behaviours.
           * @param {Error} error An error occurred during evaluation of a module.
           * @returns {void}
           */
          function hotErrorHandler(error) {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.handleRuntimeError(error);
            }
    
            if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
              if (window.onHotAcceptError) {
                window.onHotAcceptError(error.message);
              }
            }
    
            __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
          }
        );
    
        if (isHotUpdate) {
          if (
            __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
            __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
          ) {
            module.hot.invalidate();
          } else {
            __react_refresh_utils__.enqueueUpdate(
              /**
               * A function to dismiss the error overlay after performing React refresh.
               * @returns {void}
               */
              function updateCallback() {
                if (
                  typeof __react_refresh_error_overlay__ !== 'undefined' &&
                  __react_refresh_error_overlay__
                ) {
                  __react_refresh_error_overlay__.clearRuntimeErrors();
                }
              }
            );
          }
        }
      } else {
        if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
          module.hot.invalidate();
        }
      }
    }
    /* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))
    
    /***/ }),
    
    /***/ "./src/components/Splash.jsx":
    /*!***********************************!*\
      !*** ./src/components/Splash.jsx ***!
      \***********************************/
    /*! exports provided: default */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    __webpack_require__.r(__webpack_exports__);
    /* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../App.css */ "./src/App.css");
    /* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_App_css__WEBPACK_IMPORTED_MODULE_0__);
    /* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
    /* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");
    /* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
    /* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_4__);
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__);
    __webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
    __webpack_require__.$Refresh$.setup(module.i);
    
    var _jsxFileName = "/home/mounika/Desktop/hakeem-app/src/components/Splash.jsx",
        _s = __webpack_require__.$Refresh$.signature();
    
    
    
    
    
    
    
    const initialState = {
      mobileNumber: '',
      password: "",
      mobileNumberError: "",
      passwordError: ""
    };
    
    function Signin(props) {
      _s();
    
      const [state, setState] = Object(react__WEBPACK_IMPORTED_MODULE_2__["useState"])(initialState);
    
      const signin = () => {
        props.history.push("/continue");
      };
    
      const guestlogin = () => {
        localStorage.setItem("language", "en");
        localStorage.setItem("loggedin", true);
        localStorage.setItem("role", "guest");
        props.history.push('/home');
      };
    
      Object(react__WEBPACK_IMPORTED_MODULE_2__["useEffect"])(() => {
        document.body.style.backgroundColor = "#2e3649";
      });
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])("div", {
        class: "splash-container",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])("div", {
          class: "welcome-to",
          children: ["Welcome to ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])("br", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 37,
            columnNumber: 40
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])("span", {
            className: "sub-text",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])("span", {
              className: "i-text",
              children: "i"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 37,
              columnNumber: 73
            }, this), " Hakem"]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 37,
            columnNumber: 46
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 37,
          columnNumber: 5
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])("div", {
          class: "home-to",
          children: ["Home of Healthcare ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])("br", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 38,
            columnNumber: 45
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])("span", {
            className: "powered-by",
            children: "Powered by innovation & caring communities"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 38,
            columnNumber: 51
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 38,
          columnNumber: 5
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])("div", {
          className: "continue-with",
          children: "CONTINUE WITH:"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 39,
          columnNumber: 5
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])("div", {
          className: "buttons-xUsx1L",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])("div", {
            className: "btn-green-tCXEIx",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              className: "bg-1Ui4hb",
              onClick: signin,
              children: "Sign In"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 43,
              columnNumber: 17
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 42,
            columnNumber: 15
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])("div", {
            className: "button-tCXEIx",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              className: "bg-UZPtM3",
              onClick: guestlogin,
              children: "As a Guest"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 48,
              columnNumber: 17
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 47,
            columnNumber: 12
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 40,
          columnNumber: 6
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])("div", {
          className: "bottom-C61RwL",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])("div", {
            className: "home-indicatordark-7YEL5c",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])("div", {
              className: "indicator-LHZjI1"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 55,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 54,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 53,
          columnNumber: 14
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 5
      }, this);
    }
    
    _s(Signin, "g9yWDQF6ixWa1r5sfsm7YAeGJG4=");
    
    _c = Signin;
    /* harmony default export */ __webpack_exports__["default"] = (_c2 = Object(react_router_dom__WEBPACK_IMPORTED_MODULE_3__["withRouter"])(Signin));
    
    var _c, _c2;
    
    __webpack_require__.$Refresh$.register(_c, "Signin");
    __webpack_require__.$Refresh$.register(_c2, "%default%");
    
    const currentExports = __react_refresh_utils__.getModuleExports(module.i);
    __react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);
    
    if (true) {
      const isHotUpdate = !!module.hot.data;
      const prevExports = isHotUpdate ? module.hot.data.prevExports : null;
    
      if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
        module.hot.dispose(
          /**
           * A callback to performs a full refresh if React has unrecoverable errors,
           * and also caches the to-be-disposed module.
           * @param {*} data A hot module data object from Webpack HMR.
           * @returns {void}
           */
          function hotDisposeCallback(data) {
            // We have to mutate the data object to get data registered and cached
            data.prevExports = currentExports;
          }
        );
        module.hot.accept(
          /**
           * An error handler to allow self-recovering behaviours.
           * @param {Error} error An error occurred during evaluation of a module.
           * @returns {void}
           */
          function hotErrorHandler(error) {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.handleRuntimeError(error);
            }
    
            if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
              if (window.onHotAcceptError) {
                window.onHotAcceptError(error.message);
              }
            }
    
            __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
          }
        );
    
        if (isHotUpdate) {
          if (
            __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
            __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
          ) {
            module.hot.invalidate();
          } else {
            __react_refresh_utils__.enqueueUpdate(
              /**
               * A function to dismiss the error overlay after performing React refresh.
               * @returns {void}
               */
              function updateCallback() {
                if (
                  typeof __react_refresh_error_overlay__ !== 'undefined' &&
                  __react_refresh_error_overlay__
                ) {
                  __react_refresh_error_overlay__.clearRuntimeErrors();
                }
              }
            );
          }
        }
      } else {
        if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
          module.hot.invalidate();
        }
      }
    }
    /* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))
    
    /***/ }),
    
    /***/ "./src/components/Toggle.js":
    /*!**********************************!*\
      !*** ./src/components/Toggle.js ***!
      \**********************************/
    /*! exports provided: default */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    __webpack_require__.r(__webpack_exports__);
    /* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
    __webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
    __webpack_require__.$Refresh$.setup(module.i);
    
    var _jsxFileName = "/home/mounika/Desktop/hakeem-app/src/components/Toggle.js";
    
    
    
    
    function Toggle(props) {
      const {
        text,
        size = "default",
        checked,
        disabled,
        onChange,
        offstyle = "btn-danger",
        onstyle = "btn-success"
      } = props;
      let displayStyle = checked ? onstyle : offstyle;
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["Fragment"], {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("label", {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("span", {
            className: `${size} switch-wrapper`,
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("input", {
              type: "checkbox",
              checked: checked,
              disabled: disabled,
              onChange: e => onChange(e)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 19,
              columnNumber: 11
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("span", {
              className: `${displayStyle} switch`,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("span", {
                className: "switch-handle"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 26,
                columnNumber: 13
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 25,
              columnNumber: 11
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 18,
            columnNumber: 9
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("span", {
            className: "switch-label",
            children: text
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 29,
            columnNumber: 9
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 17,
          columnNumber: 7
        }, this)
      }, void 0, false);
    }
    
    _c = Toggle;
    /* harmony default export */ __webpack_exports__["default"] = (Toggle);
    
    var _c;
    
    __webpack_require__.$Refresh$.register(_c, "Toggle");
    
    const currentExports = __react_refresh_utils__.getModuleExports(module.i);
    __react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);
    
    if (true) {
      const isHotUpdate = !!module.hot.data;
      const prevExports = isHotUpdate ? module.hot.data.prevExports : null;
    
      if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
        module.hot.dispose(
          /**
           * A callback to performs a full refresh if React has unrecoverable errors,
           * and also caches the to-be-disposed module.
           * @param {*} data A hot module data object from Webpack HMR.
           * @returns {void}
           */
          function hotDisposeCallback(data) {
            // We have to mutate the data object to get data registered and cached
            data.prevExports = currentExports;
          }
        );
        module.hot.accept(
          /**
           * An error handler to allow self-recovering behaviours.
           * @param {Error} error An error occurred during evaluation of a module.
           * @returns {void}
           */
          function hotErrorHandler(error) {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.handleRuntimeError(error);
            }
    
            if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
              if (window.onHotAcceptError) {
                window.onHotAcceptError(error.message);
              }
            }
    
            __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
          }
        );
    
        if (isHotUpdate) {
          if (
            __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
            __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
          ) {
            module.hot.invalidate();
          } else {
            __react_refresh_utils__.enqueueUpdate(
              /**
               * A function to dismiss the error overlay after performing React refresh.
               * @returns {void}
               */
              function updateCallback() {
                if (
                  typeof __react_refresh_error_overlay__ !== 'undefined' &&
                  __react_refresh_error_overlay__
                ) {
                  __react_refresh_error_overlay__.clearRuntimeErrors();
                }
              }
            );
          }
        }
      } else {
        if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
          module.hot.invalidate();
        }
      }
    }
    /* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))
    
    /***/ }),
    
    /***/ "./src/components/Welcome.jsx":
    /*!************************************!*\
      !*** ./src/components/Welcome.jsx ***!
      \************************************/
    /*! exports provided: default */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    __webpack_require__.r(__webpack_exports__);
    /* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../App.css */ "./src/App.css");
    /* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_App_css__WEBPACK_IMPORTED_MODULE_0__);
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
    __webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
    __webpack_require__.$Refresh$.setup(module.i);
    
    var _jsxFileName = "/home/mounika/Desktop/hakeem-app/src/components/Welcome.jsx",
        _s = __webpack_require__.$Refresh$.signature();
    
    
    
    
    
    function Welcome(props) {
      _s();
    
      Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
        document.body.style.backgroundColor = "#2e3649";
      });
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("input", {
          type: "hidden",
          id: "anPageName",
          name: "page",
          value: "welcome"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 11,
          columnNumber: 5
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
          className: "container-center-horizontal",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
            className: "welcome screen",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
              className: "content-C61RwL",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
                className: "text-xUsx1L",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("p", {
                  className: "if-youre-offere-eat-just-get-on-gtySrw",
                  children: "If you\u2019re offered a seat on a rocket ship, don\u2019t ask what seat! Just get on."
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 16,
                  columnNumber: 13
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
                  className: "welcome-gtySrw",
                  children: "Welcome"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 19,
                  columnNumber: 13
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 15,
                columnNumber: 11
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
                className: "buttonssmallpurple-xUsx1L",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
                  className: "bg-YlnSTB"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 22,
                  columnNumber: 13
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
                  className: "next-YlnSTB",
                  children: "NEXT"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 23,
                  columnNumber: 13
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 21,
                columnNumber: 11
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
                className: "paginationlight-xUsx1L",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
                  className: "repeat-grid-sSXmyL",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
                    className: "x02-Z2xnye",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
                      className: "dot-h029Rs"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 28,
                      columnNumber: 17
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 27,
                    columnNumber: 15
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
                    className: "x12-Z2xnye",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
                      className: "dot-K4vLTJ"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 31,
                      columnNumber: 17
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 30,
                    columnNumber: 15
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
                    className: "x22-Z2xnye",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
                      className: "dot-RURjv5"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 34,
                      columnNumber: 17
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 33,
                    columnNumber: 15
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 26,
                  columnNumber: 13
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
                  className: "dot-sSXmyL"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 37,
                  columnNumber: 13
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 25,
                columnNumber: 11
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 14,
              columnNumber: 9
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
              className: "bottom-C61RwL",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
                className: "home-indicatorlight-7YEL5c",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
                  className: "bg-230BF3"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 42,
                  columnNumber: 13
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
                  className: "indicator-230BF3"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 43,
                  columnNumber: 13
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 41,
                columnNumber: 11
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 40,
              columnNumber: 9
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
              className: "component-106-5-C61RwL",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("div", {
                className: "bg-ge8Agk"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 47,
                columnNumber: 11
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__["jsxDEV"])("img", {
                className: "asset-6-ge8Agk",
                src: "img/asset-6-1@1x.png"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 48,
                columnNumber: 11
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 46,
              columnNumber: 9
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 13,
            columnNumber: 7
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 12,
          columnNumber: 5
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 10,
        columnNumber: 7
      }, this);
    }
    
    _s(Welcome, "OD7bBpZva5O2jO+Puf00hKivP7c=");
    
    _c = Welcome;
    /* harmony default export */ __webpack_exports__["default"] = (Welcome);
    
    var _c;
    
    __webpack_require__.$Refresh$.register(_c, "Welcome");
    
    const currentExports = __react_refresh_utils__.getModuleExports(module.i);
    __react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);
    
    if (true) {
      const isHotUpdate = !!module.hot.data;
      const prevExports = isHotUpdate ? module.hot.data.prevExports : null;
    
      if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
        module.hot.dispose(
          /**
           * A callback to performs a full refresh if React has unrecoverable errors,
           * and also caches the to-be-disposed module.
           * @param {*} data A hot module data object from Webpack HMR.
           * @returns {void}
           */
          function hotDisposeCallback(data) {
            // We have to mutate the data object to get data registered and cached
            data.prevExports = currentExports;
          }
        );
        module.hot.accept(
          /**
           * An error handler to allow self-recovering behaviours.
           * @param {Error} error An error occurred during evaluation of a module.
           * @returns {void}
           */
          function hotErrorHandler(error) {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.handleRuntimeError(error);
            }
    
            if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
              if (window.onHotAcceptError) {
                window.onHotAcceptError(error.message);
              }
            }
    
            __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
          }
        );
    
        if (isHotUpdate) {
          if (
            __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
            __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
          ) {
            module.hot.invalidate();
          } else {
            __react_refresh_utils__.enqueueUpdate(
              /**
               * A function to dismiss the error overlay after performing React refresh.
               * @returns {void}
               */
              function updateCallback() {
                if (
                  typeof __react_refresh_error_overlay__ !== 'undefined' &&
                  __react_refresh_error_overlay__
                ) {
                  __react_refresh_error_overlay__.clearRuntimeErrors();
                }
              }
            );
          }
        }
      } else {
        if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
          module.hot.invalidate();
        }
      }
    }
    /* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))
    
    /***/ }),
    
    /***/ "./src/components/index.js":
    /*!*********************************!*\
      !*** ./src/components/index.js ***!
      \*********************************/
    /*! exports provided: Navigation, Signin, Welcome, Splash, Orthis, Signup, Search, MapContainer, Profile, Sidebar, AppLanguage, Dashboard, Chat, Home, BottomNavbar, Bookings, Appointment, ProfileSettings */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    __webpack_require__.r(__webpack_exports__);
    /* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var _Navigation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Navigation */ "./src/components/Navigation.jsx");
    /* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Navigation", function() { return _Navigation__WEBPACK_IMPORTED_MODULE_0__["default"]; });
    
    /* harmony import */ var _Signin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Signin */ "./src/components/Signin.jsx");
    /* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Signin", function() { return _Signin__WEBPACK_IMPORTED_MODULE_1__["default"]; });
    
    /* harmony import */ var _Welcome__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Welcome */ "./src/components/Welcome.jsx");
    /* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Welcome", function() { return _Welcome__WEBPACK_IMPORTED_MODULE_2__["default"]; });
    
    /* harmony import */ var _Splash__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Splash */ "./src/components/Splash.jsx");
    /* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Splash", function() { return _Splash__WEBPACK_IMPORTED_MODULE_3__["default"]; });
    
    /* harmony import */ var _Orthis__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Orthis */ "./src/components/Orthis.jsx");
    /* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Orthis", function() { return _Orthis__WEBPACK_IMPORTED_MODULE_4__["default"]; });
    
    /* harmony import */ var _Signup__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Signup */ "./src/components/Signup.jsx");
    /* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Signup", function() { return _Signup__WEBPACK_IMPORTED_MODULE_5__["default"]; });
    
    /* harmony import */ var _Search__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Search */ "./src/components/Search.jsx");
    /* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Search", function() { return _Search__WEBPACK_IMPORTED_MODULE_6__["default"]; });
    
    /* harmony import */ var _MapContainer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./MapContainer */ "./src/components/MapContainer.js");
    /* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "MapContainer", function() { return _MapContainer__WEBPACK_IMPORTED_MODULE_7__["default"]; });
    
    /* harmony import */ var _Profile__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./Profile */ "./src/components/Profile.jsx");
    /* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Profile", function() { return _Profile__WEBPACK_IMPORTED_MODULE_8__["default"]; });
    
    /* harmony import */ var _Sidebar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./Sidebar */ "./src/components/Sidebar.jsx");
    /* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Sidebar", function() { return _Sidebar__WEBPACK_IMPORTED_MODULE_9__["default"]; });
    
    /* harmony import */ var _AppLanguage__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./AppLanguage */ "./src/components/AppLanguage.jsx");
    /* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AppLanguage", function() { return _AppLanguage__WEBPACK_IMPORTED_MODULE_10__["default"]; });
    
    /* harmony import */ var _Dashboard__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./Dashboard */ "./src/components/Dashboard.jsx");
    /* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Dashboard", function() { return _Dashboard__WEBPACK_IMPORTED_MODULE_11__["default"]; });
    
    /* harmony import */ var _Chat__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./Chat */ "./src/components/Chat.jsx");
    /* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Chat", function() { return _Chat__WEBPACK_IMPORTED_MODULE_12__["default"]; });
    
    /* harmony import */ var _Home__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./Home */ "./src/components/Home.jsx");
    /* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Home", function() { return _Home__WEBPACK_IMPORTED_MODULE_13__["default"]; });
    
    /* harmony import */ var _BottomNavbar__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./BottomNavbar */ "./src/components/BottomNavbar.jsx");
    /* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "BottomNavbar", function() { return _BottomNavbar__WEBPACK_IMPORTED_MODULE_14__["default"]; });
    
    /* harmony import */ var _Bookings__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./Bookings */ "./src/components/Bookings.jsx");
    /* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Bookings", function() { return _Bookings__WEBPACK_IMPORTED_MODULE_15__["default"]; });
    
    /* harmony import */ var _Appointment__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./Appointment */ "./src/components/Appointment.jsx");
    /* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Appointment", function() { return _Appointment__WEBPACK_IMPORTED_MODULE_16__["default"]; });
    
    /* harmony import */ var _ProfileSettings__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./ProfileSettings */ "./src/components/ProfileSettings.jsx");
    /* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ProfileSettings", function() { return _ProfileSettings__WEBPACK_IMPORTED_MODULE_17__["default"]; });
    
    __webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
    __webpack_require__.$Refresh$.setup(module.i);
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    const currentExports = __react_refresh_utils__.getModuleExports(module.i);
    __react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);
    
    if (true) {
      const isHotUpdate = !!module.hot.data;
      const prevExports = isHotUpdate ? module.hot.data.prevExports : null;
    
      if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
        module.hot.dispose(
          /**
           * A callback to performs a full refresh if React has unrecoverable errors,
           * and also caches the to-be-disposed module.
           * @param {*} data A hot module data object from Webpack HMR.
           * @returns {void}
           */
          function hotDisposeCallback(data) {
            // We have to mutate the data object to get data registered and cached
            data.prevExports = currentExports;
          }
        );
        module.hot.accept(
          /**
           * An error handler to allow self-recovering behaviours.
           * @param {Error} error An error occurred during evaluation of a module.
           * @returns {void}
           */
          function hotErrorHandler(error) {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.handleRuntimeError(error);
            }
    
            if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
              if (window.onHotAcceptError) {
                window.onHotAcceptError(error.message);
              }
            }
    
            __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
          }
        );
    
        if (isHotUpdate) {
          if (
            __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
            __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
          ) {
            module.hot.invalidate();
          } else {
            __react_refresh_utils__.enqueueUpdate(
              /**
               * A function to dismiss the error overlay after performing React refresh.
               * @returns {void}
               */
              function updateCallback() {
                if (
                  typeof __react_refresh_error_overlay__ !== 'undefined' &&
                  __react_refresh_error_overlay__
                ) {
                  __react_refresh_error_overlay__.clearRuntimeErrors();
                }
              }
            );
          }
        }
      } else {
        if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
          module.hot.invalidate();
        }
      }
    }
    /* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))
    
    /***/ }),
    
    /***/ "./src/data/appointments.json":
    /*!************************************!*\
      !*** ./src/data/appointments.json ***!
      \************************************/
    /*! exports provided: data, default */
    /***/ (function(module) {
    
    module.exports = JSON.parse("{\"data\":[{\"id\":0,\"name\":\"James\",\"image\":\"/static/img/doctors/james.png\",\"time\":\"1:00 PM\",\"speciality\":\"Neurology\",\"date\":\"31-Jul-2021\",\"nameAr\":\"ميرل فريبرج\",\"timeAr\":\"1:00 مساء\",\"specialityAr\":\"علم الأعصاب\",\"display\":\"today\"},{\"id\":1,\"name\":\"Matt Smith\",\"image\":\"/static/img/doctors/smith.jpg\",\"time\":\"4:30 PM\",\"speciality\":\"Dermatology\",\"date\":\"31-Jul-2021\",\"nameAr\":\"مات سميث\",\"timeAr\":\"4:30 مساءً\",\"specialityAr\":\"طب القلب\",\"display\":\"today\"},{\"id\":2,\"name\":\"Mounika\",\"image\":\"/static/img/doctors/mounika.png\",\"time\":\"10:00 AM\",\"speciality\":\"Dermatology\",\"date\":\"28 Aug 2021\",\"nameAr\":\"مونيقة\",\"timeAr\":\"10:00 صباحا\",\"specialityAr\":\"الجلدية\",\"display\":\"month\"},{\"id\":3,\"name\":\"Angel\",\"image\":\"/static/img/doctors/angel.jpg\",\"time\":\"3:00 PM\",\"speciality\":\"Cardiology\",\"date\":\"28 Aug 2021\",\"nameAr\":\"لاك\",\"timeAr\":\"3:00 مساءً\",\"specialityAr\":\"طب القلب\",\"display\":\"week\"}]}");
    
    /***/ }),
    
    /***/ "./src/data/chatdata.json":
    /*!********************************!*\
      !*** ./src/data/chatdata.json ***!
      \********************************/
    /*! exports provided: data, default */
    /***/ (function(module) {
    
    module.exports = JSON.parse("{\"data\":[{\"id\":0,\"name\":\"Sarah Kortney\",\"image\":\"/static/img/users/user2.jpeg\",\"message\":\"Your success and happiness lies in you. Resolve to keep happy, and your joy and you shall form an invincible host against difficulties. The sweetest of all sounds is praise.\",\"time\":\"1 hour ago\",\"messagescount\":\"2\",\"date\":\"07-23-2021\",\"nameAr\":\"سارة كورتني\",\"messageAr\":\"نجاحك وسعادتك يكمن فيك. عقد العزم على أن تبقى سعيدًا ، وفرحك وستكون مضيفًا لا يقهر ضد الصعوبات. أحلى الأصوات الحمد.\",\"timeAr\":\"منذ 1 ساعة\"},{\"id\":1,\"name\":\"Linn Ronning\",\"image\":\"/static/img/users/user3.jpeg\",\"message\":\"Your success and happiness lies in you. Resolve to keep happy, and your joy and you shall form an invincible host against difficulties. The sweetest of all sounds is praise.\",\"time\":\"2 hour ago\",\"messagescount\":\"4\",\"date\":\"07-10-2021\",\"nameAr\":\"لين رونينج\",\"messageAr\":\"نجاحك وسعادتك يكمن فيك. عقد العزم على أن تبقى سعيدًا ، وفرحك وستكون مضيفًا لا يقهر ضد الصعوبات. أحلى الأصوات الحمد.\",\"timeAr\":\"منذ ساعتين\"},{\"id\":2,\"name\":\"Goldie Mossman\",\"image\":\"/static/img/users/user4.jpeg\",\"message\":\"When one door of happiness closes, another opens, but often we look so long at the closed door that we do not see the one that has been opened for us.\",\"time\":\"4 hour ago\",\"messagescount\":\"3\",\"date\":\"07-23-2021\",\"nameAr\":\"جولدي موسمان\",\"messageAr\":\"عندما يُغلق أحد أبواب السعادة ، يفتح باب آخر ، لكن غالبًا ما ننظر طويلاً إلى الباب المغلق بحيث لا نرى الباب الذي تم فتحه لنا.\",\"timeAr\":\"قبل 4 ساعات\"},{\"id\":3,\"name\":\"Laree Munsch\",\"image\":\"/static/img/users/user5.jpeg\",\"message\":\"Your success and happiness lies in you. Resolve to keep happy, and your joy and you shall form an invincible host against difficulties. The sweetest of all sounds is praise.\",\"time\":\"1 hour ago\",\"messagescount\":\"2\",\"date\":\"07-22-2021\",\"nameAr\":\"لاري مونش\",\"messageAr\":\"نجاحك وسعادتك يكمن فيك. عقد العزم على أن تبقى سعيدًا ، وفرحك وستكون مضيفًا لا يقهر ضد الصعوبات. أحلى الأصوات الحمد.\",\"timeAr\":\"منذ 1 ساعة\"},{\"id\":4,\"name\":\"Brynn Bragg\",\"image\":\"/static/img/users/user5.jpeg\",\"message\":\"Your success and happiness lies in you. Resolve to keep happy, and your joy and you shall form an invincible host against difficulties. The sweetest of all sounds is praise.\",\"time\":\"2 hour ago\",\"messagescount\":\"4\",\"date\":\"07-28-2021\",\"nameAr\":\"برين براج\",\"messageAr\":\"نجاحك وسعادتك يكمن فيك. عقد العزم على أن تبقى سعيدًا ، وفرحك وستكون مضيفًا لا يقهر ضد الصعوبات. أحلى الأصوات الحمد.\",\"timeAr\":\"منذ ساعتين\"},{\"id\":5,\"name\":\"Merle Friberg\",\"image\":\"/static/img/users/user5.jpeg\",\"message\":\"Your success and happiness lies in you. Resolve to keep happy, and your joy and you shall form an invincible host against difficulties. The sweetest of all sounds is praise.\",\"time\":\"1 hour ago\",\"messagescount\":\"3\",\"date\":\"07-11-2021\",\"nameAr\":\"ميرل فريبرج\",\"messageAr\":\"نجاحك وسعادتك يكمن فيك. عقد العزم على أن تبقى سعيدًا ، وفرحك وستكون مضيفًا لا يقهر ضد الصعوبات. أحلى الأصوات الحمد.\",\"timeAr\":\"منذ 1 ساعة\"},{\"id\":6,\"name\":\"Velva Valdovinos\",\"image\":\"/static/img/users/user1.jpeg\",\"message\":\"Your success and happiness lies in you. Resolve to keep happy, and your joy and you shall form an invincible host against difficulties. The sweetest of all sounds is praise.\",\"time\":\"3 hour ago\",\"messagescount\":\"5\",\"date\":\"07-22-2021\",\"nameAr\":\"فيلفا فالدوفينوس\",\"messageAr\":\"نجاحك وسعادتك يكمن فيك. عقد العزم على أن تبقى سعيدًا ، وفرحك وستكون مضيفًا لا يقهر ضد الصعوبات. أحلى الأصوات الحمد.\",\"timeAr\":\"منذ 3 ساعات\"},{\"id\":7,\"name\":\"Dusti Gioia\",\"image\":\"/static/img/users/user3.jpeg\",\"message\":\"When one door of happiness closes, another opens, but often we look so long at the closed door that we do not see the one that has been opened for us.\",\"time\":\"1 hour ago\",\"messagescount\":\"2\",\"date\":\"07-27-2021\",\"nameAr\":\"داستي جويا\",\"messageAr\":\"عندما يُغلق أحد أبواب السعادة ، يفتح باب آخر ، لكن غالبًا ما ننظر طويلاً إلى الباب المغلق بحيث لا نرى الباب الذي تم فتحه لنا.\",\"timeAr\":\"منذ 1 ساعة\"},{\"id\":8,\"name\":\"Philip Nelms\",\"image\":\"/static/img/users/user2.jpeg\",\"message\":\"When one door of happiness closes, another opens, but often we look so long at the closed door that we do not see the one that has been opened for us.\",\"time\":\"1 hour ago\",\"messagescount\":\"1\",\"date\":\"07-22-2021\",\"nameAr\":\"فيليب نيلمز\",\"messageAr\":\"عندما يُغلق أحد أبواب السعادة ، يفتح باب آخر ، لكن غالبًا ما ننظر طويلاً إلى الباب المغلق بحيث لا نرى الباب الذي تم فتحه لنا.\",\"timeAr\":\"منذ 1 ساعة\"},{\"id\":9,\"name\":\"Marty Otte\",\"image\":\"/static/img/users/user5.jpeg\",\"message\":\"When one door of happiness closes, another opens, but often we look so long at the closed door that we do not see the one that has been opened for us.\",\"time\":\"1 hour ago\",\"messagescount\":\"2\",\"date\":\"07-14-2021\",\"nameAr\":\"مارتي أوتي\",\"messageAr\":\"عندما يُغلق أحد أبواب السعادة ، يفتح باب آخر ، لكن غالبًا ما ننظر طويلاً إلى الباب المغلق بحيث لا نرى الباب الذي تم فتحه لنا.\",\"timeAr\":\"منذ 1 ساعة\"},{\"id\":10,\"name\":\"Janene Thies\",\"image\":\"/static/img/users/user1.jpeg\",\"message\":\"When one door of happiness closes, another opens, but often we look so long at the closed door that we do not see the one that has been opened for us.\",\"time\":\"1 hour ago\",\"messagescount\":\"6\",\"date\":\"07-31-2021\",\"nameAr\":\"جانين ثيس\",\"messageAr\":\"عندما يُغلق أحد أبواب السعادة ، يفتح باب آخر ، لكن غالبًا ما ننظر طويلاً إلى الباب المغلق بحيث لا نرى الباب الذي تم فتحه لنا.\",\"timeAr\":\"منذ 1 ساعة\"},{\"id\":11,\"name\":\"Bao Hathaway\",\"image\":\"/static/img/users/user3.jpeg\",\"message\":\"Your success and happiness lies in you. Resolve to keep happy, and your joy and you shall form an invincible host against difficulties. The sweetest of all sounds is praise.\",\"time\":\"3 hour ago\",\"messagescount\":\"6\",\"date\":\"07-25-2021\",\"nameAr\":\"باو هاثاواي\",\"messageAr\":\"نجاحك وسعادتك يكمن فيك. عقد العزم على أن تبقى سعيدًا ، وفرحك وستكون مضيفًا لا يقهر ضد الصعوبات. أحلى الأصوات الحمد.\",\"timeAr\":\"منذ 3 ساعات\"},{\"id\":12,\"name\":\"Ramiro Roark\",\"image\":\"/static/img/users/user2.jpeg\",\"message\":\"Your success and happiness lies in you. Resolve to keep happy, and your joy and you shall form an invincible host against difficulties. The sweetest of all sounds is praise.\",\"time\":\"1 hour ago\",\"messagescount\":\"2\",\"date\":\"07-07-2021\",\"nameAr\":\"راميرو رورك\",\"messageAr\":\"نجاحك وسعادتك يكمن فيك. عقد العزم على أن تبقى سعيدًا ، وفرحك وستكون مضيفًا لا يقهر ضد الصعوبات. أحلى الأصوات الحمد.\",\"timeAr\":\"منذ 1 ساعة\"}]}");
    
    /***/ }),
    
    /***/ "./src/index.css":
    /*!***********************!*\
      !*** ./src/index.css ***!
      \***********************/
    /*! no static exports found */
    /***/ (function(module, exports, __webpack_require__) {
    
    var api = __webpack_require__(/*! ../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
                var content = __webpack_require__(/*! !../node_modules/css-loader/dist/cjs.js??ref--5-oneOf-4-1!../node_modules/postcss-loader/src??postcss!./index.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/index.css");
    
                content = content.__esModule ? content.default : content;
    
                if (typeof content === 'string') {
                  content = [[module.i, content, '']];
                }
    
    var options = {};
    
    options.insert = "head";
    options.singleton = false;
    
    var update = api(content, options);
    
    
    if (true) {
      if (!content.locals || module.hot.invalidate) {
        var isEqualLocals = function isEqualLocals(a, b, isNamedExport) {
      if (!a && b || a && !b) {
        return false;
      }
    
      var p;
    
      for (p in a) {
        if (isNamedExport && p === 'default') {
          // eslint-disable-next-line no-continue
          continue;
        }
    
        if (a[p] !== b[p]) {
          return false;
        }
      }
    
      for (p in b) {
        if (isNamedExport && p === 'default') {
          // eslint-disable-next-line no-continue
          continue;
        }
    
        if (!a[p]) {
          return false;
        }
      }
    
      return true;
    };
        var oldLocals = content.locals;
    
        module.hot.accept(
          /*! !../node_modules/css-loader/dist/cjs.js??ref--5-oneOf-4-1!../node_modules/postcss-loader/src??postcss!./index.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/index.css",
          function () {
            content = __webpack_require__(/*! !../node_modules/css-loader/dist/cjs.js??ref--5-oneOf-4-1!../node_modules/postcss-loader/src??postcss!./index.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/index.css");
    
                  content = content.__esModule ? content.default : content;
    
                  if (typeof content === 'string') {
                    content = [[module.i, content, '']];
                  }
    
                  if (!isEqualLocals(oldLocals, content.locals)) {
                    module.hot.invalidate();
    
                    return;
                  }
    
                  oldLocals = content.locals;
    
                  update(content);
          }
        )
      }
    
      module.hot.dispose(function() {
        update();
      });
    }
    
    module.exports = content.locals || {};
    
    /***/ }),
    
    /***/ "./src/index.js":
    /*!**********************!*\
      !*** ./src/index.js ***!
      \**********************/
    /*! no exports provided */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    __webpack_require__.r(__webpack_exports__);
    /* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
    /* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
    /* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom */ "./node_modules/react-dom/index.js");
    /* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
    /* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./index.css */ "./src/index.css");
    /* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_index_css__WEBPACK_IMPORTED_MODULE_2__);
    /* harmony import */ var _App__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./App */ "./src/App.js");
    /* harmony import */ var bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! bootstrap/dist/css/bootstrap.min.css */ "./node_modules/bootstrap/dist/css/bootstrap.min.css");
    /* harmony import */ var bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(bootstrap_dist_css_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_4__);
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
    /* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__);
    __webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
    __webpack_require__.$Refresh$.setup(module.i);
    
    var _jsxFileName = "/home/mounika/Desktop/hakeem-app/src/index.js";
    
    
    
     // import reportWebVitals from './reportWebVitals';
    
    
    
    react_dom__WEBPACK_IMPORTED_MODULE_1___default.a.render( /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_0___default.a.StrictMode, {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])(_App__WEBPACK_IMPORTED_MODULE_3__["default"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 11,
        columnNumber: 5
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 10,
      columnNumber: 3
    }, undefined), document.getElementById('root'));
    
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').then(function (registration) {
        registration.addEventListener('updatefound', function () {
          // If updatefound is fired, it means that there's
          // a new service worker being installed.
          var installingWorker = registration.installing;
          console.log('A new service worker is being installed:', installingWorker); // You can listen for changes to the installing service worker's
          // state via installingWorker.onstatechange
        });
      }).catch(function (error) {
        console.log('Service worker registration failed:', error);
      });
    } else {
      console.log('Service workers are not supported.');
    }
    
    let swUrl = 'sw.js';
    navigator.serviceWorker.register(swUrl).then(response => {
      console.warn("response", response);
    }); // If you want to start measuring performance in your app, pass a function
    // to log results (for example: reportWebVitals(console.log))
    // or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
    // reportWebVitals();
    
    const currentExports = __react_refresh_utils__.getModuleExports(module.i);
    __react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);
    
    if (true) {
      const isHotUpdate = !!module.hot.data;
      const prevExports = isHotUpdate ? module.hot.data.prevExports : null;
    
      if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
        module.hot.dispose(
          /**
           * A callback to performs a full refresh if React has unrecoverable errors,
           * and also caches the to-be-disposed module.
           * @param {*} data A hot module data object from Webpack HMR.
           * @returns {void}
           */
          function hotDisposeCallback(data) {
            // We have to mutate the data object to get data registered and cached
            data.prevExports = currentExports;
          }
        );
        module.hot.accept(
          /**
           * An error handler to allow self-recovering behaviours.
           * @param {Error} error An error occurred during evaluation of a module.
           * @returns {void}
           */
          function hotErrorHandler(error) {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.handleRuntimeError(error);
            }
    
            if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
              if (window.onHotAcceptError) {
                window.onHotAcceptError(error.message);
              }
            }
    
            __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
          }
        );
    
        if (isHotUpdate) {
          if (
            __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
            __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
          ) {
            module.hot.invalidate();
          } else {
            __react_refresh_utils__.enqueueUpdate(
              /**
               * A function to dismiss the error overlay after performing React refresh.
               * @returns {void}
               */
              function updateCallback() {
                if (
                  typeof __react_refresh_error_overlay__ !== 'undefined' &&
                  __react_refresh_error_overlay__
                ) {
                  __react_refresh_error_overlay__.clearRuntimeErrors();
                }
              }
            );
          }
        }
      } else {
        if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
          module.hot.invalidate();
        }
      }
    }
    /* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))
    
    /***/ }),
    
    /***/ "./src/lang/locales/ar.js":
    /*!********************************!*\
      !*** ./src/lang/locales/ar.js ***!
      \********************************/
    /*! no static exports found */
    /***/ (function(module, exports, __webpack_require__) {
    
    /* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
    __webpack_require__.$Refresh$.setup(module.i);
    
    module.exports = {
      /* Search */
      'search_whereto': 'إلى أين؟',
      'search_filter_all': 'الجميع',
      'search_filter_doctors': 'الأطباء',
      'search_filter_clinics': 'عيادات',
      'search_filter_select_speciality': 'حدد التخصص',
      'search_filter_select_location': 'اختر موقعا',
      'search_filter_save': 'يحفظ',
      'search_search': 'يبحث',
      "search_advertisement": "الإعلانات",
      "search_nodata": "لايوجد بيانات",
    
      /* Bottom Navbar */
      'bottomnavbar_home': 'الصفحة الرئيسية',
      'bottomnavbar_media': 'وسائط',
      'bottomnavbar_search': 'يبحث',
      'bottomnavbar_post': 'بريد',
      'bottomnavbar_profile': 'الملف الشخصي',
    
      /* Profile */
      'profile_address': 'تفاصيل العنوان',
      'profile_phone': 'الهاتف / البريد الإلكتروني',
      'profile_link_message': '(ربط الرموز أعلاه بطلب)',
      'profile_appointment': 'طلب موعد',
    
      /* Chat */
      'chat_post': 'الدردشة / المشاركات',
      'chat_today': 'اليوم',
      'chat_week': 'أسبوع',
      'chat_month': 'شهر',
      'chat_patient': "مريض",
    
      /* Dashboard */
      'dashboard_speciality': 'الجلدية. الاختصاص (الخيار)',
      'dashboard_name': 'د. أيمن عبد الكريم',
      'dashboard_board': 'شهادات المجالس',
      'dashboard_info': 'معلومات',
      'dashboard_patients': 'مرضى',
      'dashboard_followers': 'متابعون',
      'dashboard_posts': 'المشاركات',
      'dashboard_chat': 'محادثة',
      'dashboard_bookings': 'الحجوزات',
      'dashboard_payments': 'المدفوعات',
      'dashboard_profileinfo': 'معلومات الشخصي',
      'dashboard_account': 'الحساب',
      'dashboard_login': 'الخروج',
    
      /* Appoinments */
      'bookings_appointments': "تعيينات",
      "bookings_apptdate": "تاريخ التطبيق",
    
      /* Appointment */
      'appointment_appointment': "ميعاد",
      'appointment_selectdate': 'حدد تاريخ',
      'appointment_slot': 'الفتحات المتاحة',
      'appointment_beforenoon': 'قبل الظهر',
      'appointment_afternoon': 'بعد الظهر',
      'appointment_submit': 'حدد موعدا',
      'appointment_slot_required': 'الرجاء تحديد خانة للحصول على موعد'
    };
    
    const currentExports = __react_refresh_utils__.getModuleExports(module.i);
    __react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);
    
    if (true) {
      const isHotUpdate = !!module.hot.data;
      const prevExports = isHotUpdate ? module.hot.data.prevExports : null;
    
      if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
        module.hot.dispose(
          /**
           * A callback to performs a full refresh if React has unrecoverable errors,
           * and also caches the to-be-disposed module.
           * @param {*} data A hot module data object from Webpack HMR.
           * @returns {void}
           */
          function hotDisposeCallback(data) {
            // We have to mutate the data object to get data registered and cached
            data.prevExports = currentExports;
          }
        );
        module.hot.accept(
          /**
           * An error handler to allow self-recovering behaviours.
           * @param {Error} error An error occurred during evaluation of a module.
           * @returns {void}
           */
          function hotErrorHandler(error) {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.handleRuntimeError(error);
            }
    
            if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
              if (window.onHotAcceptError) {
                window.onHotAcceptError(error.message);
              }
            }
    
            __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
          }
        );
    
        if (isHotUpdate) {
          if (
            __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
            __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
          ) {
            module.hot.invalidate();
          } else {
            __react_refresh_utils__.enqueueUpdate(
              /**
               * A function to dismiss the error overlay after performing React refresh.
               * @returns {void}
               */
              function updateCallback() {
                if (
                  typeof __react_refresh_error_overlay__ !== 'undefined' &&
                  __react_refresh_error_overlay__
                ) {
                  __react_refresh_error_overlay__.clearRuntimeErrors();
                }
              }
            );
          }
        }
      } else {
        if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
          module.hot.invalidate();
        }
      }
    }
    /* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))
    
    /***/ }),
    
    /***/ "./src/lang/locales/en.js":
    /*!********************************!*\
      !*** ./src/lang/locales/en.js ***!
      \********************************/
    /*! no static exports found */
    /***/ (function(module, exports, __webpack_require__) {
    
    /* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
    __webpack_require__.$Refresh$.setup(module.i);
    
    module.exports = {
      /* Search */
      'search_whereto': 'Where to?',
      'search_filter_all': 'All',
      'search_filter_doctors': 'Doctors',
      'search_filter_clinics': 'Clinics',
      'search_filter_select_speciality': 'Select Speciality',
      'search_filter_select_location': 'Select Location',
      'search_filter_save': 'Save',
      'search_search': 'Search',
      "search_advertisement": "Advertisement",
      "search_nodata": "No Data",
    
      /* Bottom Navbar */
      'bottomnavbar_home': 'Home',
      'bottomnavbar_media': 'Media',
      'bottomnavbar_search': 'Search',
      'bottomnavbar_post': 'Post',
      'bottomnavbar_profile': 'Profile',
    
      /* Profile */
      'profile_address': 'Address Details',
      'profile_phone': 'Phone/Email',
      'profile_link_message': '(link icons above to Dial)',
      'profile_appointment': 'Request An Appointment',
    
      /* Chat */
      'chat_post': 'Chat/Posts',
      'chat_today': 'TODAY',
      'chat_week': 'WEEK',
      'chat_month': 'MONTH',
      'chat_patient': "Patient",
    
      /* Chat */
      'profilesettings': 'Profile Settings',
      'profilesettings_basicinfo': 'Basic Info',
      'profilesetting_scheduletimings': "Timings",
      'profilesettings_contactdetails': 'Contact Details',
      // 'profilesettings_month':'MONTH',
      // 'profilesettings_patient':"Patient",
    
      /* Dashboard */
      'dashboard_speciality': 'DERMATOLOGY . SUBSPECIALTY (OPTION)',
      'dashboard_name': 'Dr. Ayman ABCDEAFGHKLMNASDFAS',
      'dashboard_board': 'Boards certifications',
      'dashboard_info': 'info',
      'dashboard_patients': 'Patients',
      'dashboard_followers': 'Followers',
      'dashboard_posts': 'Posts',
      'dashboard_chat': 'Chat',
      'dashboard_bookings': 'Bookings',
      'dashboard_payments': 'Payments',
      'dashboard_profileinfo': 'Profile Info',
      'dashboard_account': 'Account',
      'dashboard_login': 'Login/Out',
    
      /* Appoinments */
      'bookings_appointments': "Appointments",
      "bookings_apptdate": "Appt Date",
    
      /* Appointment */
      'appointment_appointment': "Appointment",
      'appointment_selectdate': 'Select Date',
      'appointment_slot': 'Slots Available',
      'appointment_beforenoon': 'Before Noon',
      'appointment_afternoon': 'After Noon',
      'appointment_submit': 'Make Appointment',
      'appointment_slot_required': 'Please select Slot'
    };
    
    const currentExports = __react_refresh_utils__.getModuleExports(module.i);
    __react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);
    
    if (true) {
      const isHotUpdate = !!module.hot.data;
      const prevExports = isHotUpdate ? module.hot.data.prevExports : null;
    
      if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
        module.hot.dispose(
          /**
           * A callback to performs a full refresh if React has unrecoverable errors,
           * and also caches the to-be-disposed module.
           * @param {*} data A hot module data object from Webpack HMR.
           * @returns {void}
           */
          function hotDisposeCallback(data) {
            // We have to mutate the data object to get data registered and cached
            data.prevExports = currentExports;
          }
        );
        module.hot.accept(
          /**
           * An error handler to allow self-recovering behaviours.
           * @param {Error} error An error occurred during evaluation of a module.
           * @returns {void}
           */
          function hotErrorHandler(error) {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.handleRuntimeError(error);
            }
    
            if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
              if (window.onHotAcceptError) {
                window.onHotAcceptError(error.message);
              }
            }
    
            __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
          }
        );
    
        if (isHotUpdate) {
          if (
            __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
            __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
          ) {
            module.hot.invalidate();
          } else {
            __react_refresh_utils__.enqueueUpdate(
              /**
               * A function to dismiss the error overlay after performing React refresh.
               * @returns {void}
               */
              function updateCallback() {
                if (
                  typeof __react_refresh_error_overlay__ !== 'undefined' &&
                  __react_refresh_error_overlay__
                ) {
                  __react_refresh_error_overlay__.clearRuntimeErrors();
                }
              }
            );
          }
        }
      } else {
        if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
          module.hot.invalidate();
        }
      }
    }
    /* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))
    
    /***/ }),
    
    /***/ 1:
    /*!**********************************************************************************************************************************************************************************************!*\
      !*** multi (webpack)/hot/dev-server.js ./node_modules/@pmmmwh/react-refresh-webpack-plugin/client/ReactRefreshEntry.js ./node_modules/react-dev-utils/webpackHotDevClient.js ./src/index.js ***!
      \**********************************************************************************************************************************************************************************************/
    /*! no static exports found */
    /***/ (function(module, exports, __webpack_require__) {
    
    __webpack_require__(/*! /home/mounika/Desktop/hakeem-app/node_modules/webpack/hot/dev-server.js */"./node_modules/webpack/hot/dev-server.js");
    __webpack_require__(/*! /home/mounika/Desktop/hakeem-app/node_modules/@pmmmwh/react-refresh-webpack-plugin/client/ReactRefreshEntry.js */"./node_modules/@pmmmwh/react-refresh-webpack-plugin/client/ReactRefreshEntry.js");
    __webpack_require__(/*! /home/mounika/Desktop/hakeem-app/node_modules/react-dev-utils/webpackHotDevClient.js */"./node_modules/react-dev-utils/webpackHotDevClient.js");
    module.exports = __webpack_require__(/*! /home/mounika/Desktop/hakeem-app/src/index.js */"./src/index.js");
    
    
    /***/ })
    
    },[[1,"runtime-main","vendors~main"]]]);
    //# sourceMappingURL=main.chunk.js.map