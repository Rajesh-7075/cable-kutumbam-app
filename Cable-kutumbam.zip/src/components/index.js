
export {default as Splash} from './Splash';
export {default as Homepage} from './Homepage';
export {default as Registration} from './Registration';
export {default as IDcard} from './IDcard';
export {default as Login} from './Login';




